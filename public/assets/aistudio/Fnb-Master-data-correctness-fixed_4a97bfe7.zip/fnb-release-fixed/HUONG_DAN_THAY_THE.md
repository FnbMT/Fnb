# Bản sửa tính đúng đắn dữ liệu

Thay toàn bộ mã cũ bằng thư mục này. Bản này đã đồng bộ web assets cho `android/` và `ios/`.

Trước khi đưa lên TestFlight hoặc Google Play, tại GitHub macOS runner chạy:

```bash
npm ci
npm run build:mobile
```

Các thay đổi tập trung ở `src/App.tsx`, `src/components/SummaryView.tsx`, `src/components/TaxReportView.tsx`, `src/types.ts` và `src/utils/`.
