
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-networkinterface.networkinterface",
          "file": "plugins/cordova-plugin-networkinterface/www/networkinterface.js",
          "pluginId": "cordova-plugin-networkinterface",
        "clobbers": [
          "window.networkinterface"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-networkinterface": "2.0.0"
    };
    // BOTTOM OF METADATA
    });
    