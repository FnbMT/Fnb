var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.app.ts
var import_express = __toESM(require("express"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);

// api/_firebaseAdmin.ts
var import_app = require("firebase-admin/app");
var import_firestore = require("firebase-admin/firestore");
var import_auth = require("firebase-admin/auth");
var import_app2 = require("firebase/app");
var import_firestore2 = require("firebase/firestore");
var projectId = process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID || "app-fnb-d8940";
var apiKey = process.env.VITE_FIREBASE_API_KEY || "AIzaSyCoyF_ArTx73XrHPjRTfzLXdV8yYjF24kE";
var authDomain = process.env.VITE_FIREBASE_AUTH_DOMAIN || "app-fnb-d8940.firebaseapp.com";
var serviceAccountRaw = process.env.FIREBASE_SERVICE_ACCOUNT;
var clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
var privateKey = process.env.FIREBASE_PRIVATE_KEY;
var hasAdminCredential = Boolean(
  serviceAccountRaw && serviceAccountRaw.trim().length > 10 || clientEmail && privateKey && clientEmail.includes("@")
);
var getAdminStatus = () => ({
  hasCredential: hasAdminCredential,
  isInitialized: Boolean(rawAdminApp && rawAdminDb),
  projectId
});
var rawAdminApp = null;
var rawAdminDb = null;
var rawAdminAuth = null;
if (hasAdminCredential) {
  try {
    const existing = (0, import_app.getApps)();
    if (existing.length > 0) {
      rawAdminApp = existing[0];
    } else if (serviceAccountRaw) {
      const parsed = JSON.parse(serviceAccountRaw);
      rawAdminApp = (0, import_app.initializeApp)({
        credential: (0, import_app.cert)(parsed),
        projectId: parsed.project_id || projectId
      });
    } else if (clientEmail && privateKey) {
      rawAdminApp = (0, import_app.initializeApp)({
        credential: (0, import_app.cert)({
          projectId,
          clientEmail,
          privateKey: privateKey.replace(/\\n/g, "\n")
        }),
        projectId
      });
    }
    if (rawAdminApp) {
      rawAdminDb = (0, import_firestore.getFirestore)(rawAdminApp);
      rawAdminAuth = (0, import_auth.getAuth)(rawAdminApp);
    }
  } catch (err) {
    console.warn("[FirebaseAdmin] Failed to initialize Firebase Admin with service account:", err);
  }
}
var getClientDbInstance = () => {
  const apps = (0, import_app2.getApps)();
  const cApp = apps.find((a) => a.name === "server-client-bridge") || (0, import_app2.initializeApp)({
    apiKey,
    authDomain,
    projectId
  }, "server-client-bridge");
  return (0, import_firestore2.getFirestore)(cApp);
};
var cDb = getClientDbInstance();
var sanitizeDataForClient = (data) => {
  if (!data || typeof data !== "object") return data;
  if (Array.isArray(data)) return data.map(sanitizeDataForClient);
  const clean = {};
  for (const [key, value] of Object.entries(data)) {
    if (value && typeof value === "object" && ("isEqual" in value || value.constructor?.name === "FieldValue")) {
      clean[key] = (0, import_firestore2.deleteField)();
    } else if (value && typeof value === "object" && !(value instanceof Date)) {
      clean[key] = sanitizeDataForClient(value);
    } else {
      clean[key] = value;
    }
  }
  return clean;
};
var ClientQueryAdapter = class {
  constructor(colName) {
    this.filters = [];
    this.orders = [];
    this.limitNum = null;
    this.startAfterDocOrId = null;
    this.colName = colName;
  }
  where(field, op, val) {
    this.filters.push({ field, op, val });
    return this;
  }
  orderBy(field, dir = "asc") {
    this.orders.push({ field, dir });
    return this;
  }
  startAfter(cursor) {
    this.startAfterDocOrId = cursor;
    return this;
  }
  limit(num) {
    this.limitNum = num;
    return this;
  }
  async get() {
    let q = (0, import_firestore2.collection)(cDb, this.colName);
    const constraints = [];
    for (const f of this.filters) {
      constraints.push((0, import_firestore2.where)(f.field, f.op, f.val));
    }
    for (const o of this.orders) {
      constraints.push((0, import_firestore2.orderBy)(o.field, o.dir));
    }
    if (this.startAfterDocOrId) {
      if (typeof this.startAfterDocOrId === "string") {
        constraints.push((0, import_firestore2.where)((0, import_firestore2.documentId)(), ">", this.startAfterDocOrId));
      } else {
        constraints.push((0, import_firestore2.startAfter)(this.startAfterDocOrId));
      }
    }
    if (this.limitNum) {
      constraints.push((0, import_firestore2.limit)(this.limitNum));
    }
    if (constraints.length > 0) {
      q = (0, import_firestore2.query)(q, ...constraints);
    }
    const snapshot = await (0, import_firestore2.getDocs)(q);
    const docs = snapshot.docs.map((d) => ({
      id: d.id,
      exists: true,
      data: () => d.data(),
      ref: { id: d.id, path: `${this.colName}/${d.id}` }
    }));
    return {
      empty: snapshot.empty,
      size: snapshot.size,
      docs,
      forEach(cb) {
        docs.forEach(cb);
      }
    };
  }
};
var AdminQueryAdapter = class {
  constructor(colName, rawQuery, initialFilter) {
    this.filters = [];
    this.orders = [];
    this.limitNum = null;
    this.startAfterCursor = null;
    this.colName = colName;
    this.rawQuery = rawQuery;
    if (initialFilter) {
      this.filters.push(initialFilter);
    }
  }
  where(field, op, val) {
    if (this.rawQuery) {
      try {
        this.rawQuery = this.rawQuery.where(field, op, val);
      } catch (e) {
        this.rawQuery = null;
      }
    }
    this.filters.push({ field, op, val });
    return this;
  }
  orderBy(field, dir = "asc") {
    if (this.rawQuery) {
      try {
        this.rawQuery = this.rawQuery.orderBy(field, dir);
      } catch (e) {
        this.rawQuery = null;
      }
    }
    this.orders.push({ field, dir });
    return this;
  }
  startAfter(cursor) {
    if (this.rawQuery) {
      try {
        this.rawQuery = this.rawQuery.startAfter(cursor);
      } catch (e) {
        this.rawQuery = null;
      }
    }
    this.startAfterCursor = cursor;
    return this;
  }
  limit(num) {
    if (this.rawQuery) {
      try {
        this.rawQuery = this.rawQuery.limit(num);
      } catch (e) {
        this.rawQuery = null;
      }
    }
    this.limitNum = num;
    return this;
  }
  async get() {
    if (this.rawQuery) {
      try {
        const snap = await this.rawQuery.get();
        if (snap && typeof snap.forEach === "function") {
          return snap;
        }
        return {
          empty: snap.empty,
          size: snap.size,
          docs: snap.docs,
          forEach(cb) {
            snap.docs.forEach(cb);
          }
        };
      } catch (err) {
        if (!err.message?.includes("PERMISSION_DENIED") && err.code !== 7) {
          throw err;
        }
      }
    }
    let clientQ = new ClientQueryAdapter(this.colName);
    for (const f of this.filters) {
      clientQ.where(f.field, f.op, f.val);
    }
    for (const o of this.orders) {
      clientQ.orderBy(o.field, o.dir);
    }
    if (this.startAfterCursor) {
      clientQ.startAfter(this.startAfterCursor);
    }
    if (this.limitNum) {
      clientQ.limit(this.limitNum);
    }
    return clientQ.get();
  }
};
var ClientDocRefAdapter = class {
  constructor(colName, id) {
    this.colName = colName;
    if (id) {
      this.id = id;
    } else {
      this.id = (0, import_firestore2.doc)((0, import_firestore2.collection)(cDb, colName)).id;
    }
    this.path = `${colName}/${this.id}`;
  }
  async get() {
    try {
      const dRef = (0, import_firestore2.doc)(cDb, this.colName, this.id);
      const snap = await (0, import_firestore2.getDoc)(dRef);
      return {
        exists: snap.exists(),
        id: snap.id,
        data: () => snap.data() || {}
      };
    } catch (err) {
      console.error(`[FirebaseBridge] Error reading document ${this.path}:`, err?.message || err);
      throw err;
    }
  }
  async set(data, options) {
    try {
      const dRef = (0, import_firestore2.doc)(cDb, this.colName, this.id);
      await (0, import_firestore2.setDoc)(dRef, sanitizeDataForClient(data), options || {});
    } catch (err) {
      console.error(`[FirebaseBridge] Error writing document ${this.path}:`, err?.message || err);
      throw err;
    }
  }
  async update(data) {
    try {
      const dRef = (0, import_firestore2.doc)(cDb, this.colName, this.id);
      await (0, import_firestore2.updateDoc)(dRef, sanitizeDataForClient(data));
    } catch (err) {
      console.error(`[FirebaseBridge] Error updating document ${this.path}:`, err?.message || err);
      throw err;
    }
  }
  async delete() {
    try {
      const dRef = (0, import_firestore2.doc)(cDb, this.colName, this.id);
      await (0, import_firestore2.deleteDoc)(dRef);
    } catch (err) {
      console.error(`[FirebaseBridge] Error deleting document ${this.path}:`, err?.message || err);
      throw err;
    }
  }
};
var ClientBatchAdapter = class {
  constructor() {
    this.batch = (0, import_firestore2.writeBatch)(cDb);
  }
  set(docRef, data, options) {
    const dRef = (0, import_firestore2.doc)(cDb, docRef.path);
    this.batch.set(dRef, sanitizeDataForClient(data), options || {});
    return this;
  }
  update(docRef, data) {
    const dRef = (0, import_firestore2.doc)(cDb, docRef.path);
    this.batch.update(dRef, sanitizeDataForClient(data));
    return this;
  }
  delete(docRef) {
    const dRef = (0, import_firestore2.doc)(cDb, docRef.path);
    this.batch.delete(dRef);
    return this;
  }
  async commit() {
    await this.batch.commit();
  }
};
function unwrapDocumentReference(ref) {
  if (!ref) return ref;
  if (ref._rawRef) return ref._rawRef;
  if (typeof ref === "object" && (ref.constructor?.name === "DocumentReference" || typeof ref.get === "function")) {
    if (ref.path && hasAdminCredential && rawAdminDb && !(ref instanceof rawAdminDb.collection("dummy").doc().constructor)) {
      return rawAdminDb.doc(ref.path);
    }
    return ref;
  }
  if (ref.path && hasAdminCredential && rawAdminDb) {
    return rawAdminDb.doc(ref.path);
  }
  return ref;
}
var adminDb = {
  collection(colName) {
    return {
      doc(id) {
        if (hasAdminCredential && rawAdminDb) {
          const rawDoc = id ? rawAdminDb.collection(colName).doc(id) : rawAdminDb.collection(colName).doc();
          return rawDoc;
        }
        return new ClientDocRefAdapter(colName, id);
      },
      where(field, op, val) {
        const rawQ = hasAdminCredential && rawAdminDb ? rawAdminDb.collection(colName).where(field, op, val) : null;
        return new AdminQueryAdapter(colName, rawQ, { field, op, val });
      },
      orderBy(field, dir = "asc") {
        const rawQ = hasAdminCredential && rawAdminDb ? rawAdminDb.collection(colName).orderBy(field, dir) : null;
        const adapter = new AdminQueryAdapter(colName, rawQ);
        return adapter.orderBy(field, dir);
      },
      limit(num) {
        const rawQ = hasAdminCredential && rawAdminDb ? rawAdminDb.collection(colName).limit(num) : null;
        const adapter = new AdminQueryAdapter(colName, rawQ);
        return adapter.limit(num);
      },
      startAfter(cursor) {
        const rawQ = hasAdminCredential && rawAdminDb ? rawAdminDb.collection(colName) : null;
        const adapter = new AdminQueryAdapter(colName, rawQ);
        return adapter.startAfter(cursor);
      },
      async get() {
        const rawQ = hasAdminCredential && rawAdminDb ? rawAdminDb.collection(colName) : null;
        const adapter = new AdminQueryAdapter(colName, rawQ);
        return adapter.get();
      },
      async add(data) {
        if (hasAdminCredential && rawAdminDb) {
          try {
            return await rawAdminDb.collection(colName).add(data);
          } catch (e) {
            if (!e.message?.includes("PERMISSION_DENIED") && e.code !== 7) {
              throw e;
            }
          }
        }
        const docRef = await (0, import_firestore2.addDoc)((0, import_firestore2.collection)(cDb, colName), sanitizeDataForClient(data));
        return { id: docRef.id, path: docRef.path };
      }
    };
  },
  doc(docPath) {
    if (hasAdminCredential && rawAdminDb) {
      return rawAdminDb.doc(docPath);
    }
    const [colName, ...idParts] = docPath.split("/");
    return new ClientDocRefAdapter(colName, idParts.join("/"));
  },
  batch() {
    if (hasAdminCredential && rawAdminDb) {
      const rawBatch = rawAdminDb.batch();
      return {
        set(docRef, data, options) {
          return rawBatch.set(unwrapDocumentReference(docRef), data, options || {});
        },
        update(docRef, data, ...more) {
          return rawBatch.update(unwrapDocumentReference(docRef), data, ...more);
        },
        delete(docRef) {
          return rawBatch.delete(unwrapDocumentReference(docRef));
        },
        commit() {
          return rawBatch.commit();
        }
      };
    }
    return new ClientBatchAdapter();
  },
  async runTransaction(updateFunction) {
    if (hasAdminCredential && rawAdminDb) {
      return await rawAdminDb.runTransaction(async (rawTxn) => {
        const txnWrapper = {
          get(docRef) {
            return rawTxn.get(unwrapDocumentReference(docRef));
          },
          set(docRef, data, options) {
            return rawTxn.set(unwrapDocumentReference(docRef), data, options || {});
          },
          update(docRef, data, ...more) {
            return rawTxn.update(unwrapDocumentReference(docRef), data, ...more);
          },
          delete(docRef) {
            return rawTxn.delete(unwrapDocumentReference(docRef));
          }
        };
        return await updateFunction(txnWrapper);
      });
    }
    const txAdapter = {
      async get(docRef) {
        return await docRef.get();
      },
      update(docRef, data) {
        return docRef.update(data);
      },
      set(docRef, data, options) {
        return docRef.set(data, options);
      },
      delete(docRef) {
        return docRef.delete();
      }
    };
    return await updateFunction(txAdapter);
  }
};
var adminAuth = {
  async createCustomToken(uid, developerClaims) {
    if (hasAdminCredential && rawAdminAuth) {
      try {
        return await rawAdminAuth.createCustomToken(uid, developerClaims);
      } catch (err) {
        console.warn("[AdminAuth] createCustomToken error:", err.message);
        return null;
      }
    }
    return null;
  },
  async verifyIdToken(token) {
    if (!token || typeof token !== "string") {
      throw new Error("[Security Error] Token kh\xF4ng h\u1EE3p l\u1EC7.");
    }
    if (token.startsWith("dev_token_")) {
      throw new Error("[Security Error] T\u1EEB ch\u1ED1i token gi\u1EA3 l\u1EADp (dev_token) - c\u01A1 ch\u1EBF b\u1ECB lo\u1EA1i b\u1ECF ho\xE0n to\xE0n.");
    }
    if (hasAdminCredential && rawAdminAuth) {
      return await rawAdminAuth.verifyIdToken(token);
    }
    throw new Error("[Security Error] Firebase Admin SDK ch\u01B0a \u0111\u01B0\u1EE3c c\u1EA5u h\xECnh Service Account h\u1EE3p l\u1EC7 \u0111\u1EC3 x\xE1c minh ch\u1EEF k\xFD token.");
  },
  async revokeRefreshTokens(uid) {
    if (hasAdminCredential && rawAdminAuth) {
      try {
        await rawAdminAuth.revokeRefreshTokens(uid);
      } catch (err) {
        console.warn("[AdminAuth] revokeRefreshTokens error for uid:", uid, err?.message || err);
      }
    }
  }
};
var safeDeleteSentinel = import_firestore.FieldValue.delete;

// api/_crypto.ts
var import_node_crypto = __toESM(require("node:crypto"), 1);
var getDataEncryptionKey = () => {
  const secret = process.env.DATA_ENCRYPTION_KEY || process.env.ENCRYPTION_KEY;
  if (!secret || secret.trim().length === 0) {
    throw new Error("[Security Error] Thi\u1EBFu c\u1EA5u h\xECnh DATA_ENCRYPTION_KEY ho\u1EB7c ENCRYPTION_KEY trong bi\u1EBFn m\xF4i tr\u01B0\u1EDDng. H\u1EC7 th\u1ED1ng t\u1EEB ch\u1ED1i s\u1EED d\u1EE5ng kh\xF3a m\u1EB7c \u0111\u1ECBnh ho\u1EB7c t\u1EA1o kh\xF3a ng\u1EABu nhi\xEAn l\xE0m m\u1EA5t d\u1EEF li\u1EC7u m\xE3 h\xF3a c\u0169.");
  }
  return import_node_crypto.default.createHash("sha256").update(secret.trim()).digest();
};
function hashPassword(password) {
  const salt = import_node_crypto.default.randomBytes(16).toString("hex");
  const hash = import_node_crypto.default.scryptSync(password.trim(), salt, 64).toString("hex");
  return `${salt}:${hash}`;
}
function verifyPassword(password, storedHash) {
  try {
    const parts = storedHash.split(":");
    if (parts.length !== 2) return false;
    const [salt, originalHash] = parts;
    const computedHash = import_node_crypto.default.scryptSync(password.trim(), salt, 64).toString("hex");
    return import_node_crypto.default.timingSafeEqual(Buffer.from(computedHash, "hex"), Buffer.from(originalHash, "hex"));
  } catch (e) {
    return false;
  }
}
function encryptAes(plainText) {
  const key = getDataEncryptionKey();
  const iv = import_node_crypto.default.randomBytes(12);
  const cipher = import_node_crypto.default.createCipheriv("aes-256-gcm", key, iv);
  let encrypted = cipher.update(plainText.trim(), "utf8", "hex");
  encrypted += cipher.final("hex");
  const authTag = cipher.getAuthTag().toString("hex");
  return `${iv.toString("hex")}:${authTag}:${encrypted}`;
}
function decryptAes(cipherText) {
  try {
    const parts = cipherText.split(":");
    if (parts.length !== 3) return null;
    const [ivHex, authTagHex, encrypted] = parts;
    const key = getDataEncryptionKey();
    const decipher = import_node_crypto.default.createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(authTagHex, "hex"));
    let decrypted = decipher.update(encrypted, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  } catch (e) {
    return null;
  }
}

// api/_token.ts
var import_node_crypto2 = __toESM(require("node:crypto"), 1);
var getSecretKey = () => {
  const secret = process.env.JWT_SECRET || process.env.ENCRYPTION_KEY;
  if (!secret || secret.trim().length === 0) {
    throw new Error("[Security Error] Thi\u1EBFu c\u1EA5u h\xECnh JWT_SECRET ho\u1EB7c ENCRYPTION_KEY trong bi\u1EBFn m\xF4i tr\u01B0\u1EDDng. H\u1EC7 th\u1ED1ng t\u1EEB ch\u1ED1i s\u1EED d\u1EE5ng kh\xF3a m\u1EB7c \u0111\u1ECBnh c\u1EE9ng.");
  }
  return import_node_crypto2.default.createHash("sha256").update(secret.trim()).digest();
};
var getFallbackSecretKey = () => {
  const encKey = process.env.ENCRYPTION_KEY;
  if (encKey && encKey.trim().length > 0 && encKey.trim() !== process.env.JWT_SECRET?.trim()) {
    return import_node_crypto2.default.createHash("sha256").update(encKey.trim()).digest();
  }
  return null;
};
var userStatusCache = /* @__PURE__ */ new Map();
var STATUS_CACHE_TTL_MS = 3e3;
function invalidateUserStatusCache(userId) {
  if (userId) {
    userStatusCache.delete(userId);
  } else {
    userStatusCache.clear();
  }
}
async function getUserAccountStatus(userId, forceFresh = false) {
  if (!userId) return null;
  if (userId === "superadmin") {
    return { exists: true, tokenVersion: 1, role: "superadmin", storeId: "superadmin", cachedAt: Date.now() };
  }
  if (!forceFresh) {
    const cached = userStatusCache.get(userId);
    if (cached && Date.now() - cached.cachedAt < STATUS_CACHE_TTL_MS) {
      return cached;
    }
  }
  try {
    const [secretDoc, userDoc] = await Promise.all([
      adminDb.collection("user_secrets").doc(userId).get().catch(() => null),
      adminDb.collection("users").doc(userId).get().catch(() => null)
    ]);
    const userExists = Boolean(userDoc && userDoc.exists || secretDoc && secretDoc.exists);
    if (!userExists) {
      userStatusCache.set(userId, { exists: false, tokenVersion: 0, role: "", storeId: "", cachedAt: Date.now() });
      return null;
    }
    const secretData = secretDoc && secretDoc.exists ? secretDoc.data() || {} : {};
    const userData = userDoc && userDoc.exists ? userDoc.data() || {} : {};
    const tokenVersion = Number(secretData.tokenVersion || userData.tokenVersion || 1);
    const role = String(secretData.role || userData.role || "order");
    const storeId = String(secretData.storeId || userData.storeId || "");
    const status = {
      exists: true,
      tokenVersion,
      role,
      storeId,
      cachedAt: Date.now()
    };
    userStatusCache.set(userId, status);
    return status;
  } catch (err) {
    console.warn("[Auth] Failed to fetch user account status for revocation check:", err);
    return null;
  }
}
function generateAuthToken(payload) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const nowSec = Math.floor(Date.now() / 1e3);
  const data = {
    ...payload,
    isSuperAdmin: Boolean(payload.isSuperAdmin || payload.role === "superadmin"),
    tokenVersion: payload.tokenVersion ? Number(payload.tokenVersion) : 1,
    iat: nowSec,
    exp: nowSec + 7 * 24 * 60 * 60
    // 7 ngày
  };
  const body = Buffer.from(JSON.stringify(data)).toString("base64url");
  const key = getSecretKey();
  const signature = import_node_crypto2.default.createHmac("sha256", key).update(`${header}.${body}`).digest("base64url");
  return `${header}.${body}.${signature}`;
}
function extractBearerToken(req) {
  let authHeader = req.headers?.authorization || req.headers?.Authorization || "";
  if (Array.isArray(authHeader)) authHeader = authHeader[0] || "";
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    return authHeader.substring(7).trim();
  }
  const xToken = req.headers?.["x-auth-token"];
  if (typeof xToken === "string" && xToken.trim()) {
    return xToken.trim();
  }
  return null;
}
async function verifyAuthToken(token, options) {
  if (!token || typeof token !== "string") return null;
  if (token.startsWith("dev_token_")) {
    console.warn("[Auth Security] Rejected mock token attempt:", token);
    return null;
  }
  let unverifiedCaller = null;
  const parts = token.split(".");
  if (parts.length === 3) {
    const [header, body, signature] = parts;
    try {
      const key = getSecretKey();
      let isValidSig = false;
      const expectedSig = import_node_crypto2.default.createHmac("sha256", key).update(`${header}.${body}`).digest("base64url");
      if (import_node_crypto2.default.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
        isValidSig = true;
      } else {
        const fallbackKey = getFallbackSecretKey();
        if (fallbackKey) {
          const fallbackSig = import_node_crypto2.default.createHmac("sha256", fallbackKey).update(`${header}.${body}`).digest("base64url");
          if (import_node_crypto2.default.timingSafeEqual(Buffer.from(signature), Buffer.from(fallbackSig))) {
            isValidSig = true;
          }
        }
      }
      if (isValidSig) {
        const payloadJson = Buffer.from(body, "base64url").toString("utf8");
        const payload = JSON.parse(payloadJson);
        const nowSec = Math.floor(Date.now() / 1e3);
        if (payload.exp && payload.exp < nowSec) {
          console.warn("[Auth] Token expired at:", payload.exp);
          return null;
        }
        if (payload.uid && payload.role) {
          unverifiedCaller = {
            uid: String(payload.uid),
            username: payload.username ? String(payload.username) : void 0,
            role: String(payload.role),
            storeId: String(payload.storeId || ""),
            isSuperAdmin: Boolean(payload.isSuperAdmin || payload.role === "superadmin"),
            tokenVersion: payload.tokenVersion ? Number(payload.tokenVersion) : 1
          };
        }
      }
    } catch (e) {
      if (e.message?.includes("[Security Error]")) {
        console.error(e.message);
        throw e;
      }
    }
  }
  if (!unverifiedCaller && hasAdminCredential) {
    try {
      const decoded = await adminAuth.verifyIdToken(token);
      if (decoded && decoded.uid) {
        const verifiedRole = decoded.role || (decoded.uid === "superadmin" ? "superadmin" : null);
        if (!verifiedRole) {
          console.warn("[Auth Security] Firebase ID token thi\u1EBFu claim 'role' h\u1EE3p l\u1EC7. T\u1EEB ch\u1ED1i c\u1EA5p quy\u1EC1n.");
          return null;
        }
        unverifiedCaller = {
          uid: decoded.uid,
          role: verifiedRole,
          storeId: decoded.storeId || "",
          isSuperAdmin: Boolean(verifiedRole === "superadmin" || decoded.isSuperAdmin || decoded.uid === "superadmin"),
          tokenVersion: decoded.tokenVersion ? Number(decoded.tokenVersion) : 1
        };
      }
    } catch (e) {
      return null;
    }
  }
  if (!unverifiedCaller) return null;
  if (unverifiedCaller.uid === "superadmin") {
    const expectedSuperPass = process.env.SUPERADMIN_PASSWORD;
    if (!expectedSuperPass || expectedSuperPass.trim().length === 0) {
      console.warn("[Auth Revocation] SuperAdmin endpoint b\u1ECB v\xF4 hi\u1EC7u h\xF3a v\xEC thi\u1EBFu SUPERADMIN_PASSWORD.");
      return null;
    }
    return unverifiedCaller;
  }
  const accountStatus = await getUserAccountStatus(unverifiedCaller.uid, options?.forceFresh);
  if (!accountStatus || !accountStatus.exists) {
    console.warn(`[Auth Revocation] T\xE0i kho\u1EA3n ${unverifiedCaller.uid} kh\xF4ng t\u1ED3n t\u1EA1i ho\u1EB7c \u0111\xE3 b\u1ECB x\xF3a.`);
    return null;
  }
  const callerVersion = Number(unverifiedCaller.tokenVersion || 1);
  if (callerVersion < accountStatus.tokenVersion) {
    console.warn(`[Auth Revocation] Phi\xEAn \u0111\u0103ng nh\u1EADp c\u1EE7a t\xE0i kho\u1EA3n ${unverifiedCaller.uid} \u0111\xE3 b\u1ECB thu h\u1ED3i (token v${callerVersion} < server v${accountStatus.tokenVersion}).`);
    return null;
  }
  if (accountStatus.role && unverifiedCaller.role !== accountStatus.role) {
    console.warn(`[Auth Revocation] Vai tr\xF2 c\u1EE7a t\xE0i kho\u1EA3n ${unverifiedCaller.uid} \u0111\xE3 thay \u0111\u1ED5i (${unverifiedCaller.role} -> ${accountStatus.role}). Thu h\u1ED3i token c\u0169.`);
    return null;
  }
  return {
    ...unverifiedCaller,
    role: accountStatus.role,
    storeId: accountStatus.storeId || unverifiedCaller.storeId,
    tokenVersion: accountStatus.tokenVersion
  };
}
async function getAuthenticatedCaller(req, options) {
  const token = extractBearerToken(req);
  if (!token) return null;
  return await verifyAuthToken(token, options);
}

// api/login.ts
var import_firestore3 = require("firebase-admin/firestore");
var loginFailAttempts = /* @__PURE__ */ new Map();
setInterval(() => {
  const now = Date.now();
  for (const [key, attempt] of loginFailAttempts.entries()) {
    if (attempt.lockedUntil < now && now - attempt.lastAttempt > 30 * 60 * 1e3) {
      loginFailAttempts.delete(key);
    }
  }
}, 5 * 60 * 1e3);
async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { storeCode, username, password } = req.body || {};
  if (!storeCode || !username || !password) {
    return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p \u0111\u1EA7y \u0111\u1EE7 M\xE3 c\u1EEDa h\xE0ng, T\xEAn \u0111\u0103ng nh\u1EADp v\xE0 M\u1EADt kh\u1EA9u" });
  }
  const cleanStoreCode = String(storeCode).toLowerCase().trim();
  const cleanUsername = String(username).toLowerCase().trim();
  const cleanPassword = String(password).trim();
  const clientIp = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown";
  const rateLimitKey = `${clientIp}_${cleanStoreCode}_${cleanUsername}`;
  const currentAttempts = loginFailAttempts.get(rateLimitKey);
  const now = Date.now();
  if (currentAttempts && currentAttempts.lockedUntil > now) {
    const remainingMinutes = Math.ceil((currentAttempts.lockedUntil - now) / 6e4);
    return res.status(429).json({
      error: `T\xE0i kho\u1EA3n \u0111\xE3 b\u1ECB t\u1EA1m kh\xF3a do nh\u1EADp sai m\u1EADt kh\u1EA9u qu\xE1 5 l\u1EA7n. Vui l\xF2ng th\u1EED l\u1EA1i sau ${remainingMinutes} ph\xFAt.`
    });
  }
  try {
    const expectedSuperUser = process.env.SUPERADMIN_USERNAME || "superadmin";
    const expectedSuperPass = process.env.SUPERADMIN_PASSWORD;
    if (cleanStoreCode === "admin" && cleanUsername === expectedSuperUser) {
      if (!expectedSuperPass || expectedSuperPass.trim().length === 0) {
        console.error("[Auth Security] \u0110\u0103ng nh\u1EADp SuperAdmin b\u1ECB t\u1EEB ch\u1ED1i: Bi\u1EBFn m\xF4i tr\u01B0\u1EDDng SUPERADMIN_PASSWORD ch\u01B0a \u0111\u01B0\u1EE3c c\u1EA5u h\xECnh tr\xEAn m\xE1y ch\u1EE7.");
        return res.status(401).json({
          error: "T\xEDnh n\u0103ng \u0111\u0103ng nh\u1EADp Qu\u1EA3n tr\u1ECB vi\xEAn t\u1ED1i cao ch\u01B0a \u0111\u01B0\u1EE3c k\xEDch ho\u1EA1t c\u1EA5u h\xECnh an to\xE0n tr\xEAn m\xE1y ch\u1EE7."
        });
      }
      if (cleanPassword === expectedSuperPass.trim()) {
        loginFailAttempts.delete(rateLimitKey);
        const sessionToken2 = generateAuthToken({
          uid: "superadmin",
          username: expectedSuperUser,
          role: "superadmin",
          storeId: "superadmin",
          isSuperAdmin: true,
          tokenVersion: 1
        });
        const customToken2 = await adminAuth.createCustomToken("superadmin", {
          role: "superadmin",
          isSuperAdmin: true,
          storeId: "superadmin",
          tokenVersion: 1
        });
        return res.status(200).json({
          success: true,
          token: sessionToken2,
          customToken: customToken2,
          user: {
            id: "superadmin",
            username: expectedSuperUser,
            name: "Super Admin",
            role: "superadmin",
            storeId: "superadmin",
            token: sessionToken2
          }
        });
      } else {
        recordFailedAttempt(rateLimitKey);
        return res.status(401).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng" });
      }
    }
    const storeQuery = await adminDb.collection("stores").where("code", "==", cleanStoreCode).limit(1).get();
    if (storeQuery.empty) {
      return res.status(404).json({ error: "M\xE3 c\u1EEDa h\xE0ng kh\xF4ng t\u1ED3n t\u1EA1i" });
    }
    const storeDoc = storeQuery.docs[0];
    const storeId = storeDoc.id;
    const storeData = storeDoc.data();
    if (storeData.subscription && storeData.subscription.status === "blocked") {
      return res.status(403).json({ error: "C\u1EEDa h\xE0ng \u0111\xE3 b\u1ECB kh\xF3a. Vui l\xF2ng li\xEAn h\u1EC7 Admin \u0111\u1EC3 \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3." });
    }
    const userQuery = await adminDb.collection("users").where("storeId", "==", storeId).where("username", "==", cleanUsername).limit(1).get();
    if (userQuery.empty) {
      recordFailedAttempt(rateLimitKey);
      return res.status(401).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng" });
    }
    const userDoc = userQuery.docs[0];
    const userData = userDoc.data();
    const userId = userDoc.id;
    let secretDoc = null;
    let fallbackToLegacy = false;
    try {
      const secretRef = adminDb.collection("user_secrets").doc(userId);
      secretDoc = await secretRef.get();
    } catch (readErr) {
      console.warn("[Login Auth Warning] Kh\xF4ng th\u1EC3 \u0111\u1ECDc user_secrets c\u1EE7a userId:", userId, readErr?.message || readErr);
      if (userData.password && String(userData.password).trim() === cleanPassword) {
        fallbackToLegacy = true;
      } else {
        return res.status(503).json({
          error: "D\u1ECBch v\u1EE5 x\xE1c th\u1EF1c t\u1EA1m th\u1EDDi kh\xF4ng kh\u1EA3 d\u1EE5ng. Vui l\xF2ng th\u1EED l\u1EA1i sau gi\xE2y l\xE1t."
        });
      }
    }
    const hasStoredSecret = Boolean(secretDoc && secretDoc.exists);
    const secretData = hasStoredSecret ? secretDoc.data() || {} : null;
    const hasStoredHash = Boolean(secretData && (secretData.passwordHash || secretData.encryptedPassword));
    let isPasswordValid = fallbackToLegacy;
    let tokenVersion = secretData?.tokenVersion ? Number(secretData.tokenVersion) : 1;
    if (!fallbackToLegacy && hasStoredHash) {
      if (secretData.passwordHash) {
        isPasswordValid = verifyPassword(cleanPassword, secretData.passwordHash);
      } else if (secretData.encryptedPassword) {
        const decrypted = decryptAes(secretData.encryptedPassword);
        isPasswordValid = decrypted === cleanPassword;
      }
      if (!isPasswordValid) {
        recordFailedAttempt(rateLimitKey);
        return res.status(401).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng" });
      }
      if (userData.password) {
        try {
          await adminDb.collection("users").doc(userId).update({
            password: import_firestore3.FieldValue.delete(),
            isLegacy: import_firestore3.FieldValue.delete()
          });
        } catch (_) {
        }
      }
    } else {
      if (userData.password && String(userData.password).trim() === cleanPassword) {
        isPasswordValid = true;
        try {
          const passwordHash = hashPassword(cleanPassword);
          const secretPayload = {
            userId,
            storeId,
            role: userData.role,
            passwordHash,
            tokenVersion: 1,
            migratedAt: (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          if (userData.role === "admin") {
            secretPayload.encryptedPassword = encryptAes(cleanPassword);
          }
          await adminDb.collection("user_secrets").doc(userId).set(secretPayload);
        } catch (migErr) {
          console.warn("[Auth] Migration hash notice:", migErr);
        }
      } else {
        recordFailedAttempt(rateLimitKey);
        return res.status(401).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng" });
      }
    }
    if (!isPasswordValid) {
      recordFailedAttempt(rateLimitKey);
      return res.status(401).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng" });
    }
    loginFailAttempts.delete(rateLimitKey);
    try {
      await adminDb.collection("users").doc(userId).update({
        lastLogin: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (e) {
    }
    const sessionToken = generateAuthToken({
      uid: userId,
      username: cleanUsername,
      role: userData.role,
      storeId,
      isSuperAdmin: false,
      tokenVersion
    });
    const customToken = await adminAuth.createCustomToken(userId, {
      storeId,
      role: userData.role,
      isSuperAdmin: false,
      tokenVersion
    });
    if ((process.env.NODE_ENV === "production" || process.env.REQUIRE_ADMIN_AUTH === "true") && !customToken) {
      console.error("[Login Security] Firebase Admin SDK ch\u01B0a \u0111\u01B0\u1EE3c c\u1EA5u h\xECnh Service Account \u0111\u1EC3 t\u1EA1o customToken trong m\xF4i tr\u01B0\u1EDDng production.");
      return res.status(503).json({
        error: "M\xE1y ch\u1EE7 ch\u01B0a \u0111\u01B0\u1EE3c c\u1EA5u h\xECnh Firebase Admin SDK Service Account \u0111\u1EC3 kh\u1EDFi t\u1EA1o phi\xEAn \u0111\u0103ng nh\u1EADp b\u1EA3o m\u1EADt."
      });
    }
    const sanitizedUserData = { ...userData };
    delete sanitizedUserData.password;
    return res.status(200).json({
      success: true,
      token: sessionToken,
      customToken,
      hasAdminAuth: Boolean(customToken),
      user: {
        id: userId,
        token: sessionToken,
        ...sanitizedUserData,
        store: storeData
      }
    });
  } catch (error) {
    console.error("Login API error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi x\u1EED l\xFD \u0111\u0103ng nh\u1EADp" });
  }
}
function recordFailedAttempt(key) {
  const now = Date.now();
  const attempt = loginFailAttempts.get(key) || { count: 0, lockedUntil: 0, lastAttempt: now };
  attempt.count += 1;
  attempt.lastAttempt = now;
  if (attempt.count >= 5) {
    attempt.lockedUntil = now + 10 * 60 * 1e3;
    attempt.count = 0;
  }
  loginFailAttempts.set(key, attempt);
}

// api/reveal-password.ts
async function handler2(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const clientIp = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown";
  try {
    const caller = await getAuthenticatedCaller(req);
    if (!caller || !caller.isSuperAdmin) {
      return res.status(403).json({
        error: "T\u1EEB ch\u1ED1i truy c\u1EADp: Ch\u1EC9 Qu\u1EA3n tr\u1ECB vi\xEAn t\u1ED1i cao (Super Admin) \u0111\xE3 x\xE1c th\u1EF1c m\u1EDBi c\xF3 quy\u1EC1n th\u1EF1c hi\u1EC7n thao t\xE1c n\xE0y."
      });
    }
    const { storeId, storeCode } = req.body || {};
    if (!storeId && !storeCode) {
      return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p storeId ho\u1EB7c storeCode c\u1EE7a c\u1EEDa h\xE0ng c\u1EA7n tra c\u1EE9u" });
    }
    let storeDoc = null;
    if (storeId) {
      const snap = await adminDb.collection("stores").doc(storeId).get();
      if (snap && snap.exists) storeDoc = snap;
    }
    if (!storeDoc && storeCode) {
      const snap = await adminDb.collection("stores").where("code", "==", String(storeCode).toLowerCase().trim()).limit(1).get();
      if (snap && !snap.empty) storeDoc = snap.docs[0];
    }
    if (!storeDoc) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y c\u1EEDa h\xE0ng" });
    }
    const targetStoreId = storeDoc.id;
    const storeData = storeDoc.data();
    const adminUserQuery = await adminDb.collection("users").where("storeId", "==", targetStoreId).where("role", "==", "admin").limit(1).get();
    if (adminUserQuery.empty) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y t\xE0i kho\u1EA3n Qu\u1EA3n tr\u1ECB vi\xEAn c\u1EE7a c\u1EEDa h\xE0ng n\xE0y" });
    }
    const adminUserDoc = adminUserQuery.docs[0];
    const adminUserData = adminUserDoc.data();
    const adminUserId = adminUserDoc.id;
    const secretSnap = await adminDb.collection("user_secrets").doc(adminUserId).get();
    let plainPassword = "";
    if (secretSnap.exists && secretSnap.data()?.encryptedPassword) {
      const decrypted = decryptAes(secretSnap.data().encryptedPassword);
      if (decrypted) {
        plainPassword = decrypted;
      }
    }
    if (!plainPassword && adminUserData.password) {
      plainPassword = adminUserData.password;
    }
    if (!plainPassword) {
      return res.status(404).json({
        error: "M\u1EADt kh\u1EA9u t\xE0i kho\u1EA3n \u0111\xE3 \u0111\u01B0\u1EE3c b\u1EA3o m\u1EADt m\u1ED9t chi\u1EC1u ho\u1EB7c ch\u01B0a t\u1EEBng \u0111\u01B0\u1EE3c c\u1EA5p kh\xF3a kh\xF4i ph\u1EE5c. Vui l\xF2ng s\u1EED d\u1EE5ng t\xEDnh n\u0103ng \u0110\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u (Reset Password) \u0111\u1EC3 h\u1ED7 tr\u1EE3 ch\u1EE7 qu\xE1n."
      });
    }
    try {
      await adminDb.collection("admin_audit_logs").add({
        action: "REVEAL_ADMIN_PASSWORD",
        targetStoreId,
        targetStoreCode: storeData.code || "",
        targetUserId: adminUserId,
        targetUsername: adminUserData.username || "",
        performedByUid: caller.uid,
        performedByUsername: caller.username || "superadmin",
        clientIp: String(clientIp),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (auditErr) {
      console.warn("[Audit] Failed to write reveal-password audit log:", auditErr);
    }
    return res.status(200).json({
      success: true,
      storeName: storeData.name,
      storeCode: storeData.code,
      adminUsername: adminUserData.username,
      adminName: adminUserData.name,
      password: plainPassword
    });
  } catch (error) {
    console.error("Reveal password error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi tra c\u1EE9u th\xF4ng tin: " + error.message });
  }
}

// api/sepay-webhook.ts
async function handler3(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const expectedToken = process.env.SEPAY_API_TOKEN;
  if (!expectedToken) {
    console.error("CRITICAL: SEPAY_API_TOKEN is not configured in environment variables!");
    return res.status(500).json({ error: "Server payment configuration error" });
  }
  if (!hasAdminCredential) {
    console.error("CRITICAL: Firebase Admin credentials not configured. Refusing non-atomic payment transaction.");
    return res.status(503).json({ error: "M\xE1y ch\u1EE7 ch\u01B0a \u0111\u01B0\u1EE3c k\xEDch ho\u1EA1t Firebase Admin SDK Service Account \u0111\u1EC3 x\u1EED l\xFD giao d\u1ECBch thanh to\xE1n nguy\xEAn t\u1EED." });
  }
  let authHeader = req.headers.authorization || req.headers["x-api-key"] || "";
  if (Array.isArray(authHeader)) authHeader = authHeader[0] || "";
  if (authHeader.startsWith("Apikey ")) authHeader = authHeader.substring(7);
  else if (authHeader.startsWith("Bearer ")) authHeader = authHeader.substring(7);
  if (authHeader.trim() !== expectedToken.trim()) {
    console.warn("Unauthorized SePay webhook access attempt blocked.");
    return res.status(401).json({ error: "Unauthorized - Invalid API Key" });
  }
  try {
    const data = req.body || {};
    if (data.transferType !== "in") {
      return res.status(200).json({ success: true, message: "Ignored: Not an incoming transfer" });
    }
    const txId = String(data.id || data.referenceCode || "").trim();
    if (!txId) {
      return res.status(400).json({ error: "Missing transaction ID" });
    }
    const amount = Number(data.transferAmount || data.amount || 0);
    if (isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: "Invalid transfer amount" });
    }
    const txRef = adminDb.collection("processed_transactions").doc(txId);
    const existingTx = await txRef.get();
    if (existingTx.exists) {
      return res.status(200).json({ success: true, message: "Transaction already processed previously" });
    }
    const content = String(data.content || "").toUpperCase();
    if (!content.includes("GIAHAN")) {
      return res.status(200).json({ success: true, message: "No renewal command in transfer content" });
    }
    const match = content.match(/(?:SEVQR\s+)?([A-Z0-9_-]+)\s+GIAHAN(?:\s+([A-Z0-9_-]+))?(?:\s+([0-9]+))?/i);
    if (!match || !match[1]) {
      return res.status(200).json({ success: true, message: "Cannot parse store code from content" });
    }
    let rawStoreCode = match[1].trim();
    if (rawStoreCode.toUpperCase() === "SEVQR" && match[2]) {
      rawStoreCode = match[2].trim();
    }
    const storeCode = rawStoreCode.toLowerCase();
    const storesQuery = await adminDb.collection("stores").where("code", "==", storeCode).limit(1).get();
    if (storesQuery.empty) {
      console.warn(`SePay Webhook: Store code not found: ${storeCode}`);
      return res.status(200).json({ success: false, message: `Store code not found: ${storeCode}` });
    }
    const storeDoc = storesQuery.docs[0];
    const storeId = storeDoc.id;
    const storeData = storeDoc.data();
    const pkgsSnapshot = await adminDb.collection("packages").get();
    let matchedPackageId = "pro";
    let durationMonths = 1;
    let foundPricingMatch = false;
    pkgsSnapshot.forEach((docSnap) => {
      const pkg = docSnap.data();
      const pkgId = docSnap.id;
      if (pkg.pricing && Array.isArray(pkg.pricing)) {
        pkg.pricing.forEach((opt) => {
          if (amount >= opt.price && opt.durationMonths) {
            if (!foundPricingMatch || opt.durationMonths > durationMonths) {
              matchedPackageId = pkgId;
              durationMonths = opt.durationMonths;
              foundPricingMatch = true;
            }
          }
        });
      } else if (pkg.price && amount >= pkg.price) {
        matchedPackageId = pkgId;
        durationMonths = pkg.durationMonths || 1;
        foundPricingMatch = true;
      }
    });
    if (!foundPricingMatch) {
      durationMonths = Math.min(Math.max(1, Math.floor(amount / 99e3)), 24);
    }
    let baseDate = /* @__PURE__ */ new Date();
    const currentValidUntil = storeData.subscription?.validUntil;
    if (currentValidUntil) {
      const currentEnd = new Date(currentValidUntil);
      if (!isNaN(currentEnd.getTime()) && currentEnd > baseDate) {
        baseDate = currentEnd;
      }
    }
    const newEndDate = new Date(baseDate);
    newEndDate.setMonth(newEndDate.getMonth() + durationMonths);
    await adminDb.runTransaction(async (transaction) => {
      const checkTx = await transaction.get(txRef);
      if (checkTx.exists) {
        throw new Error("TRANSACTION_ALREADY_PROCESSED");
      }
      transaction.update(adminDb.collection("stores").doc(storeId), {
        "subscription.status": "active",
        "subscription.packageId": matchedPackageId,
        "subscription.validUntil": newEndDate.toISOString(),
        "subscription.lastRenewedAt": (/* @__PURE__ */ new Date()).toISOString()
      });
      transaction.set(txRef, {
        txId,
        storeId,
        storeCode,
        amount,
        durationMonths,
        packageId: matchedPackageId,
        processedAt: (/* @__PURE__ */ new Date()).toISOString(),
        gateway: "sepay"
      });
    });
    console.log(`[SePay Webhook] Successfully extended ${durationMonths} month(s) for store: ${storeCode}`);
    return res.status(200).json({
      success: true,
      message: `Extended ${durationMonths} month(s) for store ${storeCode}`
    });
  } catch (err) {
    if (err?.message === "TRANSACTION_ALREADY_PROCESSED") {
      return res.status(200).json({ success: true, message: "Already processed concurrently" });
    }
    console.error("SePay Webhook processing error:", err);
    return res.status(500).json({ error: "Internal server error while processing webhook" });
  }
}

// api/save-user.ts
var import_firestore4 = require("firebase-admin/firestore");

// src/roles.ts
var STORE_STAFF_ROLES = [
  "order",
  "cashier",
  "order_cashier",
  "kitchen",
  "manager"
];
var SYSTEM_ADMIN_ROLES = ["admin", "superadmin"];
var ALL_USER_ROLES = [
  ...STORE_STAFF_ROLES,
  ...SYSTEM_ADMIN_ROLES
];
function isStoreStaffRole(role) {
  return STORE_STAFF_ROLES.includes(role);
}
function isValidUserRole(role) {
  return ALL_USER_ROLES.includes(role);
}

// api/save-user.ts
async function handler4(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const caller = await getAuthenticatedCaller(req);
  if (!caller) {
    return res.status(401).json({
      error: "Y\xEAu c\u1EA7u \u0111\u0103ng nh\u1EADp: Phi\xEAn l\xE0m vi\u1EC7c kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n."
    });
  }
  const { user } = req.body || {};
  if (!user) {
    return res.status(400).json({ error: "D\u1EEF li\u1EC7u ng\u01B0\u1EDDi d\xF9ng kh\xF4ng h\u1EE3p l\u1EC7" });
  }
  if (!user.role) {
    return res.status(400).json({ error: "Vui l\xF2ng ch\u1ECDn vai tr\xF2 cho ng\u01B0\u1EDDi d\xF9ng" });
  }
  const rawRole = String(user.role).trim();
  if (!isValidUserRole(rawRole)) {
    return res.status(400).json({
      error: `Vai tr\xF2 "${user.role}" kh\xF4ng h\u1EE3p l\u1EC7. C\xE1c vai tr\xF2 \u0111\u01B0\u1EE3c h\u1ED7 tr\u1EE3: ${ALL_USER_ROLES.join(", ")}`
    });
  }
  const role = rawRole;
  const cleanStoreId = String(user.storeId || "").trim();
  const cleanUsername = String(user.username || "").toLowerCase().trim();
  const cleanName = String(user.name || "").trim();
  if (!cleanUsername || !cleanName) {
    return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p \u0111\u1EA7y \u0111\u1EE7 T\xEAn \u0111\u0103ng nh\u1EADp v\xE0 H\u1ECD t\xEAn" });
  }
  const isSuperAdmin = Boolean(caller.isSuperAdmin || caller.role === "superadmin");
  const isStoreAdmin = caller.role === "admin";
  if (!isSuperAdmin && !isStoreAdmin) {
    return res.status(403).json({
      error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n qu\u1EA3n l\xFD nh\xE2n s\u1EF1."
    });
  }
  if (!isSuperAdmin) {
    if (role === "superadmin" || role === "admin" || !isStoreStaffRole(role)) {
      return res.status(403).json({
        error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: Qu\u1EA3n tr\u1ECB vi\xEAn c\u1EEDa h\xE0ng ch\u1EC9 c\xF3 quy\u1EC1n ph\xE2n c\xF4ng vai tr\xF2 nh\xE2n s\u1EF1 trong qu\xE1n (order, cashier, order_cashier, kitchen, manager), kh\xF4ng \u0111\u01B0\u1EE3c c\u1EA5p quy\u1EC1n Qu\u1EA3n tr\u1ECB vi\xEAn (Admin/SuperAdmin)."
      });
    }
  }
  try {
    if (!user.id) {
      if (!user.password || String(user.password).trim().length < 1) {
        return res.status(400).json({ error: "M\u1EADt kh\u1EA9u l\xE0 b\u1EAFt bu\u1ED9c khi t\u1EA1o t\xE0i kho\u1EA3n m\u1EDBi" });
      }
      const targetStoreId2 = isSuperAdmin ? cleanStoreId : String(caller.storeId || "").trim();
      if (!targetStoreId2) {
        return res.status(400).json({ error: "M\xE3 c\u1EEDa h\xE0ng kh\xF4ng h\u1EE3p l\u1EC7" });
      }
      if (!isSuperAdmin && cleanStoreId && cleanStoreId !== targetStoreId2) {
        return res.status(403).json({
          error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n t\u1EA1o t\xE0i kho\u1EA3n nh\xE2n vi\xEAn cho c\u1EEDa h\xE0ng kh\xE1c."
        });
      }
      const existingUserQuery = await adminDb.collection("users").where("storeId", "==", targetStoreId2).where("username", "==", cleanUsername).limit(1).get();
      if (!existingUserQuery.empty) {
        return res.status(400).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp n\xE0y \u0111\xE3 t\u1ED3n t\u1EA1i trong qu\xE1n. Vui l\xF2ng ch\u1ECDn t\xEAn kh\xE1c." });
      }
      const cleanPassword = String(user.password).trim();
      const passwordHash = hashPassword(cleanPassword);
      const userDocData = {
        storeId: targetStoreId2,
        username: cleanUsername,
        name: cleanName,
        role,
        phone: user.phone ? String(user.phone).trim() : "",
        cccd: user.cccd ? String(user.cccd).trim() : "",
        address: user.address ? String(user.address).trim() : "",
        salaryType: user.salaryType || "daily",
        salaryAmount: Number(user.salaryAmount) || 0,
        shifts: Array.isArray(user.shifts) ? user.shifts : [{ start: "08:00", end: "17:00" }],
        requiresAttendance: Boolean(user.requiresAttendance),
        tokenVersion: 1,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      const newUserDocRef = await adminDb.collection("users").add(userDocData);
      const newUserId = newUserDocRef.id;
      const secretPayload = {
        userId: newUserId,
        storeId: targetStoreId2,
        role,
        passwordHash,
        tokenVersion: 1,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (role === "admin") {
        secretPayload.encryptedPassword = encryptAes(cleanPassword);
      }
      try {
        await adminDb.collection("user_secrets").doc(newUserId).set(secretPayload);
      } catch (secErr) {
        try {
          await adminDb.collection("users").doc(newUserId).delete();
        } catch (_) {
        }
        return res.status(500).json({
          error: "L\u1ED7i h\u1EC7 th\u1ED1ng: Kh\xF4ng th\u1EC3 l\u01B0u tr\u1EEF th\xF4ng tin x\xE1c th\u1EF1c an to\xE0n. T\u1EA1o t\xE0i kho\u1EA3n th\u1EA5t b\u1EA1i."
        });
      }
      return res.status(200).json({
        success: true,
        userId: newUserId,
        user: {
          id: newUserId,
          ...userDocData
        }
      });
    }
    const userId = String(user.id).trim();
    const userDocRef = adminDb.collection("users").doc(userId);
    const existingDoc = await userDocRef.get();
    if (!existingDoc.exists) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y t\xE0i kho\u1EA3n ng\u01B0\u1EDDi d\xF9ng" });
    }
    const existingData = existingDoc.data() || {};
    const existingStoreId = String(existingData.storeId || "").trim();
    const existingRole = String(existingData.role || "order");
    if (!isSuperAdmin) {
      const callerStoreId = String(caller.storeId || "").trim();
      if (!callerStoreId || existingStoreId !== callerStoreId) {
        return res.status(403).json({
          error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n ch\u1EC9nh s\u1EEDa t\xE0i kho\u1EA3n thu\u1ED9c c\u1EEDa h\xE0ng kh\xE1c."
        });
      }
      if (existingRole === "admin" || existingRole === "superadmin") {
        return res.status(403).json({
          error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: Qu\u1EA3n tr\u1ECB vi\xEAn c\u1EEDa h\xE0ng kh\xF4ng c\xF3 quy\u1EC1n ch\u1EC9nh s\u1EEDa t\xE0i kho\u1EA3n Qu\u1EA3n tr\u1ECB vi\xEAn."
        });
      }
    }
    const targetStoreId = isSuperAdmin ? cleanStoreId || existingStoreId : existingStoreId;
    if (cleanUsername !== String(existingData.username || "").toLowerCase().trim()) {
      const dupQuery = await adminDb.collection("users").where("storeId", "==", targetStoreId).where("username", "==", cleanUsername).limit(1).get();
      if (!dupQuery.empty && dupQuery.docs[0].id !== userId) {
        return res.status(400).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp m\u1EDBi \u0111\xE3 t\u1ED3n t\u1EA1i trong qu\xE1n. Vui l\xF2ng ch\u1ECDn t\xEAn kh\xE1c." });
      }
    }
    const updates = {
      username: cleanUsername,
      name: cleanName,
      role,
      storeId: targetStoreId,
      phone: user.phone ? String(user.phone).trim() : "",
      cccd: user.cccd ? String(user.cccd).trim() : "",
      address: user.address ? String(user.address).trim() : "",
      salaryType: user.salaryType || "daily",
      salaryAmount: Number(user.salaryAmount) || 0,
      shifts: Array.isArray(user.shifts) ? user.shifts : [{ start: "08:00", end: "17:00" }],
      requiresAttendance: Boolean(user.requiresAttendance),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    const passwordChanged = Boolean(user.password && String(user.password).trim().length > 0);
    const roleChanged = Boolean(role !== existingRole);
    if (passwordChanged || roleChanged) {
      let currentVer = 1;
      try {
        const secretSnap = await adminDb.collection("user_secrets").doc(userId).get();
        if (secretSnap.exists) {
          currentVer = Number(secretSnap.data()?.tokenVersion || existingData.tokenVersion || 1);
        } else {
          currentVer = Number(existingData.tokenVersion || 1);
        }
      } catch (_) {
      }
      const nextTokenVersion = currentVer + 1;
      updates.tokenVersion = nextTokenVersion;
      const secretPayload = {
        userId,
        storeId: targetStoreId,
        role,
        tokenVersion: nextTokenVersion,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      if (passwordChanged) {
        const cleanPassword = String(user.password).trim();
        secretPayload.passwordHash = hashPassword(cleanPassword);
        secretPayload.passwordChangedAt = (/* @__PURE__ */ new Date()).toISOString();
        if (role === "admin") {
          secretPayload.encryptedPassword = encryptAes(cleanPassword);
        } else {
          secretPayload.encryptedPassword = import_firestore4.FieldValue.delete();
        }
        updates.password = import_firestore4.FieldValue.delete();
        updates.isLegacy = import_firestore4.FieldValue.delete();
      }
      try {
        await adminDb.collection("user_secrets").doc(userId).set(secretPayload, { merge: true });
      } catch (secErr) {
        return res.status(500).json({
          error: "L\u1ED7i h\u1EC7 th\u1ED1ng: Kh\xF4ng th\u1EC3 c\u1EADp nh\u1EADt th\xF4ng tin x\xE1c th\u1EF1c an to\xE0n v\xE0o v\xF9ng b\u1EA3o m\u1EADt."
        });
      }
      invalidateUserStatusCache(userId);
      await adminAuth.revokeRefreshTokens(userId);
    }
    await userDocRef.update(updates);
    return res.status(200).json({
      success: true,
      userId,
      message: "C\u1EADp nh\u1EADt t\xE0i kho\u1EA3n th\xE0nh c\xF4ng"
    });
  } catch (error) {
    console.error("Save user error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi l\u01B0u th\xF4ng tin ng\u01B0\u1EDDi d\xF9ng: " + error.message });
  }
}

// api/change-password.ts
var import_firestore5 = require("firebase-admin/firestore");
async function handler5(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const caller = await getAuthenticatedCaller(req);
  if (!caller) {
    return res.status(401).json({
      error: "Y\xEAu c\u1EA7u \u0111\u0103ng nh\u1EADp: Phi\xEAn l\xE0m vi\u1EC7c kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n."
    });
  }
  const { userId, newPassword } = req.body || {};
  if (!userId || !newPassword || String(newPassword).trim().length < 1) {
    return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p m\xE3 ng\u01B0\u1EDDi d\xF9ng (userId) v\xE0 m\u1EADt kh\u1EA9u m\u1EDBi" });
  }
  const cleanUserId = String(userId).trim();
  const cleanPassword = String(newPassword).trim();
  try {
    const userDocRef = adminDb.collection("users").doc(cleanUserId);
    const userDoc = await userDocRef.get();
    if (!userDoc.exists) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y th\xF4ng tin t\xE0i kho\u1EA3n" });
    }
    const userData = userDoc.data() || {};
    const role = userData.role || "order";
    const storeId = userData.storeId || "";
    const isSelf = caller.uid === cleanUserId;
    const isSuperAdmin = caller.isSuperAdmin || caller.role === "superadmin";
    const isStoreAdmin = caller.role === "admin" && String(caller.storeId || "").trim() === storeId;
    if (!isSelf && !isSuperAdmin && !isStoreAdmin) {
      return res.status(403).json({
        error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n \u0111\u1ED5i m\u1EADt kh\u1EA9u cho t\xE0i kho\u1EA3n n\xE0y."
      });
    }
    if ((role === "admin" || role === "superadmin") && !isSelf && !isSuperAdmin) {
      return res.status(403).json({
        error: "Ch\u1EC9 SuperAdmin ho\u1EB7c ch\xEDnh ch\u1EE7 t\xE0i kho\u1EA3n Qu\u1EA3n tr\u1ECB m\u1EDBi c\xF3 th\u1EC3 \u0111\u1ED5i m\u1EADt kh\u1EA9u n\xE0y."
      });
    }
    let currentVersion = 1;
    try {
      const secretSnap = await adminDb.collection("user_secrets").doc(cleanUserId).get();
      if (secretSnap.exists) {
        currentVersion = Number(secretSnap.data()?.tokenVersion || userData.tokenVersion || 1);
      } else {
        currentVersion = Number(userData.tokenVersion || 1);
      }
    } catch (_) {
    }
    const nextTokenVersion = currentVersion + 1;
    const passwordHash = hashPassword(cleanPassword);
    const secretPayload = {
      userId: cleanUserId,
      storeId,
      role,
      passwordHash,
      tokenVersion: nextTokenVersion,
      passwordChangedAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (role === "admin") {
      secretPayload.encryptedPassword = encryptAes(cleanPassword);
    } else {
      secretPayload.encryptedPassword = import_firestore5.FieldValue.delete();
    }
    try {
      await adminDb.collection("user_secrets").doc(cleanUserId).set(secretPayload, { merge: true });
    } catch (secErr) {
      return res.status(500).json({
        error: "L\u1ED7i h\u1EC7 th\u1ED1ng: Kh\xF4ng th\u1EC3 l\u01B0u m\u1EADt kh\u1EA9u v\xE0o v\xF9ng b\u1EA3o m\u1EADt. \u0110\u1ED5i m\u1EADt kh\u1EA9u th\u1EA5t b\u1EA1i."
      });
    }
    try {
      await userDocRef.update({
        tokenVersion: nextTokenVersion,
        password: import_firestore5.FieldValue.delete(),
        isLegacy: import_firestore5.FieldValue.delete(),
        passwordUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (e) {
      console.warn("Could not clean plaintext password in users:", e);
    }
    invalidateUserStatusCache(cleanUserId);
    await adminAuth.revokeRefreshTokens(cleanUserId);
    return res.status(200).json({
      success: true,
      message: "\u0110\u1ED5i m\u1EADt kh\u1EA9u th\xE0nh c\xF4ng. C\xE1c phi\xEAn l\xE0m vi\u1EC7c c\u0169 \u0111\xE3 \u0111\u01B0\u1EE3c thu h\u1ED3i."
    });
  } catch (error) {
    console.error("Change password error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi \u0111\u1ED5i m\u1EADt kh\u1EA9u: " + error.message });
  }
}

// api/delete-user.ts
async function handler6(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const caller = await getAuthenticatedCaller(req);
  if (!caller) {
    return res.status(401).json({
      error: "Y\xEAu c\u1EA7u \u0111\u0103ng nh\u1EADp: Phi\xEAn l\xE0m vi\u1EC7c kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n."
    });
  }
  const { userId } = req.body || {};
  if (!userId) {
    return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p m\xE3 ng\u01B0\u1EDDi d\xF9ng (userId) c\u1EA7n x\xF3a" });
  }
  const cleanUserId = String(userId).trim();
  try {
    const userDocRef = adminDb.collection("users").doc(cleanUserId);
    const userSnap = await userDocRef.get();
    if (!userSnap.exists) {
      return res.status(404).json({ error: "T\xE0i kho\u1EA3n ng\u01B0\u1EDDi d\xF9ng kh\xF4ng t\u1ED3n t\u1EA1i" });
    }
    const userData = userSnap.data() || {};
    const targetStoreId = userData.storeId || "";
    const targetRole = userData.role || "order";
    const isSuperAdmin = caller.isSuperAdmin || caller.role === "superadmin";
    const isStoreAdmin = caller.role === "admin" && String(caller.storeId || "").trim() === targetStoreId;
    if (!isSuperAdmin && !isStoreAdmin) {
      return res.status(403).json({
        error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: Ch\u1EC9 Qu\u1EA3n l\xFD (Admin) c\u1EE7a qu\xE1n ho\u1EB7c SuperAdmin m\u1EDBi c\xF3 quy\u1EC1n x\xF3a nh\xE2n s\u1EF1."
      });
    }
    if ((targetRole === "admin" || targetRole === "superadmin") && !isSuperAdmin) {
      return res.status(403).json({
        error: "Kh\xF4ng th\u1EC3 x\xF3a t\xE0i kho\u1EA3n Qu\u1EA3n tr\u1ECB vi\xEAn (Admin/SuperAdmin) qua thao t\xE1c n\xE0y."
      });
    }
    await userDocRef.delete();
    try {
      await adminDb.collection("user_secrets").doc(cleanUserId).delete();
    } catch (secErr) {
    }
    invalidateUserStatusCache(cleanUserId);
    await adminAuth.revokeRefreshTokens(cleanUserId);
    return res.status(200).json({
      success: true,
      message: "X\xF3a t\xE0i kho\u1EA3n ng\u01B0\u1EDDi d\xF9ng th\xE0nh c\xF4ng"
    });
  } catch (error) {
    console.error("Delete user error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi x\xF3a t\xE0i kho\u1EA3n: " + error.message });
  }
}

// api/delete-store.ts
async function handler7(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const caller = await getAuthenticatedCaller(req);
  if (!caller) {
    return res.status(401).json({
      error: "Y\xEAu c\u1EA7u \u0111\u0103ng nh\u1EADp: Phi\xEAn l\xE0m vi\u1EC7c kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n."
    });
  }
  const { storeId } = req.body || {};
  if (!storeId) {
    return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p m\xE3 c\u1EEDa h\xE0ng (storeId) c\u1EA7n x\xF3a" });
  }
  const cleanStoreId = String(storeId).trim();
  const isSuperAdmin = Boolean(caller.isSuperAdmin || caller.role === "superadmin");
  const isStoreAdmin = caller.role === "admin" && String(caller.storeId || "").trim() === cleanStoreId;
  if (!isSuperAdmin && !isStoreAdmin) {
    return res.status(403).json({
      error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n x\xF3a c\u1EEDa h\xE0ng n\xE0y."
    });
  }
  try {
    const collectionsToClean = [
      "users",
      "menu",
      "tables",
      "table_groups",
      "invoices",
      "inventory_logs",
      "inventory_audits",
      "stock_card",
      "customers",
      "cash_transactions",
      "settings",
      "attendance_records",
      "payroll_records",
      "shifts",
      "daily_stats"
    ];
    let totalDeleted = 0;
    for (const colName of collectionsToClean) {
      const snap = await adminDb.collection(colName).where("storeId", "==", cleanStoreId).get();
      if (!snap.empty) {
        const docs = snap.docs;
        for (let i = 0; i < docs.length; i += 400) {
          const batch = adminDb.batch();
          const chunk = docs.slice(i, i + 400);
          for (const doc of chunk) {
            batch.delete(doc.ref);
            if (colName === "users") {
              batch.delete(adminDb.collection("user_secrets").doc(doc.id));
              invalidateUserStatusCache(doc.id);
            }
          }
          await batch.commit();
          totalDeleted += chunk.length;
        }
      }
    }
    const storeDocRef = adminDb.collection("stores").doc(cleanStoreId);
    await storeDocRef.delete();
    totalDeleted++;
    return res.status(200).json({
      success: true,
      message: `\u0110\xE3 x\xF3a to\xE0n b\u1ED9 c\u1EEDa h\xE0ng v\xE0 ${totalDeleted} b\u1EA3n ghi li\xEAn quan th\xE0nh c\xF4ng.`
    });
  } catch (error) {
    console.error("Delete store error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi x\xF3a c\u1EEDa h\xE0ng: " + error.message });
  }
}

// api/register-store.ts
var INITIAL_MENU = [
  { name: "C\xE0 ph\xEA \u0111en", price: 2e4, category: "C\xE0 ph\xEA", unit: "Ly" },
  { name: "C\xE0 ph\xEA s\u1EEFa", price: 25e3, category: "C\xE0 ph\xEA", unit: "Ly" },
  { name: "B\u1EA1c x\u1EC9u", price: 3e4, category: "C\xE0 ph\xEA", unit: "Ly" },
  { name: "Tr\xE0 \u0111\xE0o cam s\u1EA3", price: 35e3, category: "Tr\xE0", unit: "Ly" },
  { name: "Tr\xE0 v\u1EA3i", price: 35e3, category: "Tr\xE0", unit: "Ly" },
  { name: "N\u01B0\u1EDBc cam \xE9p", price: 35e3, category: "N\u01B0\u1EDBc \xE9p", unit: "Ly" },
  { name: "Sinh t\u1ED1 b\u01A1", price: 4e4, category: "Sinh t\u1ED1", unit: "Ly" }
];
var INITIAL_TABLES = [
  { name: "B\xE0n 1", area: "T\u1EA7ng 1", status: "available" },
  { name: "B\xE0n 2", area: "T\u1EA7ng 1", status: "available" },
  { name: "B\xE0n 3", area: "T\u1EA7ng 1", status: "available" },
  { name: "B\xE0n 4", area: "T\u1EA7ng 1", status: "available" },
  { name: "B\xE0n 5", area: "T\u1EA7ng 1", status: "available" },
  { name: "B\xE0n 6", area: "T\u1EA7ng 2", status: "available" },
  { name: "B\xE0n 7", area: "T\u1EA7ng 2", status: "available" },
  { name: "B\xE0n 8", area: "T\u1EA7ng 2", status: "available" }
];
var CATEGORIES = ["T\u1EA5t c\u1EA3", "C\xE0 ph\xEA", "Tr\xE0", "N\u01B0\u1EDBc \xE9p", "Sinh t\u1ED1", "\u0110\u1ED3 \u0103n v\u1EB7t", "Kh\xE1c"];
async function handler8(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { storeName, storeCode, phone, password } = req.body || {};
  if (!storeName || !storeCode || !phone || !password) {
    return res.status(400).json({ error: "Vui l\xF2ng \u0111i\u1EC1n \u0111\u1EA7y \u0111\u1EE7 T\xEAn qu\xE1n, M\xE3 qu\xE1n, S\u1ED1 \u0111i\u1EC7n tho\u1EA1i v\xE0 M\u1EADt kh\u1EA9u" });
  }
  const cleanStoreName = String(storeName).trim();
  const cleanStoreCode = String(storeCode).toLowerCase().trim();
  const cleanPhone = String(phone).trim();
  const cleanPassword = String(password).trim();
  if (cleanStoreCode.includes(" ") || cleanStoreCode.length < 3) {
    return res.status(400).json({ error: "M\xE3 c\u1EEDa h\xE0ng ph\u1EA3i vi\u1EBFt li\u1EC1n kh\xF4ng d\u1EA5u v\xE0 \xEDt nh\u1EA5t 3 k\xFD t\u1EF1" });
  }
  if (cleanPhone.length < 9) {
    return res.status(400).json({ error: "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i kh\xF4ng h\u1EE3p l\u1EC7" });
  }
  try {
    const existingStoreQuery = await adminDb.collection("stores").where("code", "==", cleanStoreCode).limit(1).get();
    if (!existingStoreQuery.empty) {
      return res.status(400).json({ error: "M\xE3 c\u1EEDa h\xE0ng n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c \u0111\u0103ng k\xFD. Vui l\xF2ng ch\u1ECDn m\xE3 kh\xE1c." });
    }
    const existingPhoneQuery = await adminDb.collection("users").where("username", "==", cleanPhone).where("role", "==", "admin").limit(1).get();
    if (!existingPhoneQuery.empty) {
      return res.status(400).json({ error: "S\u1ED1 \u0111i\u1EC7n tho\u1EA1i n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c d\xF9ng \u0111\u1EC3 \u0111\u0103ng k\xFD m\u1ED9t c\u1EEDa h\xE0ng kh\xE1c." });
    }
    let trialDays = 14;
    try {
      const pkgDoc = await adminDb.collection("packages").doc("trial").get();
      if (pkgDoc.exists && pkgDoc.data()?.trialDays) {
        trialDays = Number(pkgDoc.data()?.trialDays) || 14;
      }
    } catch (e) {
    }
    const trialEndDate = /* @__PURE__ */ new Date();
    trialEndDate.setDate(trialEndDate.getDate() + trialDays);
    const storeRef = await adminDb.collection("stores").add({
      name: cleanStoreName,
      code: cleanStoreCode,
      phone: cleanPhone,
      subscription: {
        status: "trial",
        trialEndDate: trialEndDate.toISOString(),
        packageId: "trial"
      },
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    const storeId = storeRef.id;
    const adminUserRef = await adminDb.collection("users").add({
      username: cleanPhone,
      name: "Qu\u1EA3n tr\u1ECB vi\xEAn",
      role: "admin",
      storeId,
      phone: cleanPhone,
      tokenVersion: 1,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    const adminUserId = adminUserRef.id;
    const passwordHash = hashPassword(cleanPassword);
    const encryptedPassword = encryptAes(cleanPassword);
    try {
      await adminDb.collection("user_secrets").doc(adminUserId).set({
        userId: adminUserId,
        storeId,
        role: "admin",
        passwordHash,
        encryptedPassword,
        tokenVersion: 1,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (secErr) {
      try {
        await adminDb.collection("users").doc(adminUserId).delete();
        await adminDb.collection("stores").doc(storeId).delete();
      } catch (_) {
      }
      return res.status(500).json({
        error: "L\u1ED7i h\u1EC7 th\u1ED1ng: Kh\xF4ng th\u1EC3 kh\u1EDFi t\u1EA1o th\xF4ng tin x\xE1c th\u1EF1c an to\xE0n cho t\xE0i kho\u1EA3n ch\u1EE7 qu\xE1n."
      });
    }
    try {
      const batch = adminDb.batch();
      for (const item of INITIAL_MENU) {
        const docRef = adminDb.collection("menu").doc();
        batch.set(docRef, { ...item, isInventory: false, storeId });
      }
      for (const table of INITIAL_TABLES) {
        const docRef = adminDb.collection("tables").doc();
        batch.set(docRef, { ...table, storeId });
      }
      const settingsDocRef = adminDb.collection("settings").doc();
      batch.set(settingsDocRef, {
        storeId,
        storeName: cleanStoreName,
        address: "",
        phone: cleanPhone,
        logo: "",
        adminUsername: cleanPhone,
        kitchenBellEnabled: true,
        vatPercent: 8,
        kitchenBillTemplate: "M\u1EABu bill b\u1EBFp m\u1EB7c \u0111\u1ECBnh",
        paymentBillTemplate: "M\u1EABu bill thanh to\xE1n m\u1EB7c \u0111\u1ECBnh",
        menuCategories: CATEGORIES,
        inventoryCategories: ["Nguy\xEAn li\u1EC7u", "\u0110\u1ED3 u\u1ED1ng", "Kh\xE1c"],
        cashCategories: ["B\xE1n h\xE0ng", "Ti\u1EC1n \u0111i\u1EC7n", "Ti\u1EC1n n\u01B0\u1EDBc", "Ti\u1EC1n m\u1EB7t b\u1EB1ng", "Nh\u1EADp h\xE0ng", "L\u01B0\u01A1ng nh\xE2n vi\xEAn", "Kh\xE1c"],
        customerTypes: [
          { id: "1", name: "Kh\xE1ch l\u1EBB", discountPercent: 0 },
          { id: "2", name: "Th\xE0nh vi\xEAn \u0110\u1ED3ng", discountPercent: 5 },
          { id: "3", name: "Th\xE0nh vi\xEAn B\u1EA1c", discountPercent: 10 },
          { id: "4", name: "Th\xE0nh vi\xEAn V\xE0ng", discountPercent: 15 }
        ],
        outOfStockAddOnIds: []
      });
      await batch.commit();
    } catch (seedErr) {
      console.error("[Register Store] L\u1ED7i t\u1EA1o d\u1EEF li\u1EC7u m\u1EABu, ti\u1EBFn h\xE0nh rollback to\xE0n di\u1EC7n:", seedErr);
      try {
        await adminDb.collection("user_secrets").doc(adminUserId).delete();
        await adminDb.collection("users").doc(adminUserId).delete();
        await adminDb.collection("stores").doc(storeId).delete();
      } catch (_) {
      }
      return res.status(500).json({
        error: "L\u1ED7i m\xE1y ch\u1EE7 khi kh\u1EDFi t\u1EA1o d\u1EEF li\u1EC7u m\u1EABu cho c\u1EEDa h\xE0ng. Giao d\u1ECBch \u0111\u0103ng k\xFD \u0111\xE3 \u0111\u01B0\u1EE3c rollback an to\xE0n."
      });
    }
    return res.status(200).json({
      success: true,
      storeId,
      userId: adminUserId,
      message: "\u0110\u0103ng k\xFD c\u1EEDa h\xE0ng th\xE0nh c\xF4ng"
    });
  } catch (error) {
    console.error("Register store error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi \u0111\u0103ng k\xFD c\u1EEDa h\xE0ng: " + error.message });
  }
}

// api/reset-password.ts
var import_firestore6 = require("firebase-admin/firestore");
async function handler9(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const caller = await getAuthenticatedCaller(req);
  if (!caller) {
    return res.status(401).json({
      error: "Y\xEAu c\u1EA7u \u0111\u0103ng nh\u1EADp: Phi\xEAn l\xE0m vi\u1EC7c kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n."
    });
  }
  const { userId, newPassword } = req.body || {};
  if (!userId || !newPassword || String(newPassword).trim().length < 6) {
    return res.status(400).json({ error: "M\u1EADt kh\u1EA9u m\u1EDBi ph\u1EA3i c\xF3 \u0111\u1ED9 d\xE0i \xEDt nh\u1EA5t 6 k\xFD t\u1EF1" });
  }
  const cleanUserId = String(userId).trim();
  const cleanPassword = String(newPassword).trim();
  try {
    const userDocRef = adminDb.collection("users").doc(cleanUserId);
    const userSnap = await userDocRef.get();
    if (!userSnap.exists) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y t\xE0i kho\u1EA3n ng\u01B0\u1EDDi d\xF9ng c\u1EA7n \u0111\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u" });
    }
    const userData = userSnap.data() || {};
    const targetStoreId = userData.storeId || "";
    const targetRole = userData.role || "order";
    const isSuperAdmin = caller.isSuperAdmin || caller.role === "superadmin";
    const isStoreAdmin = caller.role === "admin" && String(caller.storeId || "").trim() === targetStoreId;
    if (!isSuperAdmin && !isStoreAdmin) {
      return res.status(403).json({
        error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n \u0111\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u cho t\xE0i kho\u1EA3n n\xE0y."
      });
    }
    if (!isSuperAdmin && (targetRole === "admin" || targetRole === "superadmin") && caller.uid !== cleanUserId) {
      return res.status(403).json({
        error: "T\u1EEB ch\u1ED1i quy\u1EC1n truy c\u1EADp: Qu\u1EA3n tr\u1ECB vi\xEAn c\u1EEDa h\xE0ng kh\xF4ng \u0111\u01B0\u1EE3c \u0111\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u c\u1EE7a Qu\u1EA3n tr\u1ECB vi\xEAn kh\xE1c."
      });
    }
    let currentVersion = 1;
    try {
      const secretSnap = await adminDb.collection("user_secrets").doc(cleanUserId).get();
      if (secretSnap.exists) {
        currentVersion = Number(secretSnap.data()?.tokenVersion || userData.tokenVersion || 1);
      } else {
        currentVersion = Number(userData.tokenVersion || 1);
      }
    } catch (_) {
    }
    const nextTokenVersion = currentVersion + 1;
    const passwordHash = hashPassword(cleanPassword);
    const secretPayload = {
      userId: cleanUserId,
      storeId: targetStoreId,
      role: targetRole,
      passwordHash,
      tokenVersion: nextTokenVersion,
      resetAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (targetRole === "admin") {
      secretPayload.encryptedPassword = encryptAes(cleanPassword);
    } else {
      secretPayload.encryptedPassword = import_firestore6.FieldValue.delete();
    }
    try {
      await adminDb.collection("user_secrets").doc(cleanUserId).set(secretPayload, { merge: true });
    } catch (secErr) {
      return res.status(500).json({
        error: "L\u1ED7i h\u1EC7 th\u1ED1ng: Kh\xF4ng th\u1EC3 ghi nh\u1EADn m\u1EADt kh\u1EA9u m\u1EDBi v\xE0o v\xF9ng b\u1EA3o m\u1EADt."
      });
    }
    try {
      await userDocRef.update({
        tokenVersion: nextTokenVersion,
        password: import_firestore6.FieldValue.delete(),
        isLegacy: import_firestore6.FieldValue.delete(),
        passwordUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (_) {
    }
    invalidateUserStatusCache(cleanUserId);
    await adminAuth.revokeRefreshTokens(cleanUserId);
    return res.status(200).json({
      success: true,
      message: "\u0110\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u th\xE0nh c\xF4ng. C\xE1c phi\xEAn \u0111\u0103ng nh\u1EADp tr\u01B0\u1EDBc \u0111\xF3 \u0111\xE3 \u0111\u01B0\u1EE3c v\xF4 hi\u1EC7u h\xF3a."
    });
  } catch (error) {
    console.error("Reset password error:", error);
    return res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi \u0111\u1EB7t l\u1EA1i m\u1EADt kh\u1EA9u: " + error.message });
  }
}

// scripts/migrate_legacy_data.ts
function getVietnamBusinessDate(dateStr) {
  try {
    const d = dateStr ? typeof dateStr === "string" ? new Date(dateStr) : dateStr : /* @__PURE__ */ new Date();
    if (isNaN(d.getTime())) {
      const now = /* @__PURE__ */ new Date();
      return new Intl.DateTimeFormat("en-CA", {
        timeZone: "Asia/Ho_Chi_Minh",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      }).format(now);
    }
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Ho_Chi_Minh",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).format(d);
  } catch {
    return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  }
}
function classifyMenuItem(item, recipeIngredientIds) {
  const nameLower = (item.name || "").toLowerCase().trim();
  const codeUpper = (item.code || "").toUpperCase().trim();
  const categoryLower = (item.category || "").toLowerCase().trim();
  const price = Number(item.price) || 0;
  if (nameLower.endsWith("_nl") || codeUpper.startsWith("NL") || categoryLower === "nguy\xEAn li\u1EC7u") {
    if (price <= 0) return true;
  }
  if (recipeIngredientIds.has(item.id) && price <= 0) {
    return true;
  }
  if (item.type === "dish") {
    return false;
  }
  if (price > 0 && categoryLower !== "nguy\xEAn li\u1EC7u") {
    return false;
  }
  if (typeof item.isInventory === "boolean") {
    return item.isInventory;
  }
  if (price <= 0 && (Number(item.costPrice) || 0) > 0) {
    return true;
  }
  return false;
}
function calculateInvoiceCost(items) {
  if (!items || !Array.isArray(items)) return { totalCost: 0, hasEstimated: false };
  let hasEstimated = false;
  const totalCost = items.reduce((sum, item) => {
    const costPrice = Number(item.costPrice);
    const hasValidCost = typeof item.costPrice === "number" && costPrice > 0;
    const hasRecipe = Array.isArray(item.recipe) && item.recipe.length > 0;
    if (!hasValidCost && !hasRecipe) {
      hasEstimated = true;
    }
    const itemCost = (hasValidCost ? costPrice : 0) * (Number(item.quantity) || 1);
    const addOnsCost = (item.selectedAddOns || []).reduce((aSum, a) => {
      const unitCost = Number(a.costPrice) || 0;
      const qtyPerServing = typeof a.quantity === "number" && a.quantity > 0 ? a.quantity : 1;
      return aSum + unitCost * qtyPerServing * (Number(item.quantity) || 1);
    }, 0);
    return sum + itemCost + addOnsCost;
  }, 0);
  return { totalCost, hasEstimated };
}
async function migrateStoreMenu(storeId, options = {}) {
  console.log(`
=== [MENU] B\u1EAFt \u0111\u1EA7u migration Menu cho storeId: ${storeId} ===`);
  const checkpointDocRef = adminDb.doc(`migration_checkpoints/${storeId}_menu`);
  if (!options.forceRerun) {
    const cpSnap = await checkpointDocRef.get();
    if (cpSnap.exists) {
      const cpData = cpSnap.data();
      if (cpData.status === "completed") {
        console.log(`[MENU] Store ${storeId} \u0111\xE3 ho\xE0n t\u1EA5t migration Menu tr\u01B0\u1EDBc \u0111\xF3 v\xE0o ${cpData.updatedAt}. B\u1ECF qua.`);
        return { totalProcessed: cpData.totalProcessed || 0, totalUpdated: cpData.totalUpdated || 0, alreadyCompleted: true };
      }
    }
  }
  const menuSnap = await adminDb.collection("menu").where("storeId", "==", storeId).get();
  const allItems = menuSnap.docs.map((d) => ({ ...d.data(), id: d.id }));
  const totalProcessed = allItems.length;
  const recipeIngredientIds = /* @__PURE__ */ new Set();
  allItems.forEach((item) => {
    if (item.recipe && Array.isArray(item.recipe)) {
      item.recipe.forEach((r) => {
        if (r.ingredientId) recipeIngredientIds.add(r.ingredientId);
      });
    }
  });
  const updatesToApply = [];
  allItems.forEach((item) => {
    const shouldBeInventory = classifyMenuItem(item, recipeIngredientIds);
    if (item.isInventory !== shouldBeInventory) {
      updatesToApply.push({ id: item.id, shouldBeInventory });
    }
  });
  const totalUpdated = updatesToApply.length;
  console.log(`[MENU] T\xECm th\u1EA5y ${totalProcessed} m\xF3n, c\u1EA7n c\u1EADp nh\u1EADt c\u1EDD kho cho ${totalUpdated} m\xF3n.`);
  if (!options.dryRun && totalUpdated > 0) {
    for (let i = 0; i < updatesToApply.length; i += 400) {
      const chunk = updatesToApply.slice(i, i + 400);
      const batch = adminDb.batch();
      chunk.forEach((u) => {
        batch.update(adminDb.doc(`menu/${u.id}`), {
          isInventory: u.shouldBeInventory,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      });
      await batch.commit();
      console.log(`[MENU] \u0110\xE3 commit ${chunk.length} m\xF3n (${i + chunk.length}/${totalUpdated}).`);
    }
  }
  if (!options.dryRun) {
    await checkpointDocRef.set({
      storeId,
      totalProcessed,
      totalUpdated,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "completed"
    }, { merge: true });
    try {
      await adminDb.doc(`stores/${storeId}`).update({
        "migrationStatus.menu": "completed",
        "migrationStatus.menuMigratedAt": (/* @__PURE__ */ new Date()).toISOString(),
        "migrationStatus.menuTotal": totalProcessed
      });
    } catch (storeErr) {
      console.warn("[MENU] C\u1EADp nh\u1EADt migrationStatus tr\xEAn store b\u1ECB b\u1ECF qua n\u1EBFu store doc ch\u01B0a t\u1ED3n t\u1EA1i:", storeErr);
    }
  }
  return { totalProcessed, totalUpdated, dryRun: options.dryRun };
}
async function migrateStoreInvoices(storeId, options = {}) {
  console.log(`
=== [INVOICES] B\u1EAFt \u0111\u1EA7u migration H\xF3a \u0111\u01A1n cho storeId: ${storeId} ===`);
  const checkpointDocRef = adminDb.doc(`migration_checkpoints/${storeId}_invoices`);
  let lastDocId = null;
  let totalProcessed = 0;
  let totalUpdated = 0;
  if (!options.forceRerun) {
    const cpSnap = await checkpointDocRef.get();
    if (cpSnap.exists) {
      const cpData = cpSnap.data();
      if (cpData.status === "completed") {
        console.log(`[INVOICES] Store ${storeId} \u0111\xE3 ho\xE0n t\u1EA5t migration H\xF3a \u0111\u01A1n tr\u01B0\u1EDBc \u0111\xF3. B\u1ECF qua.`);
        return { totalProcessed: cpData.totalProcessed || 0, totalUpdated: cpData.totalUpdated || 0, alreadyCompleted: true };
      }
      if (cpData.status === "in_progress" && cpData.lastDocId) {
        lastDocId = cpData.lastDocId;
        totalProcessed = cpData.totalProcessed || 0;
        totalUpdated = cpData.totalUpdated || 0;
        console.log(`[INVOICES] Ph\u1EE5c h\u1ED3i t\u1EEB checkpoint t\u1EA1i document: ${lastDocId} (\u0111\xE3 x\u1EED l\xFD ${totalProcessed} \u0111\u01A1n).`);
      }
    }
  }
  let hasMore = true;
  const BATCH_SIZE = 200;
  while (hasMore) {
    let q = adminDb.collection("invoices").where("storeId", "==", storeId).orderBy("__name__").limit(BATCH_SIZE);
    if (lastDocId) {
      q = q.startAfter(lastDocId);
    }
    const snap = await q.get();
    if (snap.empty) {
      hasMore = false;
      break;
    }
    const batch = adminDb.batch();
    let batchChanges = 0;
    snap.docs.forEach((docSnap) => {
      totalProcessed++;
      const inv = docSnap.data();
      const updates = {};
      const vnDate = inv.businessDate || getVietnamBusinessDate(inv.date || (/* @__PURE__ */ new Date()).toISOString());
      if (!inv.businessDate) updates.businessDate = vnDate;
      if (!inv.businessMonth) updates.businessMonth = vnDate.slice(0, 7);
      if (!inv.businessYear) updates.businessYear = parseInt(vnDate.slice(0, 4), 10);
      if (typeof inv.totalCost !== "number") {
        const { totalCost, hasEstimated } = calculateInvoiceCost(inv.items || []);
        updates.totalCost = totalCost;
        updates.costVersion = 1;
        if (hasEstimated) {
          updates.costStatus = "estimated";
        }
      }
      if (Object.keys(updates).length > 0) {
        if (!options.dryRun) {
          batch.update(adminDb.doc(`invoices/${docSnap.id}`), updates);
        }
        batchChanges++;
        totalUpdated++;
      }
    });
    if (!options.dryRun && batchChanges > 0) {
      await batch.commit();
      console.log(`[INVOICES] Batch commit th\xE0nh c\xF4ng: ${batchChanges} h\xF3a \u0111\u01A1n c\u1EADp nh\u1EADt.`);
    }
    lastDocId = snap.docs[snap.docs.length - 1].id;
    if (!options.dryRun) {
      await checkpointDocRef.set({
        storeId,
        totalProcessed,
        totalUpdated,
        lastDocId,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: snap.docs.length < BATCH_SIZE ? "completed" : "in_progress"
      }, { merge: true });
    }
    if (snap.docs.length < BATCH_SIZE) {
      hasMore = false;
    }
  }
  if (!options.dryRun) {
    try {
      await adminDb.doc(`stores/${storeId}`).update({
        "migrationStatus.invoices": "completed",
        "migrationStatus.invoicesMigratedAt": (/* @__PURE__ */ new Date()).toISOString(),
        "migrationStatus.invoicesTotal": totalProcessed
      });
    } catch (storeErr) {
      console.warn("[INVOICES] C\u1EADp nh\u1EADt migrationStatus invoices:", storeErr);
    }
  }
  console.log(`[INVOICES] Ho\xE0n t\u1EA5t migration H\xF3a \u0111\u01A1n: ${totalProcessed} ki\u1EC3m tra, ${totalUpdated} c\u1EADp nh\u1EADt.`);
  return { totalProcessed, totalUpdated, dryRun: options.dryRun };
}
async function migrateStoreCash(storeId, options = {}) {
  console.log(`
=== [CASH] B\u1EAFt \u0111\u1EA7u migration S\u1ED5 qu\u1EF9 cho storeId: ${storeId} ===`);
  const checkpointDocRef = adminDb.doc(`migration_checkpoints/${storeId}_cash`);
  let lastDocId = null;
  let totalProcessed = 0;
  let totalUpdated = 0;
  if (!options.forceRerun) {
    const cpSnap = await checkpointDocRef.get();
    if (cpSnap.exists) {
      const cpData = cpSnap.data();
      if (cpData.status === "completed") {
        console.log(`[CASH] Store ${storeId} \u0111\xE3 ho\xE0n t\u1EA5t migration S\u1ED5 qu\u1EF9 tr\u01B0\u1EDBc \u0111\xF3. B\u1ECF qua.`);
        return { totalProcessed: cpData.totalProcessed || 0, totalUpdated: cpData.totalUpdated || 0, alreadyCompleted: true };
      }
      if (cpData.status === "in_progress" && cpData.lastDocId) {
        lastDocId = cpData.lastDocId;
        totalProcessed = cpData.totalProcessed || 0;
        totalUpdated = cpData.totalUpdated || 0;
        console.log(`[CASH] Ph\u1EE5c h\u1ED3i t\u1EEB checkpoint t\u1EA1i document: ${lastDocId}.`);
      }
    }
  }
  let hasMore = true;
  const BATCH_SIZE = 200;
  while (hasMore) {
    let q = adminDb.collection("cash_transactions").where("storeId", "==", storeId).orderBy("__name__").limit(BATCH_SIZE);
    if (lastDocId) {
      q = q.startAfter(lastDocId);
    }
    const snap = await q.get();
    if (snap.empty) {
      hasMore = false;
      break;
    }
    const batch = adminDb.batch();
    let batchChanges = 0;
    snap.docs.forEach((docSnap) => {
      totalProcessed++;
      const tx = docSnap.data();
      const updates = {};
      const vnDate = tx.businessDate || getVietnamBusinessDate(tx.date || (/* @__PURE__ */ new Date()).toISOString());
      if (!tx.businessDate) updates.businessDate = vnDate;
      if (!tx.businessMonth) updates.businessMonth = vnDate.slice(0, 7);
      if (!tx.businessYear) updates.businessYear = parseInt(vnDate.slice(0, 4), 10);
      if (Object.keys(updates).length > 0) {
        if (!options.dryRun) {
          batch.update(adminDb.doc(`cash_transactions/${docSnap.id}`), updates);
        }
        batchChanges++;
        totalUpdated++;
      }
    });
    if (!options.dryRun && batchChanges > 0) {
      await batch.commit();
      console.log(`[CASH] Batch commit s\u1ED5 qu\u1EF9 th\xE0nh c\xF4ng: ${batchChanges} giao d\u1ECBch c\u1EADp nh\u1EADt.`);
    }
    lastDocId = snap.docs[snap.docs.length - 1].id;
    if (!options.dryRun) {
      await checkpointDocRef.set({
        storeId,
        totalProcessed,
        totalUpdated,
        lastDocId,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        status: snap.docs.length < BATCH_SIZE ? "completed" : "in_progress"
      }, { merge: true });
    }
    if (snap.docs.length < BATCH_SIZE) {
      hasMore = false;
    }
  }
  if (!options.dryRun) {
    try {
      await adminDb.doc(`stores/${storeId}`).update({
        "migrationStatus.cash": "completed",
        "migrationStatus.cashMigratedAt": (/* @__PURE__ */ new Date()).toISOString(),
        "migrationStatus.cashTotal": totalProcessed
      });
    } catch (storeErr) {
      console.warn("[CASH] C\u1EADp nh\u1EADt migrationStatus cash:", storeErr);
    }
  }
  console.log(`[CASH] Ho\xE0n t\u1EA5t migration S\u1ED5 qu\u1EF9: ${totalProcessed} ki\u1EC3m tra, ${totalUpdated} c\u1EADp nh\u1EADt.`);
  return { totalProcessed, totalUpdated, dryRun: options.dryRun };
}
async function acquireStoreLock(storeId) {
  const lockRef = adminDb.doc(`migration_locks/${storeId}`);
  const snap = await lockRef.get();
  if (snap.exists) {
    const data = snap.data();
    const lockTime = new Date(data.lockedAt || 0).getTime();
    const now = Date.now();
    if (now - lockTime < 15 * 60 * 1e3) {
      return false;
    }
  }
  await lockRef.set({
    storeId,
    lockedAt: (/* @__PURE__ */ new Date()).toISOString(),
    lockedBy: "migration_job"
  });
  return true;
}
async function releaseStoreLock(storeId) {
  try {
    await adminDb.doc(`migration_locks/${storeId}`).delete();
  } catch (err) {
    console.warn("[LOCK] Kh\xF4ng th\u1EC3 gi\u1EA3i ph\xF3ng lock:", err);
  }
}

// scripts/backfill_daily_stats.ts
async function backfillStoreDailyStats(storeId, options = {}) {
  console.log(`
=== [BACKFILL] B\u1EAFt \u0111\u1EA7u \u0111\u1ED1i so\xE1t v\xE0 t\u1ED5ng h\u1EE3p daily_stats cho storeId: ${storeId} ===`);
  const todayStr = getVietnamBusinessDate();
  let invQuery = adminDb.collection("invoices").where("storeId", "==", storeId);
  const invSnap = await invQuery.get();
  console.log(`[BACKFILL] \u0110\xE3 t\u1EA3i ${invSnap.size} h\xF3a \u0111\u01A1n c\u1EE7a storeId ${storeId}.`);
  let cashQuery = adminDb.collection("cash_transactions").where("storeId", "==", storeId);
  const cashSnap = await cashQuery.get();
  console.log(`[BACKFILL] \u0110\xE3 t\u1EA3i ${cashSnap.size} giao d\u1ECBch s\u1ED5 qu\u1EF9 c\u1EE7a storeId ${storeId}.`);
  const statsMap = /* @__PURE__ */ new Map();
  const dayHasEstimatedCostMap = /* @__PURE__ */ new Map();
  const dayHasMissingCostMap = /* @__PURE__ */ new Map();
  const getOrCreateStats = (dStr) => {
    const key = `${storeId}_${dStr}`;
    if (!statsMap.has(key)) {
      const [yStr, mStr] = dStr.split("-");
      statsMap.set(key, {
        storeId,
        date: dStr,
        month: `${yStr}-${mStr}`,
        year: parseInt(yStr, 10),
        totalRevenue: 0,
        totalCash: 0,
        totalTransfer: 0,
        totalDiscount: 0,
        invoiceCount: 0,
        totalCost: 0,
        hasData: false,
        costStatus: "complete",
        coverageStatus: "reconciled",
        reconciledAt: (/* @__PURE__ */ new Date()).toISOString(),
        sourceVersion: 2,
        invoicesTotalCount: 0,
        cashTransactionsTotalCount: 0,
        totalIncome: 0,
        totalExpense: 0,
        cashExpense: 0,
        transferExpense: 0,
        cashIncome: 0,
        transferIncome: 0,
        expenseInventory: 0,
        expenseSalary: 0,
        expenseRent: 0,
        expenseOther: 0,
        cashCount: 0,
        version: 2,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    return statsMap.get(key);
  };
  const invoicesToUpdate = [];
  invSnap.docs.forEach((docSnap) => {
    const inv = docSnap.data();
    if (!inv.date) return;
    const vnDateStr = inv.businessDate || getVietnamBusinessDate(inv.date);
    if (options.startDate && vnDateStr < options.startDate) return;
    if (options.endDate && vnDateStr > options.endDate) return;
    if (vnDateStr === todayStr) {
      return;
    }
    const cur = getOrCreateStats(vnDateStr);
    const total = Number(inv.total) || 0;
    cur.totalRevenue += total;
    cur.totalDiscount += Number(inv.discount) || 0;
    cur.invoiceCount += 1;
    const method = inv.paymentMethod || "cash";
    if (method === "cash") {
      cur.totalCash += total;
    } else {
      cur.totalTransfer += total;
    }
    const items = inv.items || [];
    let invoiceEstimated = false;
    let invoiceMissing = false;
    if (items.length > 0) {
      items.forEach((item) => {
        const hasCost = typeof item.costPrice === "number" && item.costPrice > 0;
        const hasRecipe = Array.isArray(item.recipe) && item.recipe.length > 0;
        if (!hasCost && !hasRecipe) {
          invoiceEstimated = true;
        }
      });
    } else if (total > 0) {
      invoiceMissing = true;
    }
    if (invoiceEstimated) {
      dayHasEstimatedCostMap.set(vnDateStr, true);
    }
    if (invoiceMissing) {
      dayHasMissingCostMap.set(vnDateStr, true);
    }
    let invCost = 0;
    if (typeof inv.totalCost === "number") {
      invCost = inv.totalCost;
    } else {
      invCost = items.reduce((sum, item) => {
        const itemCost = (Number(item.costPrice) || 0) * (Number(item.quantity) || 1);
        const addOnsCost = (item.selectedAddOns || []).reduce((aSum, a) => {
          const unitCost = Number(a.costPrice) || 0;
          const qtyPerServing = typeof a.quantity === "number" && a.quantity > 0 ? a.quantity : 1;
          return aSum + unitCost * qtyPerServing * (Number(item.quantity) || 1);
        }, 0);
        return sum + itemCost + addOnsCost;
      }, 0);
      invoicesToUpdate.push({
        id: docSnap.id,
        data: {
          totalCost: invCost,
          costVersion: 1,
          costStatus: invoiceEstimated ? "estimated" : "complete",
          businessDate: vnDateStr,
          businessMonth: vnDateStr.slice(0, 7),
          businessYear: parseInt(vnDateStr.slice(0, 4), 10)
        }
      });
    }
    cur.totalCost += invCost;
  });
  const cashToUpdate = [];
  cashSnap.docs.forEach((docSnap) => {
    const tx = docSnap.data();
    if (!tx.date) return;
    const vnDateStr = tx.businessDate || getVietnamBusinessDate(tx.date);
    if (options.startDate && vnDateStr < options.startDate) return;
    if (options.endDate && vnDateStr > options.endDate) return;
    if (vnDateStr === todayStr) {
      return;
    }
    const cur = getOrCreateStats(vnDateStr);
    cur.cashCount += 1;
    const amount = Number(tx.amount) || 0;
    const isCash = tx.paymentMethod === "cash" || !tx.paymentMethod;
    const cat = (tx.category || "").toLowerCase().trim();
    if (tx.type === "income" && tx.category !== "B\xE1n h\xE0ng") {
      cur.totalIncome += amount;
      if (isCash) cur.cashIncome += amount;
      else cur.transferIncome += amount;
    } else if (tx.type === "expense") {
      cur.totalExpense += amount;
      if (isCash) cur.cashExpense += amount;
      else cur.transferExpense += amount;
      if (cat.includes("nh\u1EADp h\xE0ng") || cat.includes("mua h\xE0ng") || cat.includes("nguy\xEAn li\u1EC7u")) {
        cur.expenseInventory += amount;
      } else if (cat.includes("m\u1EB7t b\u1EB1ng") || cat.includes("thu\xEA nh\xE0") || cat.includes("ti\u1EC1n nh\xE0")) {
        cur.expenseRent += amount;
      } else if (cat.includes("l\u01B0\u01A1ng") || cat.includes("nh\xE2n s\u1EF1") || cat.includes("nh\xE2n vi\xEAn")) {
        cur.expenseSalary += amount;
      } else {
        cur.expenseOther += amount;
      }
    }
    if (!tx.businessDate) {
      cashToUpdate.push({
        id: docSnap.id,
        data: {
          businessDate: vnDateStr,
          businessMonth: vnDateStr.slice(0, 7),
          businessYear: parseInt(vnDateStr.slice(0, 4), 10)
        }
      });
    }
  });
  let daysWithEstimatedCost = 0;
  let daysWithCompleteCost = 0;
  statsMap.forEach((cur, dateKey) => {
    cur.invoicesTotalCount = cur.invoiceCount;
    cur.cashTransactionsTotalCount = cur.cashCount;
    cur.hasData = cur.invoiceCount > 0 || cur.cashCount > 0;
    if (cur.invoiceCount === 0) {
      cur.costStatus = "none";
      daysWithCompleteCost++;
    } else if (dayHasEstimatedCostMap.get(cur.date)) {
      cur.costStatus = "estimated";
      daysWithEstimatedCost++;
    } else if (dayHasMissingCostMap.get(cur.date)) {
      cur.costStatus = "partial";
    } else {
      cur.costStatus = "complete";
      daysWithCompleteCost++;
    }
    const nonSaleDiff = cur.totalIncome - (cur.cashIncome + cur.transferIncome);
    if (nonSaleDiff !== 0) cur.cashIncome += nonSaleDiff;
    const expPayDiff = cur.totalExpense - (cur.cashExpense + cur.transferExpense);
    if (expPayDiff !== 0) cur.cashExpense += expPayDiff;
    const expCatDiff = cur.totalExpense - (cur.expenseInventory + cur.expenseSalary + cur.expenseRent + cur.expenseOther);
    if (expCatDiff !== 0) cur.expenseOther += expCatDiff;
    cur.coverageStatus = cur.hasData ? "reconciled" : "zero_activity";
    cur.reconciledAt = (/* @__PURE__ */ new Date()).toISOString();
    cur.sourceVersion = 2;
    cur.version = 2;
  });
  const entries = Array.from(statsMap.entries());
  console.log(`[BACKFILL] \u0110\xE3 t\u1ED5ng h\u1EE3p ${entries.length} ng\xE0y \u0111\xF3ng s\u1ED5 (\u0111\xE3 b\u1ECF qua h\xF4m nay ${todayStr}).`);
  if (!options.dryRun && entries.length > 0) {
    for (let i = 0; i < entries.length; i += 400) {
      const chunk = entries.slice(i, i + 400);
      const batch = adminDb.batch();
      chunk.forEach(([docId, data]) => {
        batch.set(adminDb.doc(`daily_stats/${docId}`), {
          ...data,
          id: docId
        });
      });
      await batch.commit();
      console.log(`[BACKFILL] \u0110\xE3 ghi daily_stats chunk ${i + 1} - ${i + chunk.length}.`);
    }
    if (invoicesToUpdate.length > 0) {
      for (let i = 0; i < invoicesToUpdate.length; i += 400) {
        const chunk = invoicesToUpdate.slice(i, i + 400);
        const batch = adminDb.batch();
        chunk.forEach((item) => {
          batch.update(adminDb.doc(`invoices/${item.id}`), item.data);
        });
        await batch.commit();
      }
      console.log(`[BACKFILL] \u0110\xE3 c\u1EADp nh\u1EADt snapshot cho ${invoicesToUpdate.length} h\xF3a \u0111\u01A1n.`);
    }
    if (cashToUpdate.length > 0) {
      for (let i = 0; i < cashToUpdate.length; i += 400) {
        const chunk = cashToUpdate.slice(i, i + 400);
        const batch = adminDb.batch();
        chunk.forEach((item) => {
          batch.update(adminDb.doc(`cash_transactions/${item.id}`), item.data);
        });
        await batch.commit();
      }
      console.log(`[BACKFILL] \u0110\xE3 c\u1EADp nh\u1EADt businessDate cho ${cashToUpdate.length} giao d\u1ECBch s\u1ED5 qu\u1EF9.`);
    }
  }
  return {
    storeId,
    totalDaysAggregated: entries.length,
    totalInvoicesScanned: invSnap.size,
    totalCashTxsScanned: cashSnap.size,
    updatedStatsDocs: entries.length,
    daysWithEstimatedCost,
    daysWithCompleteCost,
    skippedTodayDate: todayStr,
    dryRun: options.dryRun
  };
}

// api/migrate-store.ts
async function handler10(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const caller = await getAuthenticatedCaller(req);
  if (!caller) {
    return res.status(401).json({ error: "Phi\xEAn l\xE0m vi\u1EC7c kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n." });
  }
  const isSuperAdmin = Boolean(caller.isSuperAdmin || caller.role === "superadmin");
  const isStoreAdmin = caller.role === "admin" || caller.role === "manager";
  if (!isSuperAdmin && !isStoreAdmin) {
    return res.status(403).json({ error: "B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n th\u1EF1c hi\u1EC7n migration c\u1EEDa h\xE0ng." });
  }
  const targetStoreId = isSuperAdmin ? req.body.storeId || caller.storeId : caller.storeId;
  if (!targetStoreId) {
    return res.status(400).json({ error: "Thi\u1EBFu storeId c\u1EA7n migration." });
  }
  const {
    dryRun = false,
    forceRerun = false,
    startDate,
    endDate,
    skipMenu = false,
    skipInvoices = false,
    skipCash = false,
    skipBackfill = false
  } = req.body || {};
  const lockAcquired = await acquireStoreLock(targetStoreId);
  if (!lockAcquired) {
    return res.status(409).json({
      error: "C\u1EEDa h\xE0ng \u0111ang c\xF3 ti\u1EBFn tr\xECnh migration ho\u1EB7c \u0111\u1ED1i so\xE1t \u0111ang ch\u1EA1y. Vui l\xF2ng th\u1EED l\u1EA1i sau."
    });
  }
  try {
    console.log(`[API /api/migrate-store] B\u1EAFt \u0111\u1EA7u an to\xE0n cho storeId: ${targetStoreId} (dryRun: ${dryRun}, forceRerun: ${forceRerun})`);
    let menuResult = null;
    let invoicesResult = null;
    let cashResult = null;
    let backfillResult = null;
    if (!skipMenu) {
      menuResult = await migrateStoreMenu(targetStoreId, { dryRun, forceRerun });
    }
    if (!skipInvoices) {
      invoicesResult = await migrateStoreInvoices(targetStoreId, { dryRun, forceRerun });
    }
    if (!skipCash) {
      cashResult = await migrateStoreCash(targetStoreId, { dryRun, forceRerun });
    }
    if (!skipBackfill) {
      backfillResult = await backfillStoreDailyStats(targetStoreId, { startDate, endDate, dryRun });
    }
    return res.status(200).json({
      success: true,
      storeId: targetStoreId,
      dryRun,
      menu: menuResult,
      invoices: invoicesResult,
      cash: cashResult,
      backfill: backfillResult,
      message: dryRun ? "Ch\u1EA1y th\u1EED nghi\u1EC7m (dry-run) th\xE0nh c\xF4ng. Kh\xF4ng c\xF3 d\u1EEF li\u1EC7u n\xE0o b\u1ECB ghi \u0111\xE8." : "Migration, chu\u1EA9n h\xF3a d\u1EEF li\u1EC7u v\xE0 \u0111\u1ED1i so\xE1t daily_stats ho\xE0n t\u1EA5t an to\xE0n 100%."
    });
  } catch (err) {
    console.error("[API /api/migrate-store] L\u1ED7i:", err);
    return res.status(500).json({
      success: false,
      error: err.message || "L\u1ED7i server trong qu\xE1 tr\xECnh migration."
    });
  } finally {
    await releaseStoreLock(targetStoreId);
  }
}

// server.app.ts
function checkServerReadiness() {
  const missingRequired = [];
  const warnings = [];
  const hasEncKey = Boolean(process.env.DATA_ENCRYPTION_KEY || process.env.ENCRYPTION_KEY);
  const hasJwtSec = Boolean(process.env.JWT_SECRET || process.env.ENCRYPTION_KEY);
  if (!hasEncKey) {
    missingRequired.push("DATA_ENCRYPTION_KEY");
  }
  if (!hasJwtSec) {
    missingRequired.push("JWT_SECRET");
  }
  const superPass = process.env.SUPERADMIN_PASSWORD;
  const hasSuperPass = Boolean(superPass && superPass.trim().length > 0);
  if (!hasSuperPass) {
    warnings.push("SUPERADMIN_PASSWORD ch\u01B0a thi\u1EBFt l\u1EADp; endpoint SuperAdmin b\u1ECB v\xF4 hi\u1EC7u h\xF3a.");
  }
  const adminStatus = getAdminStatus();
  const isProduction = process.env.NODE_ENV === "production";
  const requireAdmin = isProduction || process.env.REQUIRE_ADMIN_AUTH === "true";
  if (!adminStatus.hasCredential) {
    if (requireAdmin) {
      missingRequired.push("Firebase Admin Service Account (FIREBASE_SERVICE_ACCOUNT ho\u1EB7c FIREBASE_CLIENT_EMAIL & FIREBASE_PRIVATE_KEY)");
    } else {
      warnings.push("Firebase Admin Service Account ch\u01B0a cung c\u1EA5p; h\u1EC7 th\u1ED1ng \u0111ang d\xF9ng client bridge (ch\u1EC9 d\xF9ng cho dev/preview).");
    }
  } else if (!adminStatus.isInitialized) {
    missingRequired.push("Firebase Admin Service Account (ch\u1EE9ng ch\u1EC9 kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c l\u1ED7i kh\u1EDFi t\u1EA1o)");
  }
  const isReady = missingRequired.length === 0 && (!requireAdmin || adminStatus.hasCredential && adminStatus.isInitialized);
  return {
    ready: isReady,
    status: isReady ? warnings.length > 0 ? "degraded" : "ok" : "unready",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    uptime: Math.floor(process.uptime()),
    checks: {
      encryptionKey: {
        ready: hasEncKey,
        message: hasEncKey ? "Kh\xF3a m\xE3 h\xF3a \u0111\xE3 n\u1EA1p" : "Thi\u1EBFu DATA_ENCRYPTION_KEY"
      },
      jwtSecret: {
        ready: hasJwtSec,
        message: hasJwtSec ? "Kh\xF3a k\xFD JWT \u0111\xE3 n\u1EA1p" : "Thi\u1EBFu JWT_SECRET"
      },
      superadminAuth: {
        ready: true,
        configured: hasSuperPass,
        message: hasSuperPass ? "SuperAdmin password \u0111\xE3 c\u1EA5u h\xECnh" : "SuperAdmin password ch\u01B0a c\u1EA5u h\xECnh"
      },
      firebaseAdmin: {
        ready: Boolean(adminStatus.hasCredential && adminStatus.isInitialized),
        hasServiceAccount: adminStatus.hasCredential,
        isInitialized: adminStatus.isInitialized,
        message: adminStatus.hasCredential ? adminStatus.isInitialized ? "Firebase Admin SDK s\u1EB5n s\xE0ng" : "Firebase Admin SDK l\u1ED7i kh\u1EDFi t\u1EA1o" : requireAdmin ? "Thi\u1EBFu Service Account b\u1EAFt bu\u1ED9c trong production" : "\u0110ang d\xF9ng Firebase client bridge (dev mode)"
      }
    },
    missingRequired,
    warnings
  };
}
function validateServerConfig() {
  console.log("--------------------------------------------------");
  console.log("[Server Startup] \u0110ang ki\u1EC3m tra c\u1EA5u h\xECnh b\u1EA3o m\u1EADt...");
  const readiness = checkServerReadiness();
  if (readiness.checks.encryptionKey.ready && readiness.checks.jwtSecret.ready) {
    console.log("\u2705 [Security Config] Kh\xF3a m\xE3 h\xF3a & ch\u1EEF k\xFD s\u1ED1 \u0111\xE3 \u0111\u01B0\u1EE3c n\u1EA1p th\xE0nh c\xF4ng.");
  } else {
    console.warn("\u26A0\uFE0F [Security Warning] Thi\u1EBFu c\u1EA5u h\xECnh ENCRYPTION_KEY / JWT_SECRET. Session token v\xE0 m\xE3 h\xF3a y\xEAu c\u1EA7u c\u1EA5u h\xECnh bi\u1EBFn m\xF4i tr\u01B0\u1EDDng n\xE0y.");
  }
  if (readiness.checks.superadminAuth.configured) {
    console.log("\u2705 [Security Config] M\u1EADt kh\u1EA9u qu\u1EA3n tr\u1ECB t\u1ED1i cao (SuperAdmin) \u0111\xE3 \u0111\u01B0\u1EE3c b\u1EA3o v\u1EC7 qua bi\u1EBFn m\xF4i tr\u01B0\u1EDDng.");
  } else {
    console.warn("\u26A0\uFE0F [Security Warning] Bi\u1EBFn SUPERADMIN_PASSWORD ch\u01B0a \u0111\u01B0\u1EE3c thi\u1EBFt l\u1EADp. Endpoint \u0111\u0103ng nh\u1EADp SuperAdmin s\u1EBD t\u1EEB ch\u1ED1i truy c\u1EADp v\xE0 KH\xD4NG d\xF9ng m\u1EADt kh\u1EA9u m\u1EB7c \u0111\u1ECBnh.");
  }
  const adminStatus = getAdminStatus();
  if (adminStatus.hasCredential) {
    if (adminStatus.isInitialized) {
      console.log("\u2705 [Firebase Admin] Firebase Admin SDK \u0111\xE3 \u0111\u01B0\u1EE3c kh\u1EDFi t\u1EA1o b\u1EB1ng Service Account ch\u1EE9ng ch\u1EC9 h\u1EE3p l\u1EC7.");
    } else {
      console.error("\u274C [Firebase Admin] C\u1EA5u h\xECnh Service Account kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c kh\xF4ng th\u1EC3 kh\u1EDFi t\u1EA1o Admin SDK.");
    }
  } else {
    console.warn("\u2139\uFE0F [Firebase Admin] Service Account ch\u01B0a \u0111\u01B0\u1EE3c cung c\u1EA5p qua FIREBASE_SERVICE_ACCOUNT ho\u1EB7c FIREBASE_CLIENT_EMAIL/FIREBASE_PRIVATE_KEY. H\u1EC7 th\u1ED1ng \u0111ang d\xF9ng c\u01A1 ch\u1EBF bridge k\u1EBFt n\u1ED1i Firebase.");
  }
  console.log("--------------------------------------------------");
}
async function createApp() {
  const app = (0, import_express.default)();
  app.use((0, import_cors.default)());
  app.use(import_express.default.json());
  app.use(import_express.default.urlencoded({ extended: true }));
  app.get("/health", (_req, res) => {
    const readiness = checkServerReadiness();
    if (!readiness.ready) {
      return res.status(503).send(`UNREADY: Missing ${readiness.missingRequired.join(", ")}`);
    }
    return res.status(200).send("OK");
  });
  app.get("/_health", (_req, res) => {
    const readiness = checkServerReadiness();
    if (!readiness.ready) {
      return res.status(503).send(`UNREADY: Missing ${readiness.missingRequired.join(", ")}`);
    }
    return res.status(200).send("OK");
  });
  app.get("/api/health", (_req, res) => {
    const readiness = checkServerReadiness();
    const httpStatus = readiness.ready ? 200 : 503;
    return res.status(httpStatus).json({
      port: Number(process.env.PORT) || 3e3,
      ...readiness
    });
  });
  app.get("/api/ready", (_req, res) => {
    const readiness = checkServerReadiness();
    const httpStatus = readiness.ready ? 200 : 503;
    return res.status(httpStatus).json(readiness);
  });
  app.post("/api/login", (req, res) => handler(req, res));
  app.post("/api/reveal-password", (req, res) => handler2(req, res));
  app.post("/api/reset-password", (req, res) => handler9(req, res));
  app.post("/api/sepay-webhook", (req, res) => handler3(req, res));
  app.post("/api/sepay/webhook", (req, res) => handler3(req, res));
  app.post("/api/save-user", (req, res) => handler4(req, res));
  app.post("/api/change-password", (req, res) => handler5(req, res));
  app.post("/api/delete-user", (req, res) => handler6(req, res));
  app.post("/api/delete-store", (req, res) => handler7(req, res));
  app.post("/api/register-store", (req, res) => handler8(req, res));
  app.post("/api/migrate-store", (req, res) => handler10(req, res));
  const distPath = import_path.default.join(process.cwd(), "dist");
  const hasDist = import_fs.default.existsSync(import_path.default.join(distPath, "index.html"));
  const isDev = process.env.VITE_DEV === "true" && process.env.NODE_ENV !== "production" && !process.env.K_SERVICE;
  if (isDev || !hasDist) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    app.use(import_express.default.static(distPath));
    app.get("*all", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  return app;
}
async function createAndStartServer() {
  validateServerConfig();
  const PORT = Number(process.env.PORT) || 3e3;
  const app = await createApp();
  const isDev = process.env.VITE_DEV === "true" && process.env.NODE_ENV !== "production" && !process.env.K_SERVICE;
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (mode: ${isDev ? "development" : "production"})`);
  });
  return server;
}

// server.entry.ts
createAndStartServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
