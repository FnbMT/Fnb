import React, { useState, useEffect } from 'react';
import { Coffee, Lock, User as UserIcon, AlertCircle, Loader2, ExternalLink, Wifi, WifiOff, QrCode, Download } from 'lucide-react';
import { User } from '../types';
import { motion } from 'motion/react';
import { db, auth } from '../lib/firebase';
import { signInWithCustomToken } from 'firebase/auth';
import { collection, query, where, getDocs, limit, doc, getDoc, updateDoc } from 'firebase/firestore';
import { Capacitor } from '@capacitor/core';

import { apiUrl } from '../utils/apiConfig';

export const LoginView = ({ onLogin, onRegisterClick }: { onLogin: (user: User) => void, onRegisterClick?: () => void }) => {
  const isNative = Capacitor.isNativePlatform();
  const [apkUrl, setApkUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!isNative) {
      const fetchApk = async () => {
        try {
          const snap = await getDoc(doc(db, 'app_settings', 'android_version'));
          if (snap.exists() && snap.data().apkUrl) {
            setApkUrl(snap.data().apkUrl);
          }
        } catch (e) {}
      };
      fetchApk();
    }
  }, [isNative]);

  const [storeCode, setStoreCode] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [debugInfo, setDebugInfo] = useState<string>('');

  useEffect(() => {
    const checkConnection = async () => {
      try {
        // Cài đặt bộ đếm thời gian 15 giây để chống treo vô hạn
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('TIMEOUT_15S')), 15000)
        );
        // Kiểm tra kết nối qua tài liệu cài đặt công khai thay vì đọc bảng users
        const queryPromise = getDoc(doc(db, 'app_settings', 'android_version'));
        
        await Promise.race([queryPromise, timeoutPromise]);
        
        setConnectionStatus('online');
      } catch (err: any) {
        console.error('Firebase connection check failed:', err);
        setConnectionStatus('offline');
        
        const errMsg = err?.message || err?.toString() || 'Unknown error';
        const errCode = err?.code ? ` [Code: ${err.code}]` : '';
        setDebugInfo(`${errMsg}${errCode}`);
      }
    };
    checkConnection();
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (!storeCode) {
        setError('Vui lòng nhập Mã Cửa Hàng');
        setLoading(false);
        return;
      }

      // 1. GỌI API ĐĂNG NHẬP BẢO MẬT PHÍA SERVER (sử dụng apiUrl tương thích cả Web và Native APK)
      try {
        const resp = await fetch(apiUrl('/api/login'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            storeCode: storeCode.trim(),
            username: username.trim(),
            password: password.trim()
          })
        });

        if (resp.ok) {
          const result = await resp.json();
          if (result.success && result.user) {
            // Xác thực với Firebase Auth qua Custom Token nếu có
            if (result.customToken && !result.customToken.startsWith('dev_token_')) {
              try {
                await signInWithCustomToken(auth, result.customToken);
              } catch (authErr: any) {
                console.error("signInWithCustomToken failed:", authErr);
                setError(`Không thể xác thực phiên làm việc Firebase: ${authErr?.message || 'Lỗi phiên đăng nhập'}. Vui lòng thử lại.`);
                setLoading(false);
                return; // Dừng lại ngay lập tức, không mở phiên dữ liệu khi chưa có Firebase Auth hợp lệ
              }
            } else if (!result.customToken && result.user?.role !== 'superadmin' && import.meta.env.PROD) {
              console.error("[Login Security] Server returned no customToken in production mode.");
              setError("Máy chủ chưa cấu hình chứng chỉ Firebase Admin để xác thực phiên bảo mật. Vui lòng liên hệ Quản trị viên.");
              setLoading(false);
              return;
            }

            onLogin(result.user);
            return;
          }
        } else {
          // Server đã phản hồi từ chối (401, 403, 404, 429, 500, 503) -> Dừng lại và hiển thị lỗi, KHÔNG fallback
          const errData = await resp.json().catch(() => ({}));
          setError(errData.error || 'Tên đăng nhập hoặc mật khẩu không đúng');
          setLoading(false);
          return;
        }
      } catch (apiErr) {
        console.warn("API login network unreachable, fallback sang kiểm tra trực tiếp:", apiErr);
      }

      // 2. FALLBACK NGOẠI TUYẾN / MẤT KẾT NỐI SERVER (Chỉ áp dụng khi máy chủ không phản hồi)
      const storeQuery = query(collection(db, 'stores'), where('code', '==', storeCode.toLowerCase().trim()));
      const storeSnapshot = await getDocs(storeQuery);
      
      if (storeSnapshot.empty) {
        setError('Mã cửa hàng không tồn tại');
        setLoading(false);
        return;
      }

      const storeDoc = storeSnapshot.docs[0];
      const storeId = storeDoc.id;
      const storeData = storeDoc.data();

      if (storeData.subscription && storeData.subscription.status === 'blocked') {
        setError('Cửa hàng đã bị khóa. Vui lòng liên hệ Admin.');
        setLoading(false);
        return;
      }

      const q = query(
        collection(db, 'users'), 
        where('storeId', '==', storeId), 
        where('username', '==', username.toLowerCase().trim()), 
        where('password', '==', password.trim())
      );
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const userDoc = querySnapshot.docs[0];
        const userData = userDoc.data();
        
        try {
          await updateDoc(doc(db, 'users', userDoc.id), {
            lastLogin: new Date().toISOString()
          });
        } catch (e) {}

        onLogin({
          ...userData,
          id: userDoc.id,
          store: storeData
        } as any);
      } else {
        setError('Tên đăng nhập hoặc mật khẩu không đúng');
      }
    } catch (err: any) {
      console.error(err);
      setError('Lỗi kết nối. Hãy thử lại hoặc kiểm tra kết nối mạng.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0a0a0a] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white dark:bg-[#151619] border border-black/10 dark:border-white/10 rounded-3xl p-8 shadow-2xl space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
            <Coffee className="w-10 h-10 text-black" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white tracking-tighter">FNB MASTER</h1>
          <p className="text-gray-500">Đăng nhập để bắt đầu ca làm việc</p>
          
          <div className="flex justify-center pt-2">
            {connectionStatus === 'checking' && (
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Loader2 className="w-3 h-3 animate-spin" /> Đang kiểm tra kết nối...
              </div>
            )}
            {connectionStatus === 'online' && (
              <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full">
                <Wifi className="w-3 h-3" /> Hệ thống sẵn sàng
              </div>
            )}
            {connectionStatus === 'offline' && (
              <div className="flex flex-col items-center gap-2">
                <div className="flex items-center gap-2 text-xs text-rose-600 dark:text-rose-500 bg-rose-500/10 px-3 py-1 rounded-full">
                  <WifiOff className="w-3 h-3" /> Lỗi kết nối
                </div>
                {debugInfo && (
                  <div className="text-[10px] text-rose-500/80 bg-rose-500/10 p-2 rounded-lg max-w-xs text-center break-words border border-rose-500/20">
                    <span className="font-bold">MÃ LỖI:</span> {debugInfo}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            <div className="relative">
              <QrCode className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input 
                type="text" 
                placeholder="Mã cửa hàng"
                className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl py-4 pl-12 pr-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50 transition-all"
                value={storeCode}
                onChange={(e) => setStoreCode(e.target.value)}
                required
              />
            </div>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input 
                type="text" 
                placeholder="Tên đăng nhập"
                className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl py-4 pl-12 pr-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50 transition-all"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input 
                type="password" 
                placeholder="Mật khẩu"
                className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl py-4 pl-12 pr-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50 transition-all"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-4 flex flex-col gap-3 text-rose-600 dark:text-rose-500 text-sm">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 shrink-0" />
                {error}
              </div>
              {connectionStatus === 'offline' && (
                <a 
                  href={window.location.href} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 py-2 bg-rose-500 text-white rounded-lg font-bold hover:bg-rose-600 transition-all"
                >
                  <ExternalLink className="w-4 h-4" /> MỞ TRONG TAB MỚI
                </a>
              )}
            </div>
          )}

          <button 
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-emerald-500 text-white font-bold rounded-2xl shadow-lg shadow-emerald-500/20 hover:bg-emerald-400 transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'ĐĂNG NHẬP'}
          </button>
        </form>

          <div className="pt-4 border-t border-black/5 dark:border-white/5 text-center space-y-4">
            {!isNative && apkUrl && (
              <div>
                <a href={apkUrl} target="_blank" rel="noopener noreferrer" className="w-full flex items-center justify-center gap-2 bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 font-bold py-3 px-4 rounded-xl hover:bg-emerald-200 dark:hover:bg-emerald-500/30 transition-colors text-sm">
                  <Download className="w-4 h-4" /> Tải App Android (APK)
                </a>
              </div>
            )}

            {!isNative && onRegisterClick && (
              <div className="space-y-1">
                <p className="text-gray-500 text-sm">Chưa có tài khoản cửa hàng?</p>
                <button 
                  type="button"
                  onClick={onRegisterClick}
                  className="text-emerald-600 dark:text-emerald-500 font-bold hover:text-emerald-400 transition-colors cursor-pointer text-sm"
                >
                  TẠO TÀI KHOẢN CỬA HÀNG MỚI
                </button>
              </div>
            )}

            <div className="flex flex-col gap-2">
              <a 
                href={window.location.href} 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex justify-center items-center gap-2 text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors"
              >
                <ExternalLink className="w-3 h-3" /> Tải lại trang
              </a>
            </div>

            <div className="pt-2 overflow-hidden w-full flex justify-center">
              <p className="text-[10px] sm:text-xs text-gray-400 dark:text-gray-600 uppercase tracking-widest whitespace-nowrap overflow-hidden text-ellipsis text-center">HỆ THỐNG QUẢN LÝ NHÀ HÀNG CHUYÊN NGHIỆP</p>
            </div>
          </div>
      </motion.div>
    </div>
  );
};
