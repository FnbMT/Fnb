# Bản sửa logic cho Fnb Master — dựa trên bản 19

Gói này chứa **đầy đủ nội dung của 14 tệp cần thay thế và 3 tệp mới**, giữ nguyên đường dẫn tương đối của dự án. Đây là gói chép đè, không phải toàn bộ dự án.

## Cách áp dụng

1. Sao lưu mã nguồn bản 19 đang sử dụng.
2. Giải nén gói này. Chép các thư mục `src/`, `scripts/`, `api/` vào thư mục gốc của dự án bản 19; chọn ghi đè các tệp trùng tên. Phải chép **đủ 17 tệp**, gồm cả 3 tệp mới, vì các tệp đã sửa có import chúng.
3. Không xóa các tệp khác trong dự án. Gói không có YAML, package.json, lockfile, thư mục native hay cấu hình build để chép đè.
4. Chạy `npm ci`, `npm run lint`, `npm run build` với cấu hình và phiên bản sẵn có của dự án. Sau đó tiếp tục quy trình TestFlight và tạo APK hiện tại của bạn.
5. Nếu sử dụng API migrate/đối soát, cập nhật cả `api/migrate-store.ts` và hai tệp `scripts/` lên backend đang phục vụ ứng dụng. Chép mã vào ứng dụng mobile không tự cập nhật backend đã triển khai.
6. Cập nhật các thiết bị làm việc cùng cửa hàng. Ứng dụng phiên bản cũ vẫn có thể ghi dữ liệu theo luồng cũ nếu tiếp tục dùng song song.

Không tự chạy migration vào dữ liệu thật trong lần sửa này. Mã không tự xóa dữ liệu cửa hàng khi khởi động.

## Danh sách tệp

### Thay thế 14 tệp

| Tệp | Nội dung sửa chính |
|---|---|
| `src/App.tsx` | Gọi các thao tác transaction; lưu đơn trước thanh toán; xác nhận ca trên server; dùng nguồn đủ cho hôm nay, lương, khách; trạng thái đang đồng bộ; giữ cấu hình build. |
| `src/types.ts` | Bổ sung ID dòng món, snapshot biến động kho, điểm tích lũy và revision nguồn. |
| `src/utils/costHelper.ts` | Kiểm tra nguồn giá vốn, số hợp lệ và giữ trạng thái ước tính khi thiếu nguồn. |
| `src/components/InventoryView.tsx` | Chờ nhập/kiểm/sửa kho thành công; giữ dữ liệu khi lỗi; operation ID cho thử lại; độ chính xác 0,001. |
| `src/components/KitchenView.tsx` | Hiển thị xung đột/lỗi cập nhật thay vì nuốt lỗi. |
| `src/components/CustomerView.tsx` | Bỏ kết quả tìm kiếm cũ trả về muộn. Nguồn khách trong App không còn bị cắt ở 100. |
| `src/components/MyPayrollView.tsx` | Công theo ngày không bị nhân bởi nhiều lượt vào/ra; giờ theo khoảng thời gian thực; cảnh báo dữ liệu chưa xác nhận. |
| `src/components/UserMgmtView.tsx` | Cùng quy tắc tính công; chặn chốt khi chưa đủ dữ liệu hoặc còn lượt chưa kết thúc; xử lý lỗi lưu. |
| `src/components/ShiftView.tsx` | Chờ xác nhận đóng ca trước khi đóng biểu mẫu và nhắc chấm ra. |
| `src/components/SummaryView.tsx` | Nguồn đầy đủ theo kỳ; không lấy trang danh sách làm tổng; đối chiếu phiếu thu; cập nhật khi hủy; chi phí ngày; doanh thu món gồm topping, phân bổ giảm giá theo đồng; nguồn lương rõ ràng. |
| `src/components/TaxReportView.tsx` | Theo dõi đủ hóa đơn năm; xóa khỏi báo cáo khi nguồn xóa; không giữ hóa đơn hủy trong cache; chặn in/xuất khi chưa xác nhận đủ. |
| `scripts/backfill_daily_stats.ts` | So revision/updateTime trước khi ghi aggregate; bỏ qua ngày vừa có giao dịch thay đổi; đặt lại ngày đã hết hoạt động; giữ nhãn giá vốn ước tính. |
| `scripts/migrate_legacy_data.ts` | Khóa tác vụ có chủ sở hữu bằng transaction; không tự nhận giá vốn dựng lại từ dữ liệu cũ là đầy đủ. |
| `api/migrate-store.ts` | Dùng token chủ sở hữu khi giải phóng khóa; thông báo đúng nếu có ngày phải bỏ qua/chạy lại. |

### Thêm 3 tệp mới

| Tệp | Vai trò |
|---|---|
| `src/services/dataOperations.ts` | Transaction cho order, bếp, gộp/chuyển bàn, thu chi, nhập/kiểm kho, hủy hóa đơn, chấm công. |
| `src/utils/dataIntegrity.ts` | ID thao tác, chữ ký dòng/đơn, tổng hợp nguồn, đánh giá giá vốn, đối soát phiếu thu, tính công, phân bổ doanh thu món. |
| `src/utils/completeDataSource.ts` | Nguồn chứng từ không bị giới hạn trang; phân biệt cache/chờ đồng bộ với dữ liệu được server xác nhận; fallback không cắt 100/300. |

## Các hành vi cần biết sau khi áp dụng

- Đơn nháp được lưu thành đơn có ID ổn định trên server trước khi thanh toán. Nếu thanh toán chưa thành công, đơn đã lưu vẫn ở bàn để thực hiện tiếp; không tạo lại hóa đơn chỉ vì bước cập nhật hết hàng/in ấn lỗi.
- Cập nhật bếp giữ các món/đơn mới do máy khác thêm. Hai máy hoàn thành hai dòng khác nhau không ghi đè trạng thái của nhau. Thêm món vào dòng đã làm xong tạo phần chờ làm riêng.
- Gộp/chuyển bàn, nhập/kiểm kho, thu chi ghi đồng bộ trong transaction. Khi phát hiện dữ liệu đã đổi, thao tác bị từ chối để bạn kiểm tra lại, không âm thầm ghi đè.
- Mỗi hóa đơn mới lưu chính xác lượng kho đã trừ. Hủy dựa trên snapshot này, không suy lại từ cờ theo dõi kho hoặc công thức đã thay đổi.
- Hủy hóa đơn điều chỉnh đúng ca theo shiftId. Với ca đã đóng, giữ số tiền kiểm đếm ban đầu, tính lại chênh lệch sau điều chỉnh và đánh dấu cần kiểm tra; không xóa dấu vết kiểm đếm cũ.
- Hóa đơn cũ không có snapshot biến động kho sẽ thử dùng thẻ xuất kho liên kết. Nếu không có căn cứ, hệ thống lưu trạng thái cần đối soát và thông báo; không tự cộng kho theo suy đoán.
- Chấm công dùng ngày Việt Nam, có khóa chống hai máy cùng mở lượt và có thể đóng lượt còn mở từ hôm trước. Không tự gán 8 giờ làm khi thiếu giờ ra. Nhiều lượt trong cùng ngày chỉ tính tối đa một ngày công; các giờ bị trùng không cộng hai lần.
- Màn hình báo cáo dùng đủ chứng từ của khoảng ngày/năm chọn. Khi chỉ có dữ liệu cache, chưa xác nhận server hoặc hóa đơn không khớp phiếu thu, có cảnh báo và chặn xuất số liệu chưa đối soát.
- Sổ quỹ hiển thị số phát sinh thực theo phiếu thu/chi. Chưa có sổ số dư chuyển kỳ thì không lấy tổng tiền đầu ca bàn giao để giả lập tồn két. Nhãn thể hiện phát sinh ròng trong kỳ, không khẳng định đó là tồn quỹ thực tế.
- Chi phí lương mặc định theo phiếu chi thực tế của kỳ. Có lựa chọn xem theo các bảng lương đã chốt, được ghi rõ là tạm tính và chưa bao gồm nhân viên chưa chốt; hai nguồn không cộng chồng. Chỉ nguồn bảng lương tháng mới phân bổ theo số ngày thực của tháng khi xem ngày. Chi tiền mặt bằng của ngày không bị chia thêm cho 30.
- Doanh thu bán hàng vẫn theo tổng tiền hóa đơn đang lưu, gồm VAT; doanh thu theo món được phân bổ sau giảm giá, trước VAT và có tính món kèm. Không chuyển đổi hồi tố cơ sở thuế của dữ liệu cũ trong bản sửa này.
- Báo cáo đọc đủ chứng từ của kỳ nên kỳ dài/nhiều giao dịch có thể tăng lượt đọc và thời gian nạp so với cách chỉ lấy 100/300 bản ghi. Không dùng số liệu của một trang để công bố tổng kỳ.
- Hóa đơn/phiếu kiểm quá lớn được chặn trước khi ghi để tránh vượt giới hạn transaction; không tự tách thành các lần ghi dở dang.

## Dữ liệu lịch sử

Sửa code không khôi phục được món đã từng bị ghi đè hay chứng từ chưa từng được lưu. Các bản ghi đã lệch cần đối chiếu với hóa đơn, phiếu thu, thẻ kho và kiểm đếm thực tế. Báo cáo mới tính lại từ chứng từ hiện còn trên server; không dựa vào một aggregate cũ chưa được chứng minh đầy đủ.

Giá vốn cũ thiếu chứng cứ vẫn được giữ nhãn ước tính. Không tự sửa số để che chênh lệch. Nếu chạy lại backfill, dùng dry-run và sao lưu dữ liệu trước; các ngày có giao dịch đổi trong lúc quét được trả trong `skippedChangedDays` để chạy lại.

## Kiểm tra đã thực hiện

- TypeScript: `npm run lint` — đạt.
- Build web và server: `npm run build` — đạt.
- 51/51 ca kiểm thử mức hàm — đạt, bao gồm cạnh tranh transaction, rollback nguyên tử, thử lại, hoàn kho/ca, báo cáo, thu chi, giá vốn, chấm công, backfill và metadata cache.
- Kiểm tra byte của **189 tệp cấu hình/native/phụ thuộc** với ZIP bản 19: giữ nguyên. Bao gồm YAML, package.json, package-lock.json, bun.lock, iOS, Android, Capacitor, Vite, TypeScript, Firestore Rules/indexes.
- Không dùng Firebase cửa hàng thật trong các kiểm thử. Không chạy archive iOS hay tạo APK tại môi trường kiểm tra này; cần xác nhận hai bản native bằng pipeline hiện tại của bạn.

`verification/test-results.json` có kết quả từng ca. `verification/file-manifest.json` có danh sách và SHA-256 từng tệp cần thay.

Nếu muốn chạy lại các kiểm thử giả lập sau khi chép đủ tệp và cài phụ thuộc hiện có:

```bash
node verification/regression.cjs
```

Các kiểm thử giả lập không thay thế kiểm thử Firebase Emulator/thiết bị thật, offline/online và nhiều máy trước khi đưa bản sửa vào vận hành.
