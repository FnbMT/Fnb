import { safeStorage } from './lib/storage';
import { SubscriptionModal } from './components/SubscriptionAlert';
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from 'react';
export const LiveTimer = ({ startTime }: { startTime: string | undefined }) => {
  const [elapsed, setElapsed] = useState('--:--');

  useEffect(() => {
    if (!startTime) {
      setElapsed('--:--');
      return;
    }

    const start = new Date(startTime).getTime();
    
    const updateTimer = () => {
      const now = Date.now();
      const diff = now - start;
      if (diff < 0) {
        setElapsed('00:00');
        return;
      }
      
      const totalSeconds = Math.floor(diff / 1000);
      const hours = Math.floor(totalSeconds / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;
      
      if (hours > 0) {
        setElapsed(`${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      } else {
        setElapsed(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      }
    };

    updateTimer();
    const intervalId = setInterval(updateTimer, 1000);
    return () => clearInterval(intervalId);
  }, [startTime]);

  return <span>{elapsed}</span>;
};

import { LayoutDashboard, 
  UtensilsCrossed, 
  ChefHat, 
  BarChart3, 
  Search, 
  Plus, 
  Minus, 
  Trash2,
  DollarSign, 
  Clock, 
  FileText,
  User as UserIcon, 
  ChevronRight,
  Coffee,
  CheckCircle2,
  AlertCircle,
  Package,
  Users,
  Wallet,
  Settings,
  LogOut,
  Bell,
  Shield,
  Check,
  X,
  Printer,
  Lock,
  LayoutGrid,
  ShoppingCart,
  Flame,
  CheckCheck,
  Smartphone,
  BellRing,
  ArrowRightLeft, Sun, Moon, QrCode } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, isSameDay, parseISO, subDays } from 'date-fns';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { cn } from './lib/utils';
import { 
  Table, 
  MenuItem, 
  OrderItem, 
  AddOnItem,
  OrderSession,
  VoidItemDetail,
  VoidLog,
  ViewType, 
  Invoice,
  InventoryTransaction,
  SystemSettings,
  TableGroup,
  InventoryAudit,
  StockCardEntry,
  AttendanceRecord,
  PayrollRecord,
  INITIAL_MENU, 
  INITIAL_TABLES, 
  CATEGORIES,
  INITIAL_USERS,
  User,
  Shift,
  CashTransaction,
  Customer,
  CustomerType
} from './types';

import { db, auth } from './lib/firebase';
import { signOut } from 'firebase/auth';
import { apiUrl } from './utils/apiConfig';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  deleteDoc, 
  doc, 
  updateDoc,
  getDoc,
  getDocs,
  getDocFromServer,
  setDoc,
  deleteField,
  writeBatch,
  limit,
  orderBy,
  increment,
  arrayUnion,
  arrayRemove,
  runTransaction
} from 'firebase/firestore';
import { 
  getVietnamStartOfTodayIso, 
  getVietnamBusinessDate, 
  getVietnamDayBoundariesIso,
  getVietnamHeaderDateString,
  getVietnamYesterdayDate
} from './utils/firestoreDateHelper';

// Import new views
import { InventoryView } from './components/InventoryView';
import { SuperAdminView } from './components/SuperAdminView';
import { CustomerView } from './components/CustomerView';
import { TaxReportView } from './components/TaxReportView';
import { ShiftView } from './components/ShiftView';
import { MenuMgmtView } from './components/MenuMgmtView';
import { UserMgmtView } from './components/UserMgmtView';
import { LoginView } from './components/LoginView';
import { RegisterStoreView } from './components/RegisterStoreView';
import { SummaryView } from './components/SummaryView';
import { SettingsView } from './components/SettingsView';
import { PrinterService } from './services/printerService';
import { Capacitor } from '@capacitor/core';
import { SubscriptionAlert } from './components/SubscriptionAlert';
import { CheckInView } from './components/CheckInView';
import { MyPayrollView } from './components/MyPayrollView';
import { AttendanceScanner } from "./components/AttendanceScanner";
import { getMenuItemImage } from "./utils/foodImageHelper";
import { KitchenView } from './components/KitchenView';
import { checkStoreTabPermission, isTabAllowedInPackage, APP_PACKAGE_TABS } from './utils/packagePermissions';
import { calculateInvoiceCost, calculateInvoiceCostSnapshot } from './utils/costHelper';
import { isCashPayment } from './utils/reportDataIntegrity';
import { operationId, cloneData, orderSignature, itemsSubtotal, stockQuantity, itemKey, attendanceTotals } from './utils/dataIntegrity';
import { subscribeDateRange, fetchStoreRows } from './utils/completeDataSource';
import { addOrderAtomic, updateOrdersAtomic, moveTablesAtomic, recordCashAtomic, importStockAtomic, auditStockAtomic, cancelInvoiceAtomic, recordAttendanceAtomic } from './services/dataOperations';
import {
  sendDeviceNotification,
  checkNotificationPermission,
  requestNotificationPermission,
  isDeviceNotificationEnabled,
  setDeviceNotificationEnabled,
  seedInitialNotificationIds,
  hasNotificationBeenSent
} from './utils/deviceNotification';

// --- Components ---

const LockedTabView = ({ title, onUpgrade }: { title: string, onUpgrade: () => void }) => {
  const isNative = Capacitor.isNativePlatform();

  return (
    <div className="flex flex-col items-center justify-center h-full min-h-[400px] p-8 text-center space-y-4">
      <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-500 border border-amber-500/20 flex items-center justify-center shadow-lg">
        <Lock className="w-8 h-8" />
      </div>
      <div className="max-w-md space-y-2">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">
          Tính năng "{title}" chưa được kích hoạt
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
          {isNative 
            ? 'Gói dịch vụ hiện tại của cửa hàng chưa bao gồm quyền sử dụng tính năng này. Vui lòng liên hệ Quản trị viên hoặc đăng nhập trên trình duyệt Web máy tính để nâng cấp gói dịch vụ.'
            : 'Gói dịch vụ hiện tại của cửa hàng chưa bao gồm quyền sử dụng tính năng này. Vui lòng liên hệ Quản trị viên hoặc nâng cấp gói để mở khóa toàn bộ tiện ích.'}
        </p>
      </div>
      {!isNative && (
        <button
          onClick={onUpgrade}
          className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white rounded-xl font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all cursor-pointer"
        >
          Nâng cấp gói dịch vụ
        </button>
      )}
    </div>
  );
};

const Sidebar = ({ activeView, setView, onLogout, currentUser, unresolvedShiftsCount, packages }: { 
  activeView: ViewType, 
  setView: (v: ViewType) => void,
  onLogout: () => void,
  currentUser: User | null,
  unresolvedShiftsCount: number,
  packages: any[]
}) => {
  const allMenuItems = [
    { id: 'tables', label: 'Phòng bàn', icon: LayoutDashboard },
    { id: 'menu_mgmt', label: 'Thực đơn', icon: UtensilsCrossed },
    { id: 'kitchen', label: 'Nhà bếp', icon: ChefHat },
    { id: 'inventory', label: 'Kho hàng', icon: Package },
    { id: 'customers', label: 'Khách hàng', icon: Users },
    { id: 'shifts', label: 'Ca làm việc', icon: Wallet },
    { id: 'reports', label: 'Báo cáo doanh thu', icon: BarChart3 },
    { id: 'tax_report', label: 'Báo cáo bán hàng', icon: FileText }
  ];

  const currentPackageIdForMenu = currentUser?.store?.subscription?.packageId || 'trial';
  const currentPackageForMenu = packages.find(p => p.id === currentPackageIdForMenu);

  const isFeatureAllowedInMenu = (tabId: string): boolean => {
    return checkStoreTabPermission(tabId, currentUser, packages);
  };

  const menuItems = allMenuItems.filter(item => {
    if (!currentUser) return false;
    if (currentUser.role === 'admin' || currentUser.role === 'manager') return true;
    if (currentUser.role === 'order') {
      // Order staff only needs tables and shifts
      return ['tables', 'shifts'].includes(item.id);
    }
    if (currentUser.role === 'cashier' || currentUser.role === 'order_cashier') {
      // Cashier needs tables and shifts (summary is added below)
      return ['tables', 'shifts'].includes(item.id);
    }
    if (currentUser.role === 'kitchen') {
      return ['kitchen', 'shifts'].includes(item.id);
    }
    return ['tables'].includes(item.id); // Default for staff
  });

  if (currentUser?.role === 'admin' || currentUser?.role === 'manager') {
    menuItems.push({ id: 'user_mgmt', label: 'Nhân viên', icon: Shield });
  }
  
  if (currentUser?.role !== 'admin') {
    menuItems.push({ id: 'my_payroll', label: 'Chấm công', icon: DollarSign });
  }

  // Summary: only for admin, manager, cashier, order_cashier (Hidden from order staff)
  if (currentUser && ['admin', 'manager', 'cashier', 'order_cashier'].includes(currentUser.role)) {
    menuItems.push({ id: 'summary', label: 'Tổng kết', icon: FileText });
  }

  // Settings: admin, manager, cashier, order_cashier, kitchen (Hidden from order staff to keep UI clean and focused)
  if (currentUser && ['admin', 'manager', 'cashier', 'order_cashier', 'kitchen'].includes(currentUser.role)) {
    menuItems.push({ id: 'settings', label: 'Cài đặt', icon: Settings });
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-64 bg-white dark:bg-[#151619] text-gray-900 dark:text-white h-screen flex-col border-r border-black/10 dark:border-white/10 shrink-0">
        <div className="p-6 border-b border-black/5 dark:border-white/5">
          <h1 className="text-xl font-bold tracking-tighter flex items-center gap-2">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <Coffee className="w-5 h-5 text-black" />
            </div>
            FNB MASTER
          </h1>
        </div>
        
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => {
            const isAllowed = isFeatureAllowedInMenu(item.id);
            return (
              <button
                key={item.id}
                onClick={() => setView(item.id as ViewType)}
                className={cn(
                  "w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group cursor-pointer",
                  activeView === item.id 
                    ? "bg-emerald-500 text-white font-semibold shadow-lg shadow-emerald-500/20" 
                    : "text-gray-600 dark:text-gray-400 hover:bg-black/5 dark:hover:bg-white/5 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative">
                    <item.icon className={cn("w-5 h-5", activeView === item.id ? "text-black" : "group-hover:text-white")} />
                    {item.id === 'shifts' && unresolvedShiftsCount > 0 && (
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-rose-500 rounded-full border-2 border-[#151619]"></div>
                    )}
                  </div>
                  <span className="text-sm truncate">{item.label}</span>
                </div>
                {!isAllowed && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-1 shrink-0 ml-1">
                    <Lock className="w-3 h-3" /> Gói
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-black/5 dark:border-white/5 space-y-2">
          <button 
            onClick={() => setView('settings')}
            className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-500 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer"
          >
            <Settings className="w-4 h-4" /> Cài đặt hệ thống
          </button>
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-black/5 dark:bg-white/5">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-600 dark:text-emerald-500 font-bold text-xs">
              {currentUser?.name.charAt(0)}
            </div>
            <div className="flex-1 overflow-hidden text-sm">
              <p className="font-medium truncate text-gray-900 dark:text-white">{currentUser?.name}</p>
              <p className="text-[10px] text-gray-500 uppercase truncate">{currentUser?.role}</p>
            </div>
            <button 
              onClick={onLogout}
              className="text-gray-500 hover:text-rose-500 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 h-[calc(4rem+env(safe-area-inset-bottom))] pb-[env(safe-area-inset-bottom)] bg-white dark:bg-[#151619] border-t border-black/10 dark:border-white/10 flex items-center justify-start px-4 z-40 overflow-x-auto no-scrollbar gap-2">
        {menuItems.map((item) => {
          const isAllowed = isFeatureAllowedInMenu(item.id);
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id as ViewType)}
              className={cn(
                "flex flex-col items-center justify-center min-w-[60px] h-full gap-1 transition-all duration-200 relative",
                activeView === item.id 
                  ? "text-emerald-600 dark:text-emerald-500" 
                  : "text-gray-500 hover:text-gray-900 dark:hover:text-white"
              )}
            >
              <div className="relative">
                <item.icon className={cn("w-5 h-5", activeView === item.id && "fill-current")} />
                {item.id === 'shifts' && unresolvedShiftsCount > 0 && (
                  <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white dark:border-[#151619]"></div>
                )}
                {!isAllowed && (
                  <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 text-white rounded-full flex items-center justify-center text-[8px] font-bold">
                    <Lock className="w-2 h-2" />
                  </div>
                )}
              </div>
              <span className="text-[10px] font-medium whitespace-nowrap">{item.label}</span>
            </button>
          );
        })}
        <button 
            onClick={onLogout}
            className="flex flex-col items-center justify-center min-w-[60px] h-full gap-1 text-rose-600 dark:text-rose-500/70 hover:text-rose-500"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-[10px] font-medium whitespace-nowrap">Thoát</span>
        </button>
      </div>
    </>
  );
};

const TableGrid = ({ tables, onSelectTable, onDeleteTable, onEditTable, currentUser, kitchenEnabled = true }: { 
  tables: Table[], 
  onSelectTable: (t: Table) => void, 
  onDeleteTable: (id: string) => void,
  onEditTable: (t: Table) => void,
  currentUser: any,
  kitchenEnabled?: boolean
}) => {
  const isAdminOrManager = currentUser?.role === 'admin' || currentUser?.role === 'manager';
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 md:gap-4 p-4 md:p-6 overflow-y-auto pb-20 md:pb-6">
      {tables.map((table) => (
        <motion.div
          key={table.id}
          whileHover={{ scale: 1.02 }}
          className={cn(
            "relative min-h-[8rem] rounded-2xl p-4 flex flex-col justify-between text-left transition-all border-2 group",
            table.status === 'occupied' 
              ? "bg-emerald-500/10 border-emerald-500/50 text-emerald-600 dark:text-emerald-400" 
              : table.status === 'reserved'
              ? "bg-amber-500/10 border-amber-500/50 text-amber-600 dark:text-amber-400"
              : "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:border-white/20"
          )}
        >
          <div className="flex justify-between items-start">
            <button 
              onClick={() => onSelectTable(table)}
              className="font-bold text-lg flex-1 text-left cursor-pointer"
            >
              {table.name}
            </button>
            <div className="flex items-center gap-2">
              {isAdminOrManager && (
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onEditTable(table);
                }}
                className="p-1.5 bg-black/10 dark:bg-white/10 rounded-md text-gray-800 dark:text-gray-200 hover:bg-emerald-500/20 hover:text-emerald-600 dark:hover:text-emerald-400 transition-all cursor-pointer shadow-sm"
              >
                <Settings className="w-4 h-4" />
              </button>
              )}
              {table.status === 'occupied' && (
                <div className="flex flex-col gap-1 items-end">
                  {table.orders?.filter(o => o.status !== 'paid').map((order, idx) => (
                    <div key={order.id} className="flex items-center gap-1 text-[10px] bg-emerald-500 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                      <Clock className="w-3 h-3" />
                      <LiveTimer startTime={order.startTime || table.startTime} />
                    </div>
                  ))}
                  {(!table.orders || table.orders.filter(o => o.status !== 'paid').length === 0) && (
                    <div className="flex items-center gap-1 text-[10px] bg-emerald-500 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                      <Clock className="w-3 h-3" />
                      <LiveTimer startTime={table.startTime} />
                    </div>
                  )}
                </div>
              )}
              {table.status === 'empty' && isAdminOrManager && (
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteTable(table.id);
                  }}
                  className="p-1.5 bg-black/10 dark:bg-white/10 rounded-md text-gray-800 dark:text-gray-200 hover:bg-rose-500/20 hover:text-rose-600 dark:hover:text-rose-400 transition-all cursor-pointer shadow-sm"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
          
          <button 
            onClick={() => onSelectTable(table)}
            className="space-y-1 flex-1 w-full text-left cursor-pointer"
          >
            <p className="text-xs opacity-70">
              {table.status === 'occupied' 
                ? `${(table.orders || []).reduce((sum, o) => sum + o.items.length, 0) + (table.currentOrder?.length || 0)} món ${table.orders && table.orders.length > 1 ? `(${table.orders.length} đơn)` : ''}` 
                : 'Bàn trống'}
            </p>
            {table.status === 'occupied' && (
              <p className="font-mono text-sm font-bold">
                {((table.orders || []).reduce((sum, o) => sum + o.total, 0) + (table.currentOrder?.reduce((sum, item) => sum + item.price * item.quantity, 0) || 0)).toLocaleString('vi-VN', { minimumFractionDigits: 0, maximumFractionDigits: 1 })}đ
              </p>
            )}
            {table.status === 'occupied' && kitchenEnabled && (() => {
              const activeOrders = (table.orders || []).filter(o => o.status !== 'paid');
              const hasReady = activeOrders.some(o => o.status === 'ready');
              const hasCooking = activeOrders.some(o => o.status === 'cooking');
              const hasPending = activeOrders.some(o => o.status === 'pending');

              if (hasReady) {
                return (
                  <div className="pt-1">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500 text-white animate-pulse shadow-xs">
                      <CheckCheck className="w-3 h-3" /> Bếp đã xong!
                    </span>
                  </div>
                );
              } else if (hasCooking) {
                return (
                  <div className="pt-1">
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30">
                      <Flame className="w-3 h-3" /> Bếp đang nấu
                    </span>
                  </div>
                );
              } else if (hasPending) {
                return (
                  <div className="pt-1">
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                      <Clock className="w-3 h-3" /> Chờ bếp làm
                    </span>
                  </div>
                );
              }
              return null;
            })()}
          </button>
        </motion.div>
      ))}
    </div>
  );
};

const MenuOrdering = ({ 
  selectedTable, 
  tables, // New prop
  onClose, 
  onUpdateOrder,
  onCheckout,
  onMergeTables,
  onTransferTable,
  menu,
  categories,
  vatPercent,
  onPrint,
  staffName,
  currentUser,
  onUpdateTable,
  onLogVoid,
  activeShift,
  customers,
  customerTypes,
  systemSettings
}: { 
  selectedTable: Table, 
  tables: Table[],
  onClose: () => void, 
  onUpdateOrder: (tableId: string, order: OrderItem[], targetSessionId?: string, operationId?: string) => Promise<string>,
  onCheckout: (tableId: string, ordersToPay: OrderSession[], discount: number, paymentMethod: 'cash' | 'transfer', shouldPrint: boolean, customerId?: string) => Promise<boolean> | boolean,
  onMergeTables: (targetTableId: string, sourceTableIds: string[], operationId?: string) => Promise<void>,
  onTransferTable: (sourceTableId: string, targetTableId: string, operationId?: string) => Promise<void>,
  menu: MenuItem[],
  categories: string[],
  vatPercent: number,
  onPrint: (data: any) => void,
  staffName: string,
  currentUser: User | null,
  onUpdateTable: (id: string, updates: Partial<Table>, expectedOrders?: OrderSession[], voidLog?: VoidLog) => Promise<boolean>,
  onLogVoid: (log: VoidLog) => void,
  activeShift: Shift | null,
  customers: Customer[],
  customerTypes: CustomerType[],
  systemSettings: SystemSettings
}) => {
    const isStrictCashier = currentUser?.role === 'cashier';
  const isOrderOnly = currentUser?.role === 'order';
  const [activeCategory, setActiveCategory] = useState('Tất cả');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [voidModalInfo, setVoidModalInfo] = useState<{
    isOpen: boolean;
    itemName: string;
    oldQuantity: number;
    newQuantity: number;
    pendingData: any;
  }>({ isOpen: false, itemName: '', oldQuantity: 0, newQuantity: 0, pendingData: null });

  
  // Draft order (New items being added)
  const draftStorageKey = `fnb_draft_${currentUser?.storeId}_${currentUser?.id}_${selectedTable.id}`;
  const [draftOperationId] = useState(() => {
    try { const draft = JSON.parse(safeStorage.getItem(draftStorageKey) || 'null'); return draft?.operationId || operationId('order'); } catch { return operationId('order'); }
  });
  const orderOperationRef = useRef(draftOperationId);
  const [currentOrder, setCurrentOrder] = useState<OrderItem[]>(() => {
    try { const draft = JSON.parse(safeStorage.getItem(draftStorageKey) || 'null'); return draft?.items || selectedTable.currentOrder || []; } catch { return selectedTable.currentOrder || []; }
  });
  useEffect(() => {
    if (currentOrder.length) safeStorage.setItem(draftStorageKey, JSON.stringify({ operationId: orderOperationRef.current, items: currentOrder }));
    else safeStorage.removeItem(draftStorageKey);
  }, [currentOrder, draftStorageKey]);
  const moveOperationRef = useRef(operationId('move'));
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerResults, setCustomerResults] = useState<Customer[]>(customers);
  useEffect(() => { setCustomerResults(customers); }, [customers]);
  useEffect(() => {
    if (!currentUser?.storeId || !customerSearch.trim()) return;
    let active = true;
    const timer = setTimeout(() => {
      fetchStoreRows<Customer>('customers', currentUser.storeId).then(rows => { if(active) setCustomerResults(rows); }).catch(error => { if(active) alert(error instanceof Error ? error.message : 'Không thể tải đủ khách hàng.'); });
    }, 300);
    return () => { active = false; clearTimeout(timer); };
  }, [customerSearch, currentUser?.storeId]);
  
  // Sync local state with fresh table data from props
  const activeTable = tables.find(t => t.id === selectedTable.id) || selectedTable;
  
  // Committed orders (Already sent to kitchen)
  const committedOrders = (activeTable.orders || []).filter(o => o.status !== 'paid');

  const [discount, setDiscount] = useState(activeTable.discount || 0);
  const vat = vatPercent;
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer'>('cash');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);
  
  const filteredCustomers = useMemo(() => {
    if (!customerSearch) return customerResults;
    return customerResults.filter(c => 
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) || 
      c.phone.includes(customerSearch)
    );
  }, [customerResults, customerSearch]);
  
  useEffect(() => {
    if (selectedCustomerId) {
      const customer = customerResults.find(x => x.id === selectedCustomerId);
      if (customer) {
        const customerType = customerTypes.find(x => x.id === customer.typeId);
        setDiscount(Math.min(100, Math.max(0, customerType?.discountPercent || 0)));
        return;
      }
    }
    setDiscount(Math.min(100, Math.max(0, activeTable.discount || 0)));
  }, [selectedCustomerId, customerResults, customerTypes, activeTable.discount]);
  
  // Sync discount if it changes in DB (e.g. reset after partial payment)
  useEffect(() => {
    setDiscount(activeTable.discount || 0);
  }, [activeTable.discount]);

  // Item Configuration State
  const [configuringItem, setConfiguringItem] = useState<MenuItem | null>(null);
  const [editingDraftIndex, setEditingDraftIndex] = useState<number | null>(null);
  const [editingCommittedInfo, setEditingCommittedInfo] = useState<{orderId: string, itemIndex: number} | null>(null);
  const [itemQuantity, setItemQuantity] = useState(1);
  const [itemNote, setItemNote] = useState('');
  const [selectedAddOns, setSelectedAddOns] = useState<AddOnItem[]>([]); // Array of add-ons (can contain duplicates for quantity)

  const [isPrintKitchenEnabled, setIsPrintKitchenEnabled] = useState(() => {
    const saved = safeStorage.getItem('isPrintKitchenEnabled');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [showMergeModal, setShowMergeModal] = useState(false);
  const [tablesToMerge, setTablesToMerge] = useState<string[]>([]);
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [targetTransferTable, setTargetTransferTable] = useState<string | null>(null);
  const [selectedOrdersToPay, setSelectedOrdersToPay] = useState<string[]>([]); // IDs of orders selected for payment
  const [isProcessing, setIsProcessing] = useState(false);
  const [showZoomedQR, setShowZoomedQR] = useState(false);

  const [viewMode, setViewMode] = useState<'menu' | 'order'>(
    selectedTable.status === 'occupied' ? 'order' : 'menu'
  );

  useEffect(() => {
    setSelectedOrdersToPay([]);
    setDiscount(activeTable.discount || 0);
    // Automatically switch to order view if table is occupied
    if (activeTable.status === 'occupied') {
      setViewMode('order');
    } else {
      setViewMode('menu');
    }
  }, [activeTable.id]);

  useEffect(() => {
    safeStorage.setItem('isPrintKitchenEnabled', JSON.stringify(isPrintKitchenEnabled));
  }, [isPrintKitchenEnabled]);

  const filteredMenu = useMemo(() => {
    if (!menu) return [];
    return menu.filter(item => {
      if (!item || !item.name) return false;
      const matchesCategory = activeCategory === 'Tất cả' || item.category === activeCategory;
      const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
      const isNotRawMaterial = item.category !== 'Nguyên liệu';
      const isForSale = !item.isInventory || (item.type === 'goods' && (item.price || 0) > 0 && item.category !== 'Nguyên liệu');
      return matchesCategory && matchesSearch && isNotRawMaterial && isForSale;
    }).sort((a, b) => {
      if (a.displayOrder !== undefined && b.displayOrder !== undefined) {
        return a.displayOrder - b.displayOrder;
      }
      if (a.displayOrder !== undefined) return -1;
      if (b.displayOrder !== undefined) return 1;
      return a.name.localeCompare(b.name);
    });
  }, [activeCategory, searchQuery, menu]);

  const allCommittedItems = useMemo(() => {
    const items: OrderItem[] = [];
    committedOrders.forEach(o => {
      if (selectedOrdersToPay.length === 0 || selectedOrdersToPay.includes(o.id)) {
        items.push(...o.items);
      }
    });
    
    // Group them by ID, price, add-ons, and note
    const grouped: OrderItem[] = [];
    items.forEach(item => {
      const key = `${item.id}-${item.price}-${JSON.stringify([...(item.selectedAddOns || [])].sort((a,b)=>(a.id||'').localeCompare(b.id||'')))}-${item.note||''}`;
      const existing = grouped.find(i => {
        const eKey = `${i.id}-${i.price}-${JSON.stringify([...(i.selectedAddOns || [])].sort((a,b)=>(a.id||'').localeCompare(b.id||'')))}-${i.note||''}`;
        return eKey === key;
      });
      if (existing) {
        existing.quantity += item.quantity;
      } else {
        grouped.push({...item});
      }
    });
    return grouped;
  }, [committedOrders, selectedOrdersToPay]);

  const handleItemClick = (item: MenuItem) => {
    setConfiguringItem(item);
    setEditingDraftIndex(null);
    setItemQuantity(1);
    setItemNote('');
    setSelectedAddOns([]);
  };

  const handleEditDraftItem = (item: OrderItem, index: number) => {
    setConfiguringItem(item);
    setEditingDraftIndex(index);
    setEditingCommittedInfo(null);
    setItemQuantity(item.quantity);
    setItemNote(item.note || '');
    setSelectedAddOns(item.selectedAddOns || []);
  };

  const handleEditCommittedItem = (item: OrderItem, orderId: string, itemIndex: number) => {
    setConfiguringItem(item);
    setEditingCommittedInfo({ orderId, itemIndex });
    setEditingDraftIndex(null);
    setItemQuantity(item.quantity);
    setItemNote(item.note || '');
    setSelectedAddOns(item.selectedAddOns || []);
  };

  const handleConfirmAddItem = async () => {
    if (isProcessing) return;
    if (!configuringItem) return;
    
    const newItem: OrderItem = {
      ...configuringItem,
      quantity: itemQuantity,
      note: itemNote,
      selectedAddOns: selectedAddOns
    };

    if (editingCommittedInfo) {
      // Update committed order in DB
      const { orderId, itemIndex } = editingCommittedInfo;
      const order = committedOrders.find(o => o.id === orderId);
      if (order) {
        const oldItem = order.items[itemIndex];
        let pendingVoidLog: VoidLog | undefined;
        let updatedItems = [...order.items];
        
        if (newItem.quantity <= 0) {
          // Remove item
          updatedItems.splice(itemIndex, 1);
        } else {
          updatedItems[itemIndex] = newItem;
        }
        
        const newSubtotal = updatedItems.reduce((sum, i) => sum + (i.price + (i.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0)) * i.quantity, 0);
        const orderDiscount = Math.max(0, Math.min(newSubtotal, order.discount || 0));
        const orderVat = Math.round((newSubtotal - orderDiscount) * (order.vat || 0) / 100);
        const newTotal = newSubtotal - orderDiscount + orderVat;
        const updatedOrders = (activeTable.orders || []).map(o => 
          o.id === orderId ? { ...o, items: updatedItems, total: newTotal, subtotal: newSubtotal } : o
        );

        // Log void if quantity reduced or item removed
        if (newItem.quantity < oldItem.quantity) {
          const diff = oldItem.quantity - Math.max(0, newItem.quantity);
          const valueDiff = diff * oldItem.price; // Only track main item price difference
          
          const reason = prompt(`⚠️ Bạn đang giảm số lượng hoặc hủy món [${oldItem.name}].\nVui lòng nhập lý do (VD: Khách đổi ý, Hết nguyên liệu...):`);
          if (!reason) {
            alert("❌ Bắt buộc phải nhập lý do hủy/giảm món!");
            return false;
          }

          const voidLog: Omit<VoidLog, "id"> = {
            time: new Date().toISOString(),
            staffName: staffName,
            tableName: activeTable.name,
            itemName: oldItem.name,
            oldQuantity: oldItem.quantity,
            newQuantity: Math.max(0, newItem.quantity),
            valueDiff: valueDiff,
            type: 'item_void',
            reason: reason
          };
          
          pendingVoidLog = voidLog;
        }
        
        // SAVE TO DB
        if (onUpdateTable) {
          setIsProcessing(true);
          try { await onUpdateTable(activeTable.id, { orders: updatedOrders }, activeTable.orders || [], pendingVoidLog); }
          catch (error) { alert(error instanceof Error ? error.message : 'Không thể lưu thay đổi món.'); return; }
          finally { setIsProcessing(false); }
        }
      }
    } else {
      // Update draft order
      setCurrentOrder(prev => {
        if (editingDraftIndex !== null) {
          const updated = [...prev];
          if (newItem.quantity <= 0) {
            updated.splice(editingDraftIndex, 1);
          } else {
            updated[editingDraftIndex] = newItem;
          }
          return updated;
        }

        if (newItem.quantity <= 0) return prev;

        // Check if same item with same addons and note exists
        const existingIndex = prev.findIndex(i => 
          i.id === newItem.id && 
          JSON.stringify([...(i.selectedAddOns || [])].sort((a,b)=>(a.id||'').localeCompare(b.id||''))) === JSON.stringify([...(newItem.selectedAddOns || [])].sort((a,b)=>(a.id||'').localeCompare(b.id||''))) &&
          i.note === newItem.note
        );

        if (existingIndex >= 0) {
          const updated = [...prev];
          updated[existingIndex] = { ...updated[existingIndex], quantity: updated[existingIndex].quantity + newItem.quantity };
          return updated;
        }
        return [...prev, newItem];
      });
    }

    setConfiguringItem(null);
    setEditingDraftIndex(null);
    setEditingCommittedInfo(null);
  };

  const handleCallDish = async () => {
    if (currentOrder.length === 0 || isProcessing) return null;
    
    setIsProcessing(true);
    try {
      const newSessionId = Math.random().toString(36).substr(2, 9);
      const targetId = selectedOrdersToPay.length === 1 ? selectedOrdersToPay[0] : undefined;
      await onUpdateOrder(activeTable.id, currentOrder, targetId, orderOperationRef.current);
      
      if (isPrintKitchenEnabled) {
        onPrint({
          type: 'kitchen',
          tableName: activeTable.name,
          items: currentOrder,
          staffName: staffName
        });
      }
      
      setCurrentOrder([]); // Clear only after the server confirmed the write
      safeStorage.removeItem(draftStorageKey);
      orderOperationRef.current = operationId('order');
      setSelectedOrdersToPay([]); // Clear selection
      onClose(); // Exit to table grid after sending
      return newSessionId;
    } catch (error) {
      console.error('Order error:', error);
      alert('Có lỗi xảy ra khi gọi món. Vui lòng thử lại.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePayment = async (shouldPrint: boolean = false) => {
    if (isProcessing) return;
    
    let ordersToPay: OrderSession[] = [];
    const unpaidCommitted = committedOrders.filter(o => o.status !== 'paid');
    
    if (selectedOrdersToPay.length > 0) {
      ordersToPay = committedOrders.filter(o => selectedOrdersToPay.includes(o.id));
    } else {
      ordersToPay = [...unpaidCommitted];
    }

    if (currentOrder.length > 0 && selectedOrdersToPay.length === 0) {
      setIsProcessing(true);
      try {
        const id = await onUpdateOrder(activeTable.id, currentOrder, undefined, orderOperationRef.current);
        const subtotal = itemsSubtotal(currentOrder);
        const saved: OrderSession = { id, items: cloneData(currentOrder), startTime: new Date().toISOString(), subtotal, discount: 0, vat: vatPercent || 0, total: subtotal + Math.round(subtotal * (vatPercent || 0) / 100), status: 'pending', staffId: currentUser?.id || '' };
        ordersToPay = [...ordersToPay.filter(o => o.id !== id), saved];
        setCurrentOrder([]);safeStorage.removeItem(draftStorageKey);orderOperationRef.current=operationId('order');
      } catch (error) { alert(error instanceof Error ? error.message : 'Không thể lưu đơn trước khi thanh toán.'); return; }
      finally { setIsProcessing(false); }
    }

    if (ordersToPay.length === 0) {
      alert("Vui lòng chọn đơn để thanh toán");
      return;
    }

    setIsProcessing(true);
    try {
      const checkoutSucceeded = await onCheckout(activeTable.id, ordersToPay, discountRate, paymentMethod, shouldPrint, selectedCustomerId);
      if (checkoutSucceeded !== true) return;
      // Clear local states
      setCurrentOrder([]);
      safeStorage.removeItem(draftStorageKey);
      orderOperationRef.current = operationId('order');
      setSelectedOrdersToPay([]);
      
      // Calculate remaining orders based on what we just paid
      const paidCommittedIds = new Set(ordersToPay.filter(o => o.id && !o.id.startsWith('draft-')).map(o => o.id));
      const remainingCount = committedOrders.filter(o => !paidCommittedIds.has(o.id)).length;
      
      // If no more orders left, close the modal
      if (remainingCount === 0) {
        onClose();
      }
    } catch (error) {
      console.error('Payment error:', error);
      alert('Có lỗi xảy ra khi thanh toán. Vui lòng thử lại.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Calculate totals
  const draftSubtotal = currentOrder.reduce((sum, item) => sum + (item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0)) * item.quantity, 0);
  
  // Payment starts from line-item subtotals. Summing session totals would apply VAT twice.
  const selectedOrdersSubtotal = committedOrders
    .filter(o => selectedOrdersToPay.includes(o.id) || (selectedOrdersToPay.length === 0 && o.status !== 'paid'))
    .reduce((sum, o) => sum + o.subtotal, 0);
  const displaySubtotal = selectedOrdersToPay.length > 0 ? selectedOrdersSubtotal : (selectedOrdersSubtotal + draftSubtotal);
  const finalSubtotal = displaySubtotal;
  const discountRate = Math.min(100, Math.max(0, Number.isFinite(discount) ? discount : 0));
  const discountAmount = Math.round((finalSubtotal * discountRate) / 100);
  const vatAmount = Math.round(((finalSubtotal - discountAmount) * vat) / 100);
  const finalTotal = finalSubtotal - discountAmount + vatAmount;

  const handlePrintProvisional = () => {
    let itemsToPrint: OrderItem[] = [];
    const unpaidCommitted = committedOrders.filter(o => o.status !== 'paid');
    
    let ordersToPrint: OrderSession[] = [];
    if (selectedOrdersToPay.length > 0) {
      ordersToPrint = committedOrders.filter(o => selectedOrdersToPay.includes(o.id));
    } else {
      ordersToPrint = [...unpaidCommitted];
    }
    
    ordersToPrint.forEach(o => itemsToPrint.push(...o.items));
    
    // Only include draft items if we are printing everything (no specific selection)
    if (selectedOrdersToPay.length === 0) {
      itemsToPrint.push(...currentOrder);
    }

    let customerName = undefined;
    let customerType = undefined;
    if (selectedCustomerId) {
      const c = customers.find(x => x.id === selectedCustomerId);
      if (c) {
        customerName = c.name;
        const t = customerTypes.find(x => x.id === c.typeId);
        if (t) {
          customerType = t.name;
        }
      }
    }

    onPrint({
      type: 'bill',
      tableName: activeTable.name,
      items: itemsToPrint,
      subtotal: finalSubtotal,
      discount: discountAmount,
      vat: vatAmount,
      total: finalTotal,
      staffName: staffName,
      timeIn: activeTable.startTime || new Date().toISOString(),
      timeOut: new Date().toISOString(),
      note: activeTable.note ? `PHIẾU TẠM TÍNH (${activeTable.note})` : 'PHIẾU TẠM TÍNH',
      customerName,
      customerType
    });
    alert('Đã gửi lệnh in tạm tính cho ' + activeTable.name);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-0 md:p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative bg-white dark:bg-[#1a1b1e] w-full max-w-[96vw] xl:max-w-7xl 2xl:max-w-[1550px] h-full h-[100dvh] md:h-[94vh] md:max-h-[94vh] md:rounded-3xl overflow-hidden flex flex-col lg:flex-row border border-black/10 dark:border-white/10 shadow-2xl"
      >
        {/* Full-screen Processing Overlay during checkout or dish calling */}
        {isProcessing && (
          <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col items-center justify-center gap-3 text-white">
            <div className="w-10 h-10 border-3 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin" />
            <p className="text-sm font-bold tracking-wide">Đang hoàn tất thanh toán...</p>
          </div>
        )}

        {/* Main Header (Common for both mobile views) */}
        <div className="lg:hidden p-4 pt-[max(env(safe-area-inset-top),16px)] border-b border-black/10 dark:border-white/10 flex flex-col gap-3 bg-white dark:bg-[#1a1b1e] shrink-0">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">{activeTable.name}</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-500 border border-emerald-500/20 uppercase font-bold">
                {activeTable.status === 'empty' ? 'Bàn trống' : 'Đang dùng'}
              </span>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-full text-gray-600 dark:text-gray-400 cursor-pointer">
              <X className="w-6 h-6" />
            </button>
          </div>
          {!isOrderOnly && (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowTransferModal(true)}
                className="flex-1 flex justify-center items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold bg-purple-500/10 border border-purple-500 text-purple-500 hover:bg-purple-500/20 transition-all"
              >
                <ArrowRightLeft className="w-3 h-3" />
                Chuyển bàn
              </button>
              <button 
                onClick={() => setShowMergeModal(true)}
                className="flex-1 flex justify-center items-center gap-2 px-3 py-2 rounded-lg text-xs font-bold bg-blue-500/10 border border-blue-500 text-blue-600 dark:text-blue-500 hover:bg-blue-500/20 transition-all"
              >
                <Users className="w-3 h-3" />
                Gộp bàn
              </button>
            </div>
          )}
        </div>

        {/* Mobile Toggle */}
        <div className="lg:hidden flex border-b border-black/10 dark:border-white/10 bg-white dark:bg-[#151619] shrink-0">
          <button 
            onClick={() => setViewMode('menu')}
            className={cn(
              "flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-all",
              viewMode === 'menu' ? "text-emerald-600 dark:text-emerald-500 border-b-2 border-emerald-500 bg-emerald-500/5" : "text-gray-500"
            )}
          >
            <LayoutGrid className="w-4 h-4" />
            Thực đơn
          </button>
          <button 
            onClick={() => setViewMode('order')}
            className={cn(
              "flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-all relative",
              viewMode === 'order' ? "text-emerald-600 dark:text-emerald-500 border-b-2 border-emerald-500 bg-emerald-500/5" : "text-gray-500"
            )}
          >
            <ShoppingCart className="w-4 h-4" />
            Đơn & Thanh toán
            {(currentOrder.length > 0 || committedOrders.length > 0) && (
              <span className="absolute top-3 right-4 bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                {currentOrder.length + committedOrders.length}
              </span>
            )}
          </button>
        </div>

        {/* Left: Menu Selection */}
        <div className={cn(
          "min-w-0 flex flex-col border-r border-black/10 dark:border-white/10 min-h-0 overflow-hidden lg:flex lg:flex-1 lg:h-full",
          viewMode === 'menu' ? "flex flex-1" : "hidden lg:flex"
        )}>
          {/* Header (Desktop only) */}
          <div className="hidden lg:block px-4 py-3 xl:px-6 xl:py-4 border-b border-black/5 dark:border-white/5 shrink-0">
            <div className="flex justify-between items-center gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <h2 className="text-xl xl:text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2 truncate">
                  {activeTable.name}
                  <span className="text-sm font-normal text-gray-500 shrink-0">Thêm món</span>
                </h2>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-500 border border-emerald-500/20 uppercase font-bold shrink-0">
                  {activeTable.status === 'empty' ? 'Bàn trống' : 'Đang dùng'}
                </span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                 {/* Transfer Button */}
                 {!isOrderOnly && (
                   <>
                     <button 
                      onClick={() => setShowTransferModal(true)}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-purple-500/10 border border-purple-500 text-purple-500 hover:bg-purple-500/20 transition-all cursor-pointer"
                    >
                      <ArrowRightLeft className="w-3.5 h-3.5" />
                      <span>Chuyển bàn</span>
                    </button>

                     <button 
                      onClick={() => setShowMergeModal(true)}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-blue-500/10 border border-blue-500 text-blue-600 dark:text-blue-500 hover:bg-blue-500/20 transition-all cursor-pointer"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Gộp bàn</span>
                    </button>
                   </>
                 )}

                <button 
                  onClick={() => setViewMode(viewMode === 'order' ? 'menu' : 'order')}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer",
                    viewMode === 'order'
                      ? "bg-emerald-500 text-white border-emerald-600 shadow-sm"
                      : "bg-emerald-500/10 border-emerald-500/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20"
                  )}
                  title="Mở / Xem đơn hàng và thanh toán"
                >
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>Đơn & Thanh toán</span>
                  {(currentOrder.length > 0 || committedOrders.length > 0) && (
                    <span className={cn(
                      "text-[10px] px-1.5 py-0.2 rounded-full font-bold",
                      viewMode === 'order' ? "bg-white text-emerald-700" : "bg-emerald-500 text-white"
                    )}>
                      {currentOrder.length + committedOrders.length}
                    </span>
                  )}
                </button>

                <button 
                  onClick={() => setIsPrintKitchenEnabled(!isPrintKitchenEnabled)}
                  className={cn(
                    "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer",
                    isPrintKitchenEnabled 
                      ? "bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-500" 
                      : "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-gray-500"
                  )}
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isPrintKitchenEnabled ? 'In bếp: BẬT' : 'In bếp: TẮT'}</span>
                </button>
                <button onClick={onClose} className="p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-full text-gray-600 dark:text-gray-400 cursor-pointer" title="Đóng">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Search & Categories (Mobile & Desktop) */}
          <div className="p-3 md:p-4 border-b border-black/5 dark:border-white/5 shrink-0">
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
              <div className="relative w-full sm:w-56 md:w-64 shrink-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input 
                  type="text" 
                  placeholder="Tìm món ăn..."
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl py-2 pl-9 pr-3 text-sm text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50 transition-all"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex-1 min-w-0 flex gap-2 overflow-x-auto pb-1 custom-scrollbar">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={cn(
                      "px-3 py-1.5 rounded-xl text-xs md:text-sm whitespace-nowrap transition-all cursor-pointer shrink-0",
                      activeCategory === cat ? "bg-emerald-500 text-white font-bold" : "bg-black/5 dark:bg-white/5 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
                    )}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Menu List/Grid */}
          <div className="flex-1 overflow-y-auto p-3 md:p-4 lg:p-5 custom-scrollbar pb-32 lg:pb-6 relative min-h-0 touch-pan-y">
            {isStrictCashier ? (
              <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-4">
                <Lock className="w-16 h-16 opacity-20" />
                <p className="text-center">Nhân viên thu ngân không có quyền chỉnh sửa đơn hàng.<br/>Vui lòng chỉ thực hiện thanh toán.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-3 md:gap-4">
                {filteredMenu.map(item => (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item)}
                    className="group bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl p-2.5 md:p-3 text-left hover:border-emerald-500/30 transition-all cursor-pointer flex flex-col items-start gap-2 h-full"
                  >
                    <div className="w-full aspect-video bg-gray-100 dark:bg-gray-800 rounded-xl overflow-hidden shrink-0">
                      <img 
                        src={getMenuItemImage(item)} 
                        alt={item.name}
                        className="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition-opacity"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="w-full flex-1 flex flex-col justify-between">
                      <p className="font-bold text-gray-900 dark:text-white text-xs md:text-sm line-clamp-2 leading-snug">{item.name}</p>
                      <p className="text-emerald-600 dark:text-emerald-500 font-mono font-bold text-xs md:text-sm mt-1">{item.price.toLocaleString('vi-VN', { minimumFractionDigits: 0, maximumFractionDigits: 1 })}đ</p>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Mobile Floating Action Button */}
            <div className="lg:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[92%]">
              {currentOrder.length > 0 ? (
                <button 
                  onClick={() => setViewMode('order')}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-bold py-3.5 px-4 rounded-2xl shadow-[0_8px_30px_rgb(16,185,129,0.35)] flex items-center justify-between gap-3 transition-all"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-xl bg-white/20 flex items-center justify-center font-bold text-xs">
                      {currentOrder.length}
                    </span>
                    <span className="text-sm font-bold tracking-tight">
                      {activeTable.status === 'empty' ? 'Báo bếp & Mở bàn' : 'Xem đơn & Báo bếp'}
                    </span>
                  </div>
                  <span className="bg-black/20 text-white px-2.5 py-1 rounded-lg text-xs font-mono font-bold">
                    {draftSubtotal.toLocaleString()}đ
                  </span>
                </button>
              ) : committedOrders.length > 0 ? (
                <button 
                  onClick={() => setViewMode('order')}
                  className="w-full bg-black/80 dark:bg-white/10 border border-black/20 dark:border-white/20 text-white font-bold py-3.5 px-4 rounded-2xl backdrop-blur-md flex items-center justify-between gap-3 shadow-lg active:scale-[0.98] transition-all"
                >
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm font-bold">Xem đơn & Thanh toán</span>
                  </div>
                  <span className="bg-emerald-500 text-white px-2.5 py-1 rounded-lg text-xs font-mono font-bold">
                    {committedOrders.reduce((sum, o) => sum + o.total, 0).toLocaleString()}đ
                  </span>
                </button>
              ) : activeTable.status === 'occupied' ? (
                <button 
                  onClick={() => setViewMode('order')}
                  className="w-full bg-black/80 dark:bg-white/10 border border-black/20 dark:border-white/20 text-white font-bold py-3.5 px-4 rounded-2xl backdrop-blur-md flex items-center justify-between gap-3 shadow-lg active:scale-[0.98] transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm font-bold">Xem đơn & Thanh toán</span>
                  </div>
                  <span className="bg-emerald-500 text-white px-2.5 py-1 rounded-lg text-xs font-mono font-bold">
                    {committedOrders.reduce((sum, o) => sum + o.total, 0).toLocaleString()}đ
                  </span>
                </button>
              ) : null}
            </div>
          </div>
        </div>

        {/* Right: Order Summary & Payment */}
        <div className={cn(
          "w-full lg:w-[400px] xl:w-[440px] 2xl:w-[480px] shrink-0 bg-white dark:bg-[#151619] flex flex-col min-h-0 min-w-0 overflow-hidden lg:flex lg:h-full",
          viewMode === 'order' ? "flex flex-1 min-h-0" : "hidden lg:flex"
        )}>
          <div className="p-3 md:p-4 border-b border-black/5 dark:border-white/5 flex justify-between items-center bg-white dark:bg-[#1a1b1e] lg:bg-transparent shrink-0">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setViewMode('menu')}
                className="lg:hidden flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-black/5 dark:bg-white/5 text-gray-700 dark:text-gray-300 border border-black/10 dark:border-white/10 hover:bg-black/10 transition-colors"
                title="Quay lại danh sách thực đơn"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>+ Thêm món</span>
              </button>
              <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-emerald-600 dark:text-emerald-500" />
                <span>Đơn hàng & Thanh toán</span>
              </h3>
            </div>
            <div className="flex items-center gap-2">
              {currentOrder.length > 0 && (
                <button className="text-xs text-rose-600 dark:text-rose-500 hover:underline cursor-pointer" onClick={() => setCurrentOrder([])}>Xóa đơn mới</button>
              )}
              <button 
                onClick={() => setIsPrintKitchenEnabled(!isPrintKitchenEnabled)}
                className={cn(
                  "lg:hidden flex items-center gap-2 px-2 py-1 rounded-lg text-[10px] font-bold transition-all border",
                  isPrintKitchenEnabled 
                    ? "bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-500" 
                    : "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-gray-500"
                )}
              >
                <Printer className="w-3 h-3" />
                {isPrintKitchenEnabled ? 'Bật' : 'Tắt'}
              </button>
              <button onClick={onClose} className="p-1.5 hover:bg-black/5 dark:hover:bg-white/5 rounded-full text-gray-600 dark:text-gray-400 cursor-pointer hidden lg:flex" title="Đóng">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2 md:p-4 space-y-3 custom-scrollbar min-h-0">
            {/* Committed Orders List (Restored per-order view) */}
            <div className="space-y-2">
              {committedOrders.length === 0 ? (
                <div className="text-center py-8 text-gray-500 text-sm italic border border-dashed border-black/10 dark:border-white/10 rounded-xl">Chưa có đơn nào được báo bếp</div>
              ) : (
                committedOrders.map((order, orderIndex) => {
                  const isSelected = selectedOrdersToPay.includes(order.id);
                  const isSelectionMode = selectedOrdersToPay.length > 0;
                  
                  return (
                    <div 
                      key={order.id} 
                      className={cn(
                        "border rounded-xl overflow-hidden transition-all",
                        isSelected ? "border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)]" : "border-black/10 dark:border-white/10",
                        isSelectionMode && !isSelected ? "opacity-50" : "opacity-100"
                      )}
                    >
                      {/* Order Header */}
                      <div 
                        onClick={() => {
                          setSelectedOrdersToPay(prev => 
                            prev.includes(order.id) ? prev.filter(id => id !== order.id) : [...prev, order.id]
                          );
                        }}
                        className={cn(
                          "p-2 flex justify-between items-center cursor-pointer transition-colors",
                          isSelected ? "bg-emerald-500/20" : "bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <div className={cn(
                            "w-4 h-4 rounded-full flex items-center justify-center border text-[8px]",
                            isSelected ? "bg-emerald-500 border-emerald-500 text-black" : "border-gray-500 text-transparent"
                          )}>
                            <Check className="w-2.5 h-2.5" />
                          </div>
                          <span className="font-bold text-sm text-gray-900 dark:text-white">Đơn #{orderIndex + 1}</span>
                          {systemSettings.kitchenEnabled !== false && order.status === 'ready' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500 text-white font-bold animate-pulse flex items-center gap-1">
                              <CheckCheck className="w-2.5 h-2.5" /> Bếp đã xong
                            </span>
                          )}
                          {systemSettings.kitchenEnabled !== false && order.status === 'cooking' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-600 dark:text-sky-400 font-semibold border border-sky-500/30 flex items-center gap-1">
                              <Flame className="w-2.5 h-2.5" /> Đang nấu
                            </span>
                          )}
                          {systemSettings.kitchenEnabled !== false && order.status === 'pending' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 font-semibold border border-amber-500/30 flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5" /> Chờ bếp
                            </span>
                          )}
                          {systemSettings.kitchenEnabled !== false && order.status === 'completed' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/10 dark:bg-white/10 text-gray-500 font-semibold">
                              Đã lên món
                            </span>
                          )}
                          <span className="flex items-center gap-1 text-[9px] text-gray-600 dark:text-gray-400 bg-gray-200 dark:bg-black/40 px-1.5 py-0.5 rounded-full">
                            <Clock className="w-2.5 h-2.5" />
                            <LiveTimer startTime={order.startTime} />
                          </span>
                        </div>
                        <span className="font-mono font-bold text-sm text-emerald-600 dark:text-emerald-400">{order.total.toLocaleString()}đ</span>
                      </div>
                      
                      {/* Order Items */}
                      <div className="p-2 space-y-2 bg-gray-100 dark:bg-black/20">
                        {order.items.map((item, itemIndex) => {
                          const groupedAddOns: { name: string, quantity: number }[] = [];
                          item.selectedAddOns?.forEach(a => {
                            const existing = groupedAddOns.find(ga => ga.name === a.name);
                            if (existing) existing.quantity++;
                            else groupedAddOns.push({ name: a.name, quantity: 1 });
                          });

                          return (
                            <div key={`${order.id}-${itemIndex}`} className="space-y-0.5 pb-1.5 border-b border-black/5 dark:border-white/5 last:border-0 last:pb-0">
                              <div className="flex justify-between items-start text-[13px]">
                                <div className="flex-1">
                                  <div className="text-gray-900 dark:text-white font-medium flex items-center gap-1.5">
                                    {item.name}
                                    <span className="text-emerald-600 dark:text-emerald-500 font-bold text-xs">x{item.quantity}</span>
                                  </div>
                                  {groupedAddOns.length > 0 && (
                                    <div className="text-[10px] text-emerald-600 dark:text-emerald-500/90 font-medium leading-tight">
                                      + {groupedAddOns.map(ga => `${ga.name}${ga.quantity > 1 ? ` x${ga.quantity}` : ''}`).join(', ')}
                                    </div>
                                  )}
                                  {item.note && <div className="text-[9px] text-gray-500 italic leading-tight">"{item.note}"</div>}
                                </div>
                                <div className="flex items-center gap-2 ml-2">
                                  <div className="text-gray-900 dark:text-white font-mono text-xs">{(item.quantity * (item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0))).toLocaleString()}đ</div>
                                  {!isOrderOnly && (
                                    <button 
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleEditCommittedItem(item, order.id, itemIndex);
                                      }}
                                      className="text-blue-600 dark:text-blue-500 hover:text-blue-400 p-0.5 bg-blue-500/10 rounded"
                                    >
                                      <Settings className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Current Draft Order */}
            {currentOrder.length > 0 && (
              <div className="border border-dashed border-emerald-500/50 bg-emerald-500/5 rounded-xl p-3 space-y-3">
                <div className="flex justify-between items-center border-b border-emerald-500/20 pb-2">
                  <span className="font-bold text-emerald-600 dark:text-emerald-500 text-sm">Đơn mới (Chưa báo bếp)</span>
                  <span className="font-mono font-bold text-emerald-600 dark:text-emerald-500">{draftSubtotal.toLocaleString()}đ</span>
                </div>
                {currentOrder.map((item, idx) => {
                  // Group add-ons for display (Task 2)
                  const groupedAddOns: { name: string, quantity: number }[] = [];
                  item.selectedAddOns?.forEach(a => {
                    const existing = groupedAddOns.find(ga => ga.name === a.name);
                    if (existing) existing.quantity++;
                    else groupedAddOns.push({ name: a.name, quantity: 1 });
                  });

                  return (
                    <div key={`${item.id}-${idx}`} className="space-y-1">
                      <div className="flex justify-between items-start text-sm">
                        <div className="text-gray-900 dark:text-white">
                          <span className="font-medium">{item.name}</span>
                          {groupedAddOns.length > 0 && (
                            <div className="text-[10px] text-emerald-600 dark:text-emerald-500">
                              + {groupedAddOns.map(ga => `${ga.name}${ga.quantity > 1 ? ` x${ga.quantity}` : ''}`).join(', ')}
                            </div>
                          )}
                          {item.note && <div className="text-[10px] text-gray-600 dark:text-gray-400 italic">"{item.note}"</div>}
                        </div>
                        <div className="flex items-center gap-2">
                           <span className="font-bold">x{item.quantity}</span>
                           <button 
                              onClick={() => handleEditDraftItem(item, idx)} 
                              className="text-blue-600 dark:text-blue-500 hover:text-blue-400 p-1"
                           >
                              <Settings className="w-3 h-3" />
                           </button>
                           <button onClick={() => {
                              setCurrentOrder(prev => prev.filter((_, i) => i !== idx));
                           }} className="text-rose-600 dark:text-rose-500 hover:text-rose-400 p-1"><Trash2 className="w-3 h-3" /></button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Bottom Checkout & Action Area: Scrollable details + Pinned action buttons to avoid overflow */}
          <div className="shrink-0 border-t border-black/10 dark:border-white/10 bg-black/[0.02] dark:bg-white/[0.02] flex flex-col min-h-0">
            <div className="max-h-[32vh] overflow-y-auto custom-scrollbar p-3 space-y-2.5">
              <div className="space-y-1.5 text-xs">
                {/* ... (Totals - Updated to reflect selection) ... */}
                <div className="flex justify-between items-center text-gray-600 dark:text-gray-400">
                  <span>Tạm tính ({selectedOrdersToPay.length > 0 ? `${selectedOrdersToPay.length} đơn đã chọn` : 'Tất cả đơn'})</span>
                  <span className="font-mono font-bold text-gray-900 dark:text-white">{finalSubtotal.toLocaleString()}đ</span>
                </div>
                {/* ... Discount/VAT inputs ... */}
                <div className="flex justify-between items-center text-gray-600 dark:text-gray-400">
                  <div className="flex items-center gap-2">
                    <span>Giảm giá (%)</span>
                    {isOrderOnly ? (
                      <span className="w-10 bg-gray-200 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded px-1 text-center text-[10px] text-gray-500 inline-block">{discount}</span>
                    ) : (
                      <input 
                        type="number" 
                        className="w-10 bg-gray-200 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded px-1 text-center text-[10px]"
                        value={discount}
                        min="0"
                        max="100"
                        onChange={(e) => { const next = Number(e.target.value); setDiscount(Number.isFinite(next) ? Math.min(100, Math.max(0, next)) : 0); }}
                      />
                    )}
                  </div>
                  <span className="font-mono text-rose-600 dark:text-rose-400">-{discountAmount.toLocaleString()}đ</span>
                </div>
                <div className="flex justify-between items-center text-gray-600 dark:text-gray-400">
                  <span>VAT ({vat}%)</span>
                  <span className="font-mono">{vatAmount.toLocaleString()}đ</span>
                </div>
                <div className="pt-2 border-t border-black/5 dark:border-white/5 flex justify-between items-center text-gray-900 dark:text-white text-lg font-bold">
                  <span>Tổng cộng</span>
                  <span className="text-emerald-600 dark:text-emerald-500 font-mono text-xl">{finalTotal.toLocaleString()}đ</span>
                </div>
              </div>

              {activeTable.status === 'occupied' && (
                <div className="space-y-2.5 pt-1 border-t border-black/5 dark:border-white/5">
                  <div className="space-y-1">
                    <p className="text-[10px] text-gray-500 uppercase tracking-wider font-bold flex justify-between items-center">
                      <span>Khách hàng</span>
                      {selectedCustomerId && (
                        <button onClick={() => setSelectedCustomerId('')} className="text-[10px] text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer">Bỏ chọn</button>
                      )}
                    </p>
                    <div className="relative">
                      {!showCustomerDropdown && !selectedCustomerId ? (
                        <button 
                          onClick={() => setShowCustomerDropdown(true)}
                          className="w-full bg-gray-200 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-gray-600 dark:text-gray-400 text-left hover:border-emerald-500/50 cursor-pointer"
                        >
                          Tìm khách hàng (Khách lẻ)
                        </button>
                      ) : selectedCustomerId && !showCustomerDropdown ? (
                        <div 
                          onClick={() => setShowCustomerDropdown(true)}
                          className="w-full bg-gray-200 dark:bg-black/40 border border-emerald-500/50 rounded-lg px-2.5 py-1.5 text-xs text-emerald-600 dark:text-emerald-500 text-left cursor-pointer flex justify-between"
                        >
                          <span>
                            {customers.find(c => c.id === selectedCustomerId)?.name}
                          </span>
                          <span>
                            {customerTypes.find(t => t.id === customers.find(c => c.id === selectedCustomerId)?.typeId)?.discountPercent ? ` (-${customerTypes.find(t => t.id === customers.find(c => c.id === selectedCustomerId)?.typeId)?.discountPercent}%)` : ''}
                          </span>
                        </div>
                      ) : (
                        <div className="relative">
                          <input
                            autoFocus
                            type="text"
                            className="w-full bg-gray-200 dark:bg-black/40 border border-emerald-500/50 rounded-lg px-2.5 py-1.5 text-xs text-gray-900 dark:text-white focus:outline-none"
                            placeholder="Nhập tên hoặc SĐT..."
                            value={customerSearch}
                            onChange={(e) => setCustomerSearch(e.target.value)}
                            onBlur={() => setTimeout(() => setShowCustomerDropdown(false), 200)}
                          />
                          <div className="absolute bottom-full left-0 right-0 mb-1 bg-white dark:bg-[#1a1b1e] border border-black/10 dark:border-white/10 rounded-lg max-h-48 overflow-y-auto z-50 shadow-2xl">
                            <button
                              className="w-full text-left px-3 py-2 hover:bg-black/5 dark:hover:bg-white/5 text-xs text-gray-600 dark:text-gray-400 cursor-pointer"
                              onClick={() => { setSelectedCustomerId(''); setShowCustomerDropdown(false); setCustomerSearch(''); }}
                            >
                              Khách lẻ (Không áp dụng ưu đãi)
                            </button>
                            {filteredCustomers.map(c => (
                              <button
                                key={c.id}
                                className="w-full text-left px-3 py-2 hover:bg-black/5 dark:hover:bg-white/5 text-xs text-gray-900 dark:text-white cursor-pointer"
                                onClick={() => { setSelectedCustomerId(c.id); setShowCustomerDropdown(false); setCustomerSearch(''); }}
                              >
                                {c.name} - {c.phone} 
                                {customerTypes.find(t => t.id === c.typeId)?.discountPercent ? ` (-${customerTypes.find(t => t.id === c.typeId)?.discountPercent}%)` : ''}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {!isOrderOnly && (
                  <div className="space-y-1.5">
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: 'cash', label: 'Tiền mặt' },
                        { id: 'transfer', label: 'Chuyển khoản' }
                      ].map(method => (
                        <button
                          key={method.id}
                          onClick={() => setPaymentMethod(method.id as any)}
                          className={cn(
                            "py-1.5 rounded-lg text-[11px] font-bold border transition-all cursor-pointer uppercase",
                            paymentMethod === method.id ? "bg-emerald-500/20 border-emerald-500 text-emerald-600 dark:text-emerald-500" : "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
                          )}
                        >
                          {method.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  )}

                  {systemSettings.bankCode && systemSettings.bankAccountNumber && finalTotal > 0 && paymentMethod === 'transfer' && (
                    <div className="p-2.5 bg-white dark:bg-black/20 rounded-xl border border-emerald-500/30 flex justify-between items-center gap-2.5">
                      <div className="flex-1 space-y-0.5">
                        <p className="text-[10px] font-bold uppercase text-emerald-600 dark:text-emerald-500 tracking-wider">Mã VietQR</p>
                        <p className="text-[9px] text-gray-500 uppercase leading-tight truncate">{systemSettings.bankAccountName} - {systemSettings.bankAccountNumber}</p>
                        <span className="text-[9px] text-emerald-600 dark:text-emerald-400 font-semibold cursor-pointer hover:underline block" onClick={() => setShowZoomedQR(true)}>Bấm để phóng to mã QR</span>
                      </div>
                      <div className="bg-white p-1 rounded-lg cursor-pointer shrink-0 shadow-sm border border-emerald-500/20" onClick={() => setShowZoomedQR(true)} title="Bấm để phóng to mã QR">
                        <img 
                          src={`https://img.vietqr.io/image/${systemSettings.bankCode}-${systemSettings.bankAccountNumber}-compact2.png?amount=${finalTotal}&accountName=${encodeURIComponent(systemSettings.bankAccountName || '')}&addInfo=${encodeURIComponent((systemSettings.bankCode?.toUpperCase() === 'ICB' || systemSettings.bankCode?.toUpperCase() === 'CTG' || systemSettings.bankCode?.toLowerCase()?.includes('vietin') ? 'SEVQR ' : '') + currentUser?.store?.code + ' THANH TOAN ' + activeTable.name)}`} 
                          alt="VietQR" 
                          className="w-14 h-14 object-contain hover:scale-105 transition-transform"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Pinned Action Buttons: Always visible at bottom, never overflow */}
            <div className="p-3 pb-[max(env(safe-area-inset-bottom),14px)] bg-white dark:bg-[#151619] border-t border-black/10 dark:border-white/10 shrink-0 space-y-2 shadow-[0_-4px_20px_rgba(0,0,0,0.15)]">
              {/* Buttons */}
              {currentOrder.length > 0 && (
                <button 
                  onClick={handleCallDish}
                  disabled={isProcessing}
                  className={cn(
                    "w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-bold shadow-lg shadow-emerald-600/30 cursor-pointer flex items-center justify-center gap-2 text-sm transition-all",
                    isProcessing && "opacity-50 cursor-not-allowed"
                  )}
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Đang gửi bếp...
                    </>
                  ) : (
                    <>
                      <ChefHat className="w-5 h-5" />
                      {activeTable.status === 'empty' ? 'BÁO BẾP & MỞ BÀN' : (selectedOrdersToPay.length === 1 ? 'THÊM MÓN VÀO ĐƠN & GỬI BẾP' : 'TẠO ĐƠN MỚI & GỬI BẾP')}
                    </>
                  )}
                </button>
              )}
              
              {activeTable.status === 'occupied' && !isOrderOnly && (
                <div className="grid grid-cols-3 gap-2">
                  <button 
                    onClick={handlePrintProvisional}
                    disabled={isProcessing}
                    className={cn(
                      "py-2 rounded-xl border border-black/10 dark:border-white/10 text-gray-900 dark:text-white font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer flex flex-col items-center justify-center gap-0.5 text-[10px]",
                      isProcessing && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    <Printer className="w-3.5 h-3.5" />
                    IN TẠM
                  </button>
                  <button 
                    onClick={() => handlePayment(true)}
                    disabled={isProcessing}
                    className={cn(
                      "py-2 rounded-xl border border-blue-500/30 text-blue-600 dark:text-blue-500 font-bold hover:bg-blue-500/10 cursor-pointer flex flex-col items-center justify-center gap-0.5 text-[10px]",
                      isProcessing && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    {isProcessing ? (
                      <div className="w-3.5 h-3.5 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
                    ) : (
                      <> <Printer className="w-3.5 h-3.5" /> THU & IN </>
                    )}
                  </button>
                  <button 
                    onClick={() => handlePayment(false)}
                    disabled={isProcessing}
                    className={cn(
                      "py-2 rounded-xl bg-emerald-500 text-white font-bold shadow-sm hover:bg-emerald-400 cursor-pointer flex flex-col items-center justify-center gap-0.5 text-[10px]",
                      isProcessing && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    {isProcessing ? (
                      <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <> <Check className="w-3.5 h-3.5" /> THANH TOÁN </>
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Item Configuration Modal (New) */}
        <AnimatePresence>
          {showZoomedQR && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
              onClick={() => setShowZoomedQR(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-white rounded-3xl p-6 max-w-sm w-full mx-auto relative flex flex-col items-center shadow-2xl"
                onClick={e => e.stopPropagation()}
              >
                <button 
                  onClick={() => setShowZoomedQR(false)}
                  className="absolute top-4 right-4 p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-700" />
                </button>
                <h3 className="text-lg font-bold text-gray-900 mb-4 text-center">Quét mã để thanh toán</h3>
                <div className="bg-white p-2 rounded-2xl border border-gray-200 shadow-inner mb-4 w-full aspect-square flex items-center justify-center">
                  <img 
                    src={`https://img.vietqr.io/image/${systemSettings.bankCode}-${systemSettings.bankAccountNumber}-compact2.png?amount=${finalTotal}&accountName=${encodeURIComponent(systemSettings.bankAccountName || '')}&addInfo=${encodeURIComponent((systemSettings.bankCode?.toUpperCase() === 'ICB' || systemSettings.bankCode?.toUpperCase() === 'CTG' || systemSettings.bankCode?.toLowerCase()?.includes('vietin') ? 'SEVQR ' : '') + currentUser?.store?.code + ' THANH TOAN ' + activeTable.name)}`} 
                    alt="VietQR Zoomed" 
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="text-center space-y-1">
                  <p className="font-bold text-gray-900">{systemSettings.bankAccountName}</p>
                  <p className="text-sm text-gray-500">{systemSettings.bankAccountNumber}</p>
                  <p className="text-xl font-black text-emerald-600 mt-2">{finalTotal.toLocaleString()} đ</p>
                </div>
              </motion.div>
            </motion.div>
          )}

          {configuringItem && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-2xl md:rounded-3xl p-5 md:p-6 border border-black/10 dark:border-white/10 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden"
              >
                <div className="flex justify-between items-center shrink-0 pb-3 border-b border-black/5 dark:border-white/5">
                  <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white truncate pr-2">{configuringItem.name}</h3>
                  <button onClick={() => setConfiguringItem(null)} className="text-gray-500 hover:text-gray-900 dark:hover:text-white p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5"><X className="w-5 h-5" /></button>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar py-3 space-y-4 min-h-0 pr-1">
                  {/* Main Quantity */}
                  <div className="flex justify-between items-center bg-black/5 dark:bg-white/5 p-3 rounded-xl">
                    <span className="text-gray-600 dark:text-gray-400 text-sm">Số lượng món chính</span>
                    <div className="flex items-center gap-3">
                      <button onClick={() => setItemQuantity(Math.max(0, itemQuantity - 1))} className="p-1.5 bg-black/10 dark:bg-white/10 rounded-lg hover:bg-white/20"><Minus className="w-3.5 h-3.5" /></button>
                      <span className="text-lg font-bold font-mono w-8 text-center">{itemQuantity}</span>
                      <button onClick={() => setItemQuantity(itemQuantity + 1)} className="p-1.5 bg-black/10 dark:bg-white/10 rounded-lg hover:bg-white/20"><Plus className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>

                  {/* Add-ons */}
                  {configuringItem.addOns && configuringItem.addOns.length > 0 && (
                    <div className="space-y-2.5">
                      <div className="flex justify-between items-center">
                        <p className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Món ăn kèm</p>
                        <span className="text-[11px] text-gray-400">Chọn thêm theo suất</span>
                      </div>
                      {configuringItem.addOns.map(addon => {
                        const count = selectedAddOns.filter(a => a.id === addon.id).length;
                        const invItem = menu.find(m => 
                          (m.isInventory || m.type === 'goods' || m.category === 'Nguyên liệu') &&
                          (m.id === addon.inventoryItemId || m.name.toLowerCase().trim() === addon.name.toLowerCase().trim())
                        );
                        const isTracked = invItem ? invItem.trackStock !== false : true;
                        let isOutOfStock = false;
                        if (isTracked) {
                          const currentStock = invItem ? invItem.stock : undefined;
                          const isOutOfStockFromInv = invItem && currentStock !== undefined && currentStock <= 0;
                          const isOutOfStockFromSettings = (systemSettings.outOfStockAddOnIds || []).includes(addon.id) ||
                            Boolean(addon.inventoryItemId && (systemSettings.outOfStockAddOnIds || []).includes(addon.inventoryItemId)) ||
                            Boolean(invItem && (systemSettings.outOfStockAddOnIds || []).includes(invItem.id));
                          isOutOfStock = Boolean(isOutOfStockFromInv || isOutOfStockFromSettings);
                        }

                        return (
                          <div key={addon.id} className="flex justify-between items-center p-2.5 rounded-xl border border-black/10 dark:border-white/10 bg-black/5 dark:bg-white/5">
                            <div className="flex-1 pr-2">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <p className="font-medium text-gray-900 dark:text-white text-xs">{addon.name}</p>
                                {(invItem || isOutOfStock) && (
                                  <span className={cn(
                                    "text-[9px] font-mono px-1.5 py-0.5 rounded",
                                    isOutOfStock ? "bg-rose-500/10 text-rose-500 font-bold" : "bg-black/10 dark:bg-white/10 text-gray-500 dark:text-gray-400"
                                  )}>
                                    {isOutOfStock ? 'Hết hàng' : (invItem ? `Còn: ${invItem.stock} ${invItem.unit}` : 'Còn hàng')}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs font-bold text-emerald-600 dark:text-emerald-500 mt-0.5">
                                {addon.price > 0 ? `+${addon.price.toLocaleString()}đ` : 'Miễn phí'}
                                {addon.quantity && addon.quantity !== 1 && (
                                  <span className="text-gray-400 font-normal ml-1">({addon.quantity} {addon.unit || invItem?.unit || 'phần'})</span>
                                )}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                               {count > 0 && (
                                 <button 
                                   type="button"
                                   onClick={() => {
                                     const idx = selectedAddOns.findIndex(a => a.id === addon.id);
                                     if (idx > -1) {
                                       const newAddOns = [...selectedAddOns];
                                       newAddOns.splice(idx, 1);
                                       setSelectedAddOns(newAddOns);
                                     }
                                   }} 
                                   className="p-1 bg-black/10 dark:bg-white/10 rounded hover:bg-white/20 cursor-pointer"
                                 >
                                   <Minus className="w-3 h-3" />
                                 </button>
                               )}
                               <span className={cn("text-xs font-bold w-4 text-center font-mono", count > 0 ? "text-emerald-600 dark:text-emerald-400 font-bold" : "text-gray-600 dark:text-gray-400")}>{count}</span>
                               <button 
                                 type="button"
                                 disabled={isOutOfStock}
                                 onClick={() => setSelectedAddOns([...selectedAddOns, { ...addon, inventoryItemId: addon.inventoryItemId || invItem?.id }])} 
                                 className={cn(
                                   "p-1 rounded cursor-pointer transition-all",
                                   isOutOfStock ? "bg-black/5 dark:bg-white/5 text-gray-400 cursor-not-allowed opacity-50" : "bg-black/10 dark:bg-white/10 hover:bg-white/20"
                                 )}
                                 title={isOutOfStock ? 'Hết kho' : 'Thêm 1'}
                               >
                                 <Plus className="w-3 h-3" />
                               </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Note */}
                  <div className="space-y-1.5">
                    <p className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-wider">Ghi chú</p>
                    <textarea 
                      className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl p-2.5 text-xs text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500"
                      rows={2}
                      placeholder="VD: Không hành, ít cay..."
                      value={itemNote}
                      onChange={(e) => setItemNote(e.target.value)}
                    />
                  </div>

                  {/* Total price preview for configured dish + add-ons */}
                  <div className="flex justify-between items-center py-2 px-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                    <div>
                      <span className="text-xs text-emerald-800 dark:text-emerald-300 font-semibold block">Tạm tính</span>
                      <span className="text-[10px] text-gray-500">
                        ({configuringItem.price.toLocaleString()}đ {selectedAddOns.length > 0 ? `+ ${selectedAddOns.reduce((s, a) => s + a.price, 0).toLocaleString()}đ kèm` : ''}) × {itemQuantity}
                      </span>
                    </div>
                    <span className="text-sm md:text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
                      {((configuringItem.price + selectedAddOns.reduce((s, a) => s + a.price, 0)) * itemQuantity).toLocaleString()}đ
                    </span>
                  </div>
                </div>

                <div className="flex gap-2.5 pt-3 border-t border-black/5 dark:border-white/5 shrink-0">
                  <button 
                    onClick={() => setConfiguringItem(null)}
                    className="flex-1 py-2.5 rounded-xl border border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer text-xs"
                  >
                    Hủy
                  </button>
                  <button 
                    onClick={handleConfirmAddItem}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-400 cursor-pointer text-xs transition-colors shadow-sm"
                  >
                    Thêm vào đơn
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Merge Table Modal */}
        {showMergeModal && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
            <div className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-3xl p-8 border border-black/10 dark:border-white/10 shadow-2xl space-y-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Gộp bàn</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Chọn các bàn muốn gộp vào bàn <span className="font-bold text-gray-900 dark:text-white">{activeTable.name}</span>:</p>
              
              <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                {tables.filter(t => t.id !== activeTable.id && t.status === 'occupied').map(t => (
                  <button
                    key={t.id}
                    onClick={() => {
                      setTablesToMerge(prev => prev.includes(t.id) ? prev.filter(id => id !== t.id) : [...prev, t.id]);
                    }}
                    className={cn(
                      "w-full flex justify-between items-center p-3 rounded-xl border transition-all",
                      tablesToMerge.includes(t.id) 
                        ? "bg-blue-500/20 border-blue-500 text-blue-600 dark:text-blue-500" 
                        : "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:bg-black/10 dark:hover:bg-white/10"
                    )}
                  >
                    <span>{t.name}</span>
                    {tablesToMerge.includes(t.id) && <Check className="w-4 h-4" />}
                  </button>
                ))}
                {tables.filter(t => t.id !== activeTable.id && t.status === 'occupied').length === 0 && (
                  <p className="text-center text-gray-500 italic py-4">Không có bàn nào đang hoạt động để gộp.</p>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button 
                  onClick={() => setShowMergeModal(false)}
                  className="flex-1 py-3 rounded-xl border border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
                >
                  Hủy
                </button>
                <button 
                  onClick={async () => {
                    if (isProcessing) return;
                    setIsProcessing(true);
                    try { await onMergeTables(activeTable.id, tablesToMerge, moveOperationRef.current); moveOperationRef.current = operationId('move'); setShowMergeModal(false); }
                    catch (error) { alert(error instanceof Error ? error.message : 'Không thể gộp bàn.'); }
                    finally { setIsProcessing(false); }
                  }}
                  disabled={tablesToMerge.length === 0 || isProcessing}
                  className="flex-1 py-3 rounded-xl bg-blue-500 text-gray-900 dark:text-white font-bold hover:bg-blue-600 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Xác nhận gộp
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Transfer Table Modal */}
        {showTransferModal && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
            <div className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-3xl p-8 border border-black/10 dark:border-white/10 shadow-2xl space-y-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Chuyển bàn</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Chọn bàn muốn chuyển đơn từ bàn <span className="font-bold text-gray-900 dark:text-white">{activeTable.name}</span> đến:</p>
              
              <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                {tables.filter(t => t.id !== activeTable.id && t.status === 'empty').map(t => (
                  <button
                    key={t.id}
                    onClick={() => setTargetTransferTable(t.id)}
                    className={cn(
                      "w-full flex justify-between items-center p-3 rounded-xl border transition-all",
                      targetTransferTable === t.id 
                        ? "bg-purple-500/20 border-purple-500 text-purple-500" 
                        : "bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:bg-black/10 dark:hover:bg-white/10"
                    )}
                  >
                    <span>{t.name}</span>
                    {targetTransferTable === t.id && <Check className="w-4 h-4" />}
                  </button>
                ))}
                {tables.filter(t => t.id !== activeTable.id && t.status === 'empty').length === 0 && (
                  <p className="text-center text-gray-500 italic py-4">Không có bàn trống nào để chuyển.</p>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button 
                  onClick={() => setShowTransferModal(false)}
                  className="flex-1 py-3 rounded-xl border border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
                >
                  Hủy
                </button>
                <button 
                  onClick={async () => {
                    if (!targetTransferTable || isProcessing) return;
                    setIsProcessing(true);
                    try { await onTransferTable(activeTable.id, targetTransferTable, moveOperationRef.current); moveOperationRef.current = operationId('move'); setShowTransferModal(false); onClose(); }
                    catch (error) { alert(error instanceof Error ? error.message : 'Không thể chuyển bàn.'); }
                    finally { setIsProcessing(false); }
                  }}
                  disabled={!targetTransferTable || isProcessing}
                  className="flex-1 py-3 rounded-xl bg-purple-500 text-gray-900 dark:text-white font-bold hover:bg-purple-600 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Xác nhận chuyển
                </button>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

const ReportsView = ({ invoices, activeOrdersCount, businessDate, isDataReady = false }: { invoices: Invoice[], activeOrdersCount: number, businessDate?: string, isDataReady?: boolean }) => {
  const todayVn = businessDate || getVietnamBusinessDate();
  
  // Lọc chuẩn theo ngày kinh doanh Việt Nam (hỗ trợ cả schema businessDate và legacy date ISO)
  const todayInvoices = invoices.filter(inv => {
    const invDateStr = inv.businessDate || getVietnamBusinessDate(inv.date);
    return invDateStr === todayVn;
  });
  const todayRevenue = todayInvoices.reduce((sum, inv) => sum + inv.total, 0);
  const todayOrders = todayInvoices.length;

  const chartData = Array.from({ length: 12 }, (_, i) => {
    const hour = i * 2;
    const label = `${hour.toString().padStart(2, '0')}:00`;
    const revenue = todayInvoices.reduce((sum, inv) => {
      let invHour = 0;
      try {
        const d = new Date(inv.date);
        invHour = parseInt(new Intl.DateTimeFormat('en-GB', {
          timeZone: 'Asia/Ho_Chi_Minh',
          hour: '2-digit',
          hour12: false
        }).format(d), 10);
      } catch {
        invHour = parseISO(inv.date).getHours();
      }
      if (invHour >= hour && invHour < hour + 2) {
        return sum + inv.total;
      }
      return sum;
    }, 0);
    return { name: label, revenue };
  });

  const productSales = todayInvoices.reduce((acc: Record<string, { name: string, sales: number }>, inv) => {
    inv.items.forEach(item => {
      if (!acc[item.id]) acc[item.id] = { name: item.name, sales: 0 };
      acc[item.id].sales += item.quantity;
    });
    return acc;
  }, {});

  const topProducts = Object.values(productSales)
    .sort((a, b) => b.sales - a.sales)
    .slice(0, 5)
    .map((p, i) => ({
      ...p,
      color: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'][i % 5]
    }));

  return (
    <div className="p-8 space-y-8 overflow-y-auto h-full">
      {!isDataReady && <div role="status" className="p-3 rounded-xl bg-amber-500/10 text-amber-700">Đang đồng bộ chứng từ; doanh thu và số đơn hiện chưa được server xác nhận đầy đủ.</div>}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Báo cáo doanh thu (Hôm nay)</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Đang phục vụ', value: `${activeOrdersCount || 0} đơn`, trend: '', icon: Check, color: 'text-cyan-600 dark:text-cyan-500', isLive: true },
          { label: 'Doanh thu hôm nay', value: `${todayRevenue.toLocaleString('vi-VN', { minimumFractionDigits: 0, maximumFractionDigits: 1 })}đ`, trend: '', icon: BarChart3, color: 'text-emerald-600 dark:text-emerald-500' },
          { label: 'Đơn hàng hôm nay', value: todayOrders.toString(), trend: '', icon: UtensilsCrossed, color: 'text-blue-600 dark:text-blue-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-6 rounded-2xl space-y-2 relative overflow-hidden">
            {stat.isLive && activeOrdersCount > 0 && (
              <div className="absolute top-0 right-0 p-4">
                <span className="flex w-3 h-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                </span>
              </div>
            )}
            <div className="flex justify-between items-start">
              <div className={cn("p-2 rounded-lg bg-black/5 dark:bg-white/5", stat.color)}>
                <stat.icon className="w-5 h-5" />
              </div>
            </div>
            <p className="text-gray-500 text-sm">{stat.label}</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-6 rounded-2xl space-y-6">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white">Biểu đồ doanh thu hôm nay (theo giờ)</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="name" stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => v >= 1000000 ? `${(v/1000000).toFixed(1)}M` : `${(v/1000).toFixed(0)}K`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a1b1e', border: '1px solid #ffffff10', borderRadius: '12px', color: '#f3f4f6' }}
                  itemStyle={{ color: '#10b981' }}
                  formatter={(v: number) => [v.toLocaleString() + 'đ', 'Doanh thu']}
                />
                <Line type="monotone" dataKey="revenue" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-6 rounded-2xl space-y-6">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white">Top 5 món bán chạy nhất hôm nay</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topProducts} layout="vertical">
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" stroke="#6b7280" fontSize={12} tickLine={false} axisLine={false} width={100} />
                <Tooltip 
                  cursor={{ fill: '#ffffff05' }}
                  contentStyle={{ backgroundColor: '#1a1b1e', border: '1px solid #ffffff10', borderRadius: '12px', color: '#f3f4f6' }}
                  itemStyle={{ color: '#f3f4f6' }}
                  formatter={(v: number) => [v.toLocaleString(), 'Số lượng']}
                />
                <Bar dataKey="sales" radius={[0, 4, 4, 0]} barSize={24}>
                  {topProducts.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [showScanner, setShowScanner] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const savedUser = safeStorage.getItem('fnb_master_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [isRegistering, setIsRegistering] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('register') === 'true' || params.get('mode') === 'register' || params.get('view') === 'register';
    }
    return false;
  });
  const [users, setUsers] = useState<User[]>([]);
    const [view, setView] = useState<ViewType>(() => {
    const savedUser = safeStorage.getItem('fnb_master_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      if (user.role === 'admin' || user.role === 'manager') return 'tables';
      if (user.role === 'kitchen') return 'kitchen';
      return 'shifts';
    }
    return 'tables';
  });

  const handleSetView = (newView: ViewType) => {
    setView(newView);
  };
  const [confirmDialog, setConfirmDialog] = useState<{ message: string, onConfirm: () => void } | null>(null);
  const [tables, setTables] = useState<Table[]>(INITIAL_TABLES);
  const [tableGroups, setTableGroups] = useState<TableGroup[]>([]);
  const [activeTableGroup, setActiveTableGroup] = useState<string>('all');
  const [activeTableStatus, setActiveTableStatus] = useState<'all' | 'empty' | 'occupied'>('all');
  const [packages, setPackages] = useState<any[]>([]);
  const [featureLimitMessage, setFeatureLimitMessage] = useState<string | null>(null);
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const checkFeatureLimit = (feature: string, currentUsage: number): boolean => {
    const currentPackageId = currentUser?.store?.subscription?.packageId || 'trial';
    const currentPackage = packages.find(p => p.id === currentPackageId);
    if (!currentPackage) return true; // If package not found, allow by default or maybe deny? Let's allow.

    if (feature === 'maxUsers') {
      const maxUsers = currentPackage.features?.maxUsers || 999;
      if (currentUsage >= maxUsers) {
        setFeatureLimitMessage(`Gói hiện tại của bạn chỉ cho phép tạo tối đa ${maxUsers} nhân viên.`);
        return false;
      }
    }
    return true;
  };

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        const snapshot = await getDocs(collection(db, 'packages'));
        const pkgs = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
        setPackages(pkgs);
      } catch (err) {
        console.error(err);
      }
    };
    fetchPackages();
  }, []);
  const [menu, setMenu] = useState<MenuItem[]>(INITIAL_MENU);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [invoicesReady, setInvoicesReady] = useState(false);
  const [inventoryLogs, setInventoryLogs] = useState<InventoryTransaction[]>([]);
  const [inventoryAudits, setInventoryAudits] = useState<InventoryAudit[]>([]);
  const [stockCardEntries, setStockCardEntries] = useState<StockCardEntry[]>([]);
  const [cashTransactions, setCashTransactions] = useState<CashTransaction[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [payrollSourceReady, setPayrollSourceReady] = useState(false);
  const [myTodayAttendance, setMyTodayAttendance] = useState<AttendanceRecord[]>([]);
  const [currentBusinessDate, setCurrentBusinessDate] = useState<string>(() => getVietnamBusinessDate());

  // Khóa chống ghi lặp khi thanh toán đa luồng / double-click (P0 Idempotency & Replay Protection)
  const checkoutLockRef = useRef<Set<string>>(new Set());

  // Tự động kiểm tra và cập nhật ngày kinh doanh (Việt Nam UTC+7) khi qua nửa đêm hoặc khi app resume từ background
  useEffect(() => {
    const checkBusinessDate = () => {
      const todayVietnam = getVietnamBusinessDate();
      setCurrentBusinessDate(prev => {
        if (prev !== todayVietnam) {
          console.log(`[Fnb Master] Tự động chuyển ngày kinh doanh: ${prev} -> ${todayVietnam}`);
          return todayVietnam;
        }
        return prev;
      });
    };

    const intervalId = setInterval(checkBusinessDate, 30000);
    window.addEventListener('focus', checkBusinessDate);
    document.addEventListener('visibilitychange', checkBusinessDate);

    return () => {
      clearInterval(intervalId);
      window.removeEventListener('focus', checkBusinessDate);
      document.removeEventListener('visibilitychange', checkBusinessDate);
    };
  }, []);

  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    storeName: 'FNB Master POS',
    address: '',
    phone: '',
    logo: '',
    adminUsername: 'admin',
    kitchenEnabled: true,
    kitchenBellEnabled: true,
    vatPercent: 8,
    kitchenBillTemplate: 'Mẫu bill bếp mặc định',
    paymentBillTemplate: 'Mẫu bill thanh toán mặc định',
    menuCategories: CATEGORIES,
    inventoryCategories: ['Nguyên liệu', 'Đồ uống', 'Khác'],
    cashCategories: ['Bán hàng', 'Tiền điện', 'Tiền nước', 'Tiền mặt bằng', 'Nhập hàng', 'Lương nhân viên', 'Khác'],
    customerTypes: [
      { id: '1', name: 'Thành viên', discountPercent: 5 },
      { id: '2', name: 'VIP', discountPercent: 10 }
    ],
    printers: [{
      id: 'default-printer',
      name: 'Máy in hóa đơn (Mặc định)',
      ipAddress: '192.168.1.200',
      port: 9100,
      type: 'both',
      isDefault: true,
      isEnabled: true,
      paperSize: '80mm'
    }],
    silentPrinting: true,
    kitchenTemplate: {
      showTime: true,
      showStaffName: true,
      showStoreAddress: false,
      showStorePhone: false,
      showLogo: false,
      showNote: true,
      showCustomerInfo: false,
      fontSize: 'medium'
    },
    paymentTemplate: {
      showTime: true,
      showStaffName: true,
      showStoreAddress: true,
      showStorePhone: true,
      showLogo: true,
      showNote: true,
      showCustomerInfo: true,
      fontSize: 'medium'
    },
    outOfStockAddOnIds: []
  });

  const settingsDocIdRef = useRef<string | null>(null);

  const getLinkedAddOnIds = (itemId: string, currentMenu: MenuItem[]): string[] => {
    const ids = new Set<string>([itemId]);
    const targetItem = currentMenu.find(m => m.id === itemId);
    const targetName = targetItem?.name.toLowerCase().trim();

    currentMenu.forEach(dish => {
      (dish.addOns || []).forEach(addon => {
        const matchId = addon.inventoryItemId === itemId || addon.id === itemId;
        const matchName = targetName && addon.name.toLowerCase().trim() === targetName;
        if (matchId || matchName) {
          ids.add(addon.id);
          if (addon.inventoryItemId) ids.add(addon.inventoryItemId);
        }
      });
    });
    return Array.from(ids);
  };

  const getSettingsDocRef = async (storeId: string) => {
    if (settingsDocIdRef.current) {
      return doc(db, 'settings', settingsDocIdRef.current);
    }
    const q = query(collection(db, 'settings'), where('storeId', '==', storeId), limit(1));
    const snap = await getDocs(q);
    if (!snap.empty) {
      settingsDocIdRef.current = snap.docs[0].id;
      return doc(db, 'settings', snap.docs[0].id);
    }
    const newRef = doc(collection(db, 'settings'));
    await setDoc(newRef, { storeId, outOfStockAddOnIds: [] }, { merge: true });
    settingsDocIdRef.current = newRef.id;
    return newRef;
  };

  const updateOutOfStockStatus = async (itemIdsOut: string[], itemIdsIn: string[]) => {
    if(!currentUser?.storeId)return;
    const storeId=currentUser.storeId,ids=[...new Set([...itemIdsOut,...itemIdsIn])].filter(Boolean);
    if(!ids.length)return;
    const settingsRef=await getSettingsDocRef(storeId);
    await runTransaction(db,async txn=>{
      const settings=await txn.get(settingsRef);
      if(settings.exists()&&settings.data().storeId!==storeId)throw new Error('Cài đặt không thuộc cửa hàng.');
      const reads=[];
      for(const id of ids){const snapshot=await txn.get(doc(db,'menu',id));if(snapshot.exists()&&snapshot.data().storeId!==storeId)throw new Error('Mặt hàng không thuộc cửa hàng.');reads.push({id,data:snapshot.data()});}
      const out=new Set<string>(),available=new Set<string>();
      for(const {id,data} of reads){
        const target=data&&data.trackStock===false?available:!data||(data.stock||0)<=0?out:available;
        getLinkedAddOnIds(id,menu).forEach(linked=>target.add(linked));
      }
      const next=new Set<string>(settings.data()?.outOfStockAddOnIds||[]);
      available.forEach(id=>{if(!out.has(id))next.delete(id);});out.forEach(id=>next.add(id));
      txn.set(settingsRef,{storeId,outOfStockAddOnIds:[...next]},{merge:true});
    });
  };

  const hasReconciledOutOfStockRef = useRef(false);

  const reconcileOutOfStockStatus = async (storeId: string, currentMenu: MenuItem[], currentOutOfStock: string[]) => {
    if (!storeId || currentMenu.length === 0) return;

    const expectedOutIds = new Set<string>();
    currentMenu.forEach(item => {
      if (item.trackStock !== false && item.stock !== undefined && item.stock <= 0) {
        getLinkedAddOnIds(item.id, currentMenu).forEach(id => expectedOutIds.add(id));
      }
    });

    const settingsSnapshot=await getDocFromServer(await getSettingsDocRef(storeId));
    const currentSet = new Set<string>(settingsSnapshot.data()?.outOfStockAddOnIds || []);

    const missingOut: string[] = [];
    expectedOutIds.forEach(id => {
      if (!currentSet.has(id)) missingOut.push(id);
    });

    const spuriousOut: string[] = [];
    currentSet.forEach(id => {
      const matched = currentMenu.find(m => m.id === id);
      if (matched && (matched.trackStock === false || (matched.stock !== undefined && matched.stock > 0))) {
        spuriousOut.push(id);
      }
    });

    if (missingOut.length > 0 || spuriousOut.length > 0) {
      await updateOutOfStockStatus(missingOut, spuriousOut);
    }
  };

  const [localPrinters, setLocalPrinters] = useState<any[]>([]);

  useEffect(() => {
    if (currentUser?.storeId) {
      try {
        const saved = localStorage.getItem(`printers_${currentUser.storeId}`);
        if (saved) {
          setLocalPrinters(JSON.parse(saved));
        } else if (systemSettings.printers && systemSettings.printers.length > 0) {
          // Kế thừa máy in từ cấu hình cũ (nếu có)
          setLocalPrinters(systemSettings.printers);
          localStorage.setItem(`printers_${currentUser.storeId}`, JSON.stringify(systemSettings.printers));
        } else {
          setLocalPrinters([]);
        }
      } catch(e) {
        setLocalPrinters([]);
      }
    } else {
      setLocalPrinters([]);
    }
  }, [currentUser?.storeId, systemSettings.printers]); // Re-evaluate if user changes or systemSettings initialize

  const handleUpdateLocalPrinters = (printers: any[]) => {
    setLocalPrinters(printers);
    if (currentUser?.storeId) {
      localStorage.setItem(`printers_${currentUser.storeId}`, JSON.stringify(printers));
    }
  };

  const [printData, setPrintData] = useState<{
    type: 'bill' | 'kitchen';
    tableName: string;
    items: OrderItem[];
    total?: number;
    discount?: number;
    vat?: number;
    staffName: string;
  } | null>(null);

  const categories = systemSettings.menuCategories || CATEGORIES;

  const triggerPrint = async (data: {
    type: 'bill' | 'kitchen';
    tableName: string;
    items: OrderItem[];
    total?: number;
    subtotal?: number;
    discount?: number;
    vat?: number;
    staffName: string;
    date?: string;
    timeIn?: string;
    timeOut?: string;
    note?: string;
    customerName?: string;
    customerType?: string;
  }) => {
    // 1. Find suitable printers
    const printers = localPrinters.length > 0 ? localPrinters : (systemSettings.printers || []);
    const targetPrinters = printers.filter(p => p.isEnabled && (p.type === data.type || p.type === 'both'));


    // 2. Get Template Settings
    const template = data.type === 'kitchen' 
      ? (systemSettings.kitchenTemplate || { showTime: true, showStaffName: true, showStoreAddress: false, showStorePhone: false, showLogo: false, showNote: true, fontSize: 'medium' })
      : (systemSettings.paymentTemplate || { showTime: true, showStaffName: true, showStoreAddress: true, showStorePhone: true, showLogo: true, showNote: true, fontSize: 'medium' });

    // 3. Generate Content
    const styles = `
      <style>
        body { font-family: 'Courier New', monospace; padding: 20px; max-width: 300px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 20px; border-bottom: 1px dashed #000; padding-bottom: 10px; }
        .store-name { font-size: 1.2em; font-weight: bold; }
        .title { font-size: 1.1em; font-weight: bold; margin: 10px 0; }
        .info { font-size: 0.9em; margin-bottom: 5px; }
        .items { width: 100%; border-collapse: collapse; margin: 15px 0; }
        .items th { text-align: left; border-bottom: 1px solid #000; }
        .items td { padding: 5px 0; }
        .total-section { border-top: 1px dashed #000; padding-top: 10px; margin-top: 10px; }
        .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
        .footer { text-align: center; margin-top: 20px; font-size: 0.8em; }
        .text-small { font-size: 12px; }
        .text-medium { font-size: 14px; }
        .text-large { font-size: 16px; }
      </style>
    `;

    const fontSizeClass = `text-${template.fontSize}`;

    let content = `
      <html>
        <head>
          <title>In ${data.type === 'kitchen' ? 'Bếp' : 'Hóa đơn'}</title>
          ${styles}
        </head>
        <body class="${fontSizeClass}">
          <div class="header">
            ${template.showLogo && systemSettings.logo ? `<img src="${systemSettings.logo}" style="max-width: 50px; margin-bottom: 5px;" />` : ''}
            <div class="store-name">${systemSettings.storeName}</div>
            ${template.showStoreAddress && systemSettings.address ? `<div>${systemSettings.address}</div>` : ''}
            ${template.showStorePhone && systemSettings.phone ? `<div>${systemSettings.phone}</div>` : ''}
            <div class="title">${data.type === 'kitchen' ? 'PHIẾU BẾP' : 'HÓA ĐƠN THANH TOÁN'}</div>
          </div>

          <div class="info">
            <div>Bàn: <strong>${data.tableName}</strong></div>
            ${template.showTime && data.timeIn ? `<div>Giờ vào: ${new Date(data.timeIn).toLocaleString('vi-VN')}</div>` : ''}
            ${template.showTime && data.timeOut ? `<div>Giờ ra: ${new Date(data.timeOut).toLocaleString('vi-VN')}</div>` : ''}
            ${template.showTime && !data.timeIn && !data.timeOut ? `<div>Thời gian: ${data.date || new Date().toLocaleString('vi-VN')}</div>` : ''}
            ${template.showStaffName ? `<div>Nhân viên: ${data.staffName}</div>` : ''}
            ${template.showCustomerInfo && data.customerName ? `<div>Khách hàng: <strong>${data.customerName}</strong> ${data.customerType ? `(${data.customerType})` : ''}</div>` : ''}
          </div>

          <table class="items">
            <thead>
              <tr>
                <th style="width: 40%">Món</th>
                <th style="width: 20%; text-align: center">SL</th>
                ${data.type === 'bill' ? '<th style="width: 40%; text-align: right">Thành tiền</th>' : ''}
              </tr>
            </thead>
            <tbody>
              ${data.items.map(item => `
                <tr>
                  <td>
                    <div style="font-weight: bold;">${item.name}</div>
                    ${item.selectedAddOns && item.selectedAddOns.length > 0 ? `
                      <div style="font-size: 0.8em; padding-left: 10px;">
                        ${Object.entries(item.selectedAddOns.reduce((acc, a) => {
                          const key = a.price > 0 ? `${a.name} (+${a.price.toLocaleString()}đ)` : a.name;
                          acc[key] = (acc[key] || 0) + 1;
                          return acc;
                        }, {} as Record<string, number>)).map(([text, count]) => `+ ${text} ${count > 1 ? `(x${count})` : ''}`).join('<br/>')}
                      </div>
                    ` : ''}
                  </td>
                  <td style="text-align: center; vertical-align: top; font-weight: bold; font-size: 1.2em;">${item.quantity}</td>
                  ${data.type === 'bill' ? `<td style="text-align: right; vertical-align: top;">${((item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0)) * item.quantity).toLocaleString()}</td>` : ''}
                </tr>
                ${item.note && template.showNote ? `<tr><td colspan="3" style="font-style: italic; font-size: 0.9em; padding-left: 10px; border-bottom: 1px solid #eee; padding-bottom: 5px;">Ghi chú: ${item.note}</td></tr>` : ''}
              `).join('')}
            </tbody>
          </table>
    `;

    if (data.type === 'bill' && data.total !== undefined) {
      content += `
          <div class="total-section">
            ${data.note && template.showNote ? `<div style="font-style: italic; font-size: 0.9em; margin-bottom: 10px; border-bottom: 1px dashed #eee; padding-bottom: 5px;">Ghi chú: ${data.note}</div>` : ''}
            <div class="row">
              <span>Tạm tính:</span>
              <span>${(data.subtotal !== undefined ? data.subtotal : data.items.reduce((acc, item) => acc + (item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0)) * item.quantity, 0)).toLocaleString()}</span>
            </div>
            ${data.discount ? `
            <div class="row">
              <span>Giảm giá:</span>
              <span>-${data.discount.toLocaleString()}</span>
            </div>` : ''}
            ${data.vat ? `
            <div class="row">
              <span>VAT (${systemSettings.vatPercent}%):</span>
              <span>${data.vat.toLocaleString()}</span>
            </div>` : ''}
            <div class="row" style="font-weight: bold; font-size: 1.2em; margin-top: 5px;">
              <span>Tổng cộng:</span>
              <span>${data.total.toLocaleString()}</span>
            </div>
          </div>
      `;
    }

    content += `
          <div class="footer">
            <div>Cảm ơn quý khách!</div>
            <div>Hẹn gặp lại</div>
          </div>
        </body>
      </html>
    `;

    // Always update in-app printData
    setPrintData(data);

    // 4. Handle Silent Printing if enabled (Only on Native Android/iOS via TCP Socket)
    const isNative = Capacitor.isNativePlatform();
    if (isNative && systemSettings.silentPrinting) {
      if (targetPrinters.length === 0) {
        alert(`Không tìm thấy máy in nào được cài đặt cho ${data.type === 'kitchen' ? 'bếp' : 'hóa đơn'}! Vui lòng kiểm tra cài đặt máy in.`);
        return;
      }

      try {
        let allSuccess = true;
        for (const p of targetPrinters) {
          const success = await PrinterService.printDirect(p, data, systemSettings);
          if (!success) allSuccess = false;
        }
        if (allSuccess) return; 
      } catch (error) {
        alert(error instanceof Error ? error.message : 'Lỗi máy in không xác định');
        return;
      }
    }

    // 5. Browser Print (Web / Desktop browser)
    // Uses hidden iframe to prevent popup blocker blocking window.open in browsers
    const printFrameId = '__app_web_print_iframe__';
    let printFrame = document.getElementById(printFrameId) as HTMLIFrameElement | null;
    if (!printFrame) {
      printFrame = document.createElement('iframe');
      printFrame.id = printFrameId;
      printFrame.style.position = 'fixed';
      printFrame.style.right = '0';
      printFrame.style.bottom = '0';
      printFrame.style.width = '0px';
      printFrame.style.height = '0px';
      printFrame.style.border = 'none';
      printFrame.style.zIndex = '-9999';
      document.body.appendChild(printFrame);
    }

    try {
      const frameDoc = printFrame.contentWindow?.document || printFrame.contentDocument;
      if (frameDoc) {
        frameDoc.open();
        frameDoc.write(content);
        frameDoc.close();
        setTimeout(() => {
          try {
            printFrame?.contentWindow?.focus();
            printFrame?.contentWindow?.print();
          } catch (e) {
            console.warn('Iframe print failed, falling back to window.print', e);
            window.print();
          }
        }, 350);
      } else {
        window.print();
      }
    } catch (err) {
      console.warn('Print iframe error, calling window.print:', err);
      window.print();
    }
  };

  const [selectedTable, setSelectedTable] = useState<Table | null>(null);

  const [editingTable, setEditingTable] = useState<Table | null>(null);
  const [showAddTableModal, setShowAddTableModal] = useState(false);
  const [showAddGroupModal, setShowAddGroupModal] = useState(false);
  const [newTableName, setNewTableName] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');
  const [newGroupName, setNewGroupName] = useState('');
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [activeShift, setActiveShift] = useState<Shift | null>(null);
  const [allActiveShifts, setAllActiveShifts] = useState<Shift[]>([]);

  // Firebase Sync - Role-based & Selective Subscription (Tối ưu triệt để lượt đọc Firestore)
  useEffect(() => {
    if (!currentUser) return;

    let isMounted = true;
    const storeId = currentUser.storeId;
    const isKitchenOrOrder = currentUser.role === 'kitchen' || currentUser.role === 'order';
    const unsubs: (() => void)[] = [];

    // 1. Sync Store Data (Cần thiết cho mọi vai trò để kiểm tra gói & hạn dùng)
    const storeRef = doc(db, 'stores', storeId);
    const unsubStore = onSnapshot(storeRef, (docSnap) => {
      if (!isMounted) return;
      if (docSnap.exists()) {
        const storeData = { ...docSnap.data(), id: docSnap.id } as any;

        // Auto-check for expiration
        if (storeData.subscription) {
          const now = new Date();
          let newStatus = storeData.subscription.status;
          let shouldUpdate = false;

          if (storeData.subscription.status === 'trial' && storeData.subscription.trialEndDate) {
            if (now > new Date(storeData.subscription.trialEndDate)) {
              newStatus = 'expired';
              shouldUpdate = true;
            }
          } else if (storeData.subscription.status === 'active' && storeData.subscription.validUntil) {
            if (now > new Date(storeData.subscription.validUntil)) {
              newStatus = 'expired';
              shouldUpdate = true;
            }
          }

          if (shouldUpdate) {
            storeData.subscription.status = newStatus;
          }
        }

        setCurrentUser(prev => {
          if (!prev) return prev;
          const updatedUser = { ...prev, store: storeData };
          localStorage.setItem('currentUser', JSON.stringify(updatedUser));
          return updatedUser;
        });
      }
    });
    unsubs.push(unsubStore);

    // 2. Sync Menu:
    // - Bếp (kitchen): KHÔNG nghe menu (chỉ hiển thị vé món theo bàn, tiết kiệm 100% reads)
    // - Phục vụ (order): Khi cửa hàng đã hoàn tất migration, CHỈ nghe món bán thực đơn (isInventory == false) để tiết kiệm reads;
    //   Nếu chưa hoàn tất migration, nghe menu và phân loại an toàn theo tiêu chí nghiệp vụ trên máy (không bao giờ ẩn món cũ)
    // - Thu ngân / Quản lý / Admin: Nghe đầy đủ để phục vụ thanh toán trừ kho công thức và quản lý tồn kho
    if (currentUser.role !== 'kitchen') {
      const isMenuMigrated = currentUser.store?.migrationStatus?.menu === 'completed';
      const menuQuery = (currentUser.role === 'order' && isMenuMigrated)
        ? query(collection(db, 'menu'), where('storeId', '==', storeId), where('isInventory', '==', false))
        : query(collection(db, 'menu'), where('storeId', '==', storeId));

      const unsubMenu = onSnapshot(menuQuery, (snapshot) => {
        if (!isMounted) return;

        let menuData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as MenuItem));

        // Phân loại an toàn trên client nếu là role order nhưng chưa hoàn tất migration:
        if (currentUser.role === 'order' && !isMenuMigrated) {
          menuData = menuData.filter(item => {
            if (item.isInventory === true) return false;
            if (item.isInventory === false) return true;
            // Tiêu chuẩn nghiệp vụ: Món chế biến hoặc hàng hóa có giá bán lẻ > 0 không phải nguyên liệu kho
            if (item.type === 'dish') return true;
            if (item.category === 'Nguyên liệu' || item.code?.startsWith('NL') || item.name?.toLowerCase().endsWith('_nl')) {
              return false;
            }
            return (item.price || 0) > 0;
          });
        }

        const sources = new Map(menuData.map(item => [item.id,item]));
        menuData = menuData.map(item => item.recipe?.length && item.recipe.every(r => typeof sources.get(r.ingredientId)?.costPrice === 'number')
          ? { ...item, costPrice: Math.round(item.recipe.reduce((sum,r) => sum + sources.get(r.ingredientId)!.costPrice*r.quantity,0)) }
          : item);
        setMenu(menuData);

        // Tự động kiểm tra & đồng bộ outOfStockAddOnIds cho quán cũ khi menu vừa tải (Admin / Manager)
        if (!hasReconciledOutOfStockRef.current && menuData.length > 0 && (currentUser.role === 'admin' || currentUser.role === 'manager')) {
          hasReconciledOutOfStockRef.current = true;
          reconcileOutOfStockStatus(storeId, menuData, systemSettings.outOfStockAddOnIds || []).catch(console.warn);
        }
      }, (err) => console.warn('Lỗi menu listener:', err));
      unsubs.push(unsubMenu);
    }

    // 3. Sync Tables (Trạng thái bàn & món ăn đang gọi)
    const tablesQuery = query(collection(db, 'tables'), where('storeId', '==', storeId));
    const unsubTables = onSnapshot(tablesQuery, (snapshot) => {
      snapshot.docs.forEach(docSnap => {
        const data = docSnap.data();
        if (data.status === 'empty' && data.note) {
          updateDoc(doc(db, 'tables', docSnap.id), { note: deleteField() }).catch(console.error);
        }
      });

      const tablesData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Table));
      const sortedTables = tablesData.sort((a, b) => {
        const numA = parseInt(a.name.replace(/\D/g, '')) || 0;
        const numB = parseInt(b.name.replace(/\D/g, '')) || 0;
        return numA - numB;
      });
      setTables(sortedTables);
    });
    unsubs.push(unsubTables);

    // 4. Sync Table Groups (Khu vực bàn)
    const groupsQuery = query(collection(db, 'table_groups'), where('storeId', '==', storeId));
    const unsubGroups = onSnapshot(groupsQuery, (snapshot) => {
      const groupsData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as TableGroup));
      setTableGroups(groupsData);
    });
    unsubs.push(unsubGroups);

    // 5. Sync Settings (Cài đặt quán)
    const settingsQuery = query(collection(db, 'settings'), where('storeId', '==', storeId));
    const unsubSettings = onSnapshot(settingsQuery, (snapshot) => {
      if (!snapshot.empty) {
        settingsDocIdRef.current = snapshot.docs[0].id;
        const settingsData = snapshot.docs[0].data() as SystemSettings;
        setSystemSettings(prev => ({ ...prev, ...settingsData }));
      }
    });
    unsubs.push(unsubSettings);

    // 6. Sync Users (Chỉ cho Thu ngân / Quản lý / Admin - Bếp và Order KHÔNG nghe)
    if (!isKitchenOrOrder) {
      const usersQuery = query(collection(db, 'users'), where('storeId', '==', storeId));
      const unsubUsers = onSnapshot(usersQuery, (snapshot) => {
        const usersData = snapshot.docs.map(doc => {
          const data = doc.data();
          const { password, ...safeData } = data as any;
          return { ...safeData, id: doc.id } as User;
        });
        setUsers(usersData);
      });
      unsubs.push(unsubUsers);
    }

    // 7. Sync Shifts
    // 7a. Nếu là Bếp (kitchen): Tuyệt đối KHÔNG nghe ca làm việc
    if (currentUser.role === 'kitchen') {
      // Bếp không cần nghe ca
    } else if (currentUser.role === 'order') {
      // 7b. Nhân viên gọi món (order): CHỈ nghe duy nhất ca mở của chính mình (tiết kiệm triệt để reads)
      const myOpenShiftQuery = query(
        collection(db, 'shifts'),
        where('storeId', '==', storeId),
        where('status', '==', 'open'),
        where('staffId', '==', currentUser.id)
      );
      const unsubMyShift = onSnapshot(myOpenShiftQuery, (snapshot) => {
        if (!snapshot.empty) {
          const myShift = { ...snapshot.docs[0].data(), id: snapshot.docs[0].id } as Shift;
          setActiveShift(myShift);
          setAllActiveShifts([myShift]);
        } else {
          setActiveShift(null);
          setAllActiveShifts([]);
        }
      }, (err) => console.warn('Order staff shift query error:', err));
      unsubs.push(unsubMyShift);
    } else {
      // 7c. Thu ngân / Quản lý / Admin: Nghe tất cả các ca đang mở để quản lý điều phối
      const openShiftsQuery = query(
        collection(db, 'shifts'),
        where('storeId', '==', storeId),
        where('status', '==', 'open')
      );
      const unsubOpenShifts = onSnapshot(openShiftsQuery, (snapshot) => {
        const openShifts = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Shift));
        setAllActiveShifts(openShifts);
        const myOpenShift = openShifts.find(s => s.staffId === currentUser?.id);
        setActiveShift(myOpenShift || null);
      }, (err) => console.warn('Open shifts query error:', err));
      unsubs.push(unsubOpenShifts);

      // Ca đã đóng gần nhất trong 3 ngày (Chỉ cho Thu ngân / Quản lý / Admin xem đối soát)
      const threeDaysAgoIso = subDays(new Date(), 3).toISOString();
      const closedShiftsQuery = query(
        collection(db, 'shifts'),
        where('storeId', '==', storeId),
        where('status', '==', 'closed'),
        where('startTime', '>=', threeDaysAgoIso)
      );
      const unsubClosedShifts = onSnapshot(closedShiftsQuery, (snapshot) => {
        const closedData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Shift));
        setShifts(closedData.sort((a, b) => b.startTime.localeCompare(a.startTime)));
      }, (err) => {
        console.warn('Closed shifts query fallback:', err);
        const fallbackShifts = query(
          collection(db, 'shifts'),
          where('storeId', '==', storeId),
          where('status', '==', 'closed'),
          limit(30)
        );
        const unsubFallback = onSnapshot(fallbackShifts, (snapshot) => {
          const closedData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Shift));
          setShifts(closedData.sort((a, b) => b.startTime.localeCompare(a.startTime)));
        });
        unsubs.push(unsubFallback);
      });
      unsubs.push(unsubClosedShifts);
    }

    // 8. Sync Customers (Chỉ cho Thu ngân / Quản lý / Admin - Bếp và Order KHÔNG nghe)
    if (!isKitchenOrOrder) {
      const customersQuery = query(collection(db, 'customers'), where('storeId', '==', storeId));
      const unsubCustomers = onSnapshot(customersQuery, (snapshot) => {
        const customersData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Customer));
        setCustomers(customersData);
      });
      unsubs.push(unsubCustomers);
    }

    return () => {
      isMounted = false;
      unsubs.forEach(u => u());
    };
  }, [currentUser?.storeId, currentUser?.id, currentUser?.role]);

  // DATE-BOUNDED REALTIME SYNC (Hôm nay theo múi giờ Việt Nam):
  // Đưa điều kiện ngày trực tiếp vào Firestore query (P0 - Cắt giảm 99% reads tải đầu)
  // và tách riêng để khi qua nửa đêm chỉ effect này cập nhật, không reload menu/bàn!
  useEffect(() => {
    if (!currentUser) return;
    const storeId = currentUser.storeId;
    const isKitchen = currentUser.role === 'kitchen';
    const isOrderOnly = currentUser.role === 'order';
    const unsubs: (() => void)[] = [];

    // 1. Điểm danh hôm nay của chính user
    const myAttendanceQuery = query(
      collection(db, 'attendance_records'),
      where('storeId', '==', storeId),
      where('userId', '==', currentUser.id)
    );
    const unsubMyAttendance = onSnapshot(myAttendanceQuery, (snapshot) => {
      const attendanceData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as AttendanceRecord));
      setMyTodayAttendance(attendanceData);
    }, (err) => console.warn('User today attendance listener error:', err));
    unsubs.push(unsubMyAttendance);

    // Bếp và Order không cần nghe hóa đơn hay sổ quỹ
    if (isKitchen || isOrderOnly) {
      return () => {
        unsubs.forEach(u => u());
      };
    }

    setInvoicesReady(false);
    setInvoices([]);
    setCashTransactions([]);
    const errors = (error: Error) => { invoicesConfirmed=false;cashConfirmed=false;console.error('Không thể xác nhận dữ liệu hôm nay:', error); setInvoicesReady(false); };
    let invoicesConfirmed = false, cashConfirmed = false;
    const updateReady = () => setInvoicesReady(invoicesConfirmed && cashConfirmed);
    unsubs.push(subscribeDateRange<Invoice>('invoices', storeId, currentBusinessDate, currentBusinessDate, (rows, confirmed) => {
      setInvoices(rows.filter(i => i.status !== 'cancelled').sort((a,b) => b.date.localeCompare(a.date)));
      invoicesConfirmed = confirmed; updateReady();
    }, errors));
    unsubs.push(subscribeDateRange<CashTransaction>('cash_transactions', storeId, currentBusinessDate, currentBusinessDate, (rows, confirmed) => {
      setCashTransactions(rows.sort((a,b) => b.date.localeCompare(a.date)));
      cashConfirmed = confirmed; updateReady();
    }, errors));

    return () => {
      unsubs.forEach(u => u());
    };
  }, [currentUser?.storeId, currentUser?.id, currentUser?.role, currentBusinessDate]);

  // ON-DEMAND SYNC: Kho hàng (Chỉ lắng nghe khi mở tab Kho)
  useEffect(() => {
    if (!currentUser || view !== 'inventory') return;
    const storeId = currentUser.storeId;
    const unsubs: (() => void)[] = [];

    const auditsQuery = query(
      collection(db, 'inventory_audits'), 
      where('storeId', '==', storeId), 
      orderBy('date', 'desc')
    );
    const unsubAudits = onSnapshot(auditsQuery, (snapshot) => {
      const auditsData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as InventoryAudit));
      setInventoryAudits(auditsData);
    }, (err) => {
      console.warn('Audits orderBy fallback to limit:', err);
      const fallbackAudits = query(collection(db, 'inventory_audits'), where('storeId', '==', storeId));
      const unsubFallback = onSnapshot(fallbackAudits, (snapshot) => {
        const auditsData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as InventoryAudit));
        setInventoryAudits(auditsData.sort((a, b) => b.date.localeCompare(a.date)));
      });
      unsubs.push(unsubFallback);
    });
    unsubs.push(unsubAudits);

    const stockCardQuery = query(
      collection(db, 'stock_card'), 
      where('storeId', '==', storeId), 
      orderBy('date', 'desc')
    );
    const unsubStockCard = onSnapshot(stockCardQuery, (snapshot) => {
      const stockCardData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as StockCardEntry));
      setStockCardEntries(stockCardData);
    }, (err) => {
      console.warn('Stock card orderBy fallback to limit:', err);
      const fallbackStock = query(collection(db, 'stock_card'), where('storeId', '==', storeId));
      const unsubFallback = onSnapshot(fallbackStock, (snapshot) => {
        const stockCardData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as StockCardEntry));
        setStockCardEntries(stockCardData.sort((a, b) => b.date.localeCompare(a.date)));
      });
      unsubs.push(unsubFallback);
    });
    unsubs.push(unsubStockCard);

    return () => {
      unsubs.forEach(u => u());
    };
  }, [currentUser?.storeId, view]);

  // Complete source for payroll: never calculate salaries from a display-page limit.
  useEffect(() => {
    setPayrollSourceReady(false);
    if (!currentUser || (view !== 'user_mgmt' && view !== 'my_payroll')) return;
    const storeId = currentUser.storeId;
    const personal = view === 'my_payroll' || !['admin','manager'].includes(currentUser.role);
    let attendanceReady = false, payrollReady = false;
    const constraints = [where('storeId', '==', storeId)];
    if (personal) constraints.push(where('userId','==',currentUser.id));
    const error = (err: Error) => { setPayrollSourceReady(false); console.error('Không thể tải đầy đủ dữ liệu lương:',err); };
    const a = onSnapshot(query(collection(db,'attendance_records'),...constraints), {includeMetadataChanges:true}, snapshot => {
      setAttendanceRecords(snapshot.docs.map(d => ({...d.data(),id:d.id} as AttendanceRecord)).sort((a,b)=>b.date.localeCompare(a.date)));
      attendanceReady=!snapshot.metadata.fromCache&&!snapshot.metadata.hasPendingWrites;
      setPayrollSourceReady(attendanceReady&&payrollReady);
    },error);
    const p = onSnapshot(query(collection(db,'payroll_records'),...constraints), {includeMetadataChanges:true}, snapshot => {
      setPayrollRecords(snapshot.docs.map(d=>({...d.data(),id:d.id} as PayrollRecord)).sort((a,b)=>b.month.localeCompare(a.month)));
      payrollReady=!snapshot.metadata.fromCache&&!snapshot.metadata.hasPendingWrites;
      setPayrollSourceReady(attendanceReady&&payrollReady);
    },error);
    return () => { a();p(); };
  }, [currentUser?.storeId,currentUser?.id,currentUser?.role,view]);


  // Authentication
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    safeStorage.setItem('fnb_master_user', JSON.stringify(user));
    setIsRegistering(false);
    if (user.role === 'admin' || user.role === 'manager') {
      setView('tables');
    } else if (user.role === 'kitchen') {
      setView('kitchen');
    } else {
      setView('shifts');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (authErr) {
      console.warn("SignOut error:", authErr);
    }
    setCurrentUser(null);
    safeStorage.removeItem('fnb_master_user');
    safeStorage.removeItem('fnb_master_token');
    try {
      localStorage.removeItem('fnb_master_user');
      localStorage.removeItem('fnb_master_token');
      sessionStorage.clear();
    } catch (_) {}
    window.location.reload();
  };

  const handleDeleteAccount = async () => {
    if (!currentUser) return;
    if (!confirm('Bạn có chắc chắn muốn xóa tài khoản và dữ liệu không? Hành động này không thể hoàn tác!')) return;

    try {
      const storeId = currentUser.storeId;
      const userId = currentUser.id;

      if (currentUser.role === 'admin' && storeId) {
        // Quản trị viên: Xóa cửa hàng và toàn bộ dữ liệu liên quan qua backend API có kiểm soát
        const resp = await fetch(apiUrl('/api/delete-store'), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
          },
          body: JSON.stringify({ storeId })
        });
        const data = await resp.json().catch(() => ({}));
        if (!resp.ok) {
          alert(data.error || 'Có lỗi xảy ra khi xóa cửa hàng và dữ liệu');
          return;
        }
      } else if (userId) {
        // Nhân viên: Xóa tài khoản cá nhân qua API
        const resp = await fetch(apiUrl('/api/delete-user'), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
          },
          body: JSON.stringify({ userId })
        });
        const data = await resp.json().catch(() => ({}));
        if (!resp.ok) {
          alert(data.error || 'Có lỗi xảy ra khi xóa tài khoản');
          return;
        }
      }

      // Chỉ xóa bộ nhớ tạm và tải lại khi API thực sự xác nhận thành công
      safeStorage.removeItem('fnb_master_user');
      safeStorage.removeItem('fnb_master_token');
      localStorage.clear();
      sessionStorage.clear();
      alert('Tài khoản và dữ liệu của bạn đã được xóa hoàn toàn khỏi hệ thống.');
      window.location.reload();
    } catch (error: any) {
      console.error('Error deleting account:', error);
      alert('Không thể kết nối đến máy chủ để xóa tài khoản.');
    }
  };

  // Table Management
  const handleAddTable = async (name: string, groupId?: string) => {
    if (!currentUser) return false;
    
    // Check for duplicate name
    const isDuplicate = tables.some(t => t.name.toLowerCase() === name.toLowerCase());
    if (isDuplicate) {
      alert(`Tên bàn "${name}" đã tồn tại. Vui lòng chọn tên khác.`);
      return false;
    }

    await addDoc(collection(db, 'tables'), {
      name,
      status: 'empty',
      currentOrder: [],
      storeId: currentUser.storeId,
      groupId: groupId || null
    });
    return true;
  };

  const handleUpdateTable = async (id: string, updates: Partial<Table>, expectedOrders?: OrderSession[], voidLog?: VoidLog) => {
    // Check for duplicate name if name is being updated
    if (updates.name) {
      const isDuplicate = tables.some(t => t.id !== id && t.name.toLowerCase() === updates.name!.toLowerCase());
      if (isDuplicate) {
        alert(`Tên bàn "${updates.name}" đã tồn tại. Vui lòng chọn tên khác.`);
        return false;
      }
    }
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    if (updates.orders) {
      await updateOrdersAtomic(currentUser, id, expectedOrders || tables.find(t => t.id === id)?.orders || [], updates.orders, false, voidLog, activeShift?.id);
    } else await updateDoc(doc(db, 'tables', id), updates);
    return true;
  };

  const handleDeleteTable = async (id: string) => {
    setConfirmDialog({
      message: 'Bạn có chắc chắn muốn xóa bàn này?',
      onConfirm: async () => {
        await deleteDoc(doc(db, 'tables', id));
      }
    });
  };

  const handleAddTableGroup = async (name: string) => {
    if (!currentUser) return;
    await addDoc(collection(db, 'table_groups'), {
      name,
      storeId: currentUser.storeId
    });
  };

  const handleDeleteTableGroup = async (id: string) => {
    setConfirmDialog({
      message: 'Xóa nhóm bàn sẽ không xóa các bàn trong nhóm. Bạn có chắc chắn?',
      onConfirm: async () => {
        await deleteDoc(doc(db, 'table_groups', id));
      }
    });
  };

  // Menu Management
  const handleAddItem = async (item: MenuItem) => {
    if (!currentUser) return;
    setMenu(prev => {
      const idx = prev.findIndex(i => i.id === item.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = item;
        return copy;
      }
      return [...prev, item];
    });
    if (item.id) {
      await setDoc(doc(db, 'menu', item.id), { 
        ...item, 
        storeId: currentUser.storeId,
        isInventory: item.isInventory === true 
      });
    } else {
      const docRef = await addDoc(collection(db, 'menu'), { 
        ...item, 
        storeId: currentUser.storeId,
        isInventory: item.isInventory === true 
      });
      setMenu(prev => prev.map(i => i.id === item.id ? { ...i, id: docRef.id } : i));
    }
  };

  const handleDeleteItem = async (id: string) => {
    setMenu(prev => prev.filter(i => i.id !== id));
    await deleteDoc(doc(db, 'menu', id));
    await updateOutOfStockStatus([], [id]);
  };

  const handleUpdateItem = async (item: MenuItem) => {
    if (!item.id) return;
    const existing = menu.find(i => i.id === item.id);
    setMenu(prev => prev.map(i => i.id === item.id ? { ...i, ...item } : i));
    const { stock: currentStockIsReadOnly, ...metadata } = item;
    await updateDoc(doc(db, 'menu', item.id), { ...metadata, isInventory: item.isInventory === true });

    if (item.trackStock === false) {
      await updateOutOfStockStatus([], [item.id]);
    } else if (item.stock !== undefined) {
      const oldStock = existing?.stock ?? 0;
      if (oldStock > 0 && item.stock <= 0) {
        await updateOutOfStockStatus([item.id], []);
      } else if (oldStock <= 0 && item.stock > 0) {
        await updateOutOfStockStatus([], [item.id]);
      }
    }
  };

  const handleDeleteCategory = (cat: string) => {
    setConfirmDialog({
      message: `Bạn có chắc chắn muốn xóa nhóm "${cat}"? Tất cả các món ăn và nguyên liệu trong nhóm này cũng sẽ bị xóa.`,
      onConfirm: async () => {
        const currentCats = systemSettings.menuCategories || CATEGORIES;
        const newCats = currentCats.filter(c => c !== cat);
        await handleUpdateSettings({ ...systemSettings, menuCategories: newCats });
        setMenu(prev => prev.filter(item => item.category !== cat));

        const itemsToDelete = menu.filter(item => item.category === cat);
        for (const item of itemsToDelete) {
          if (item.id) {
            await deleteDoc(doc(db, 'menu', item.id));
          }
        }
      }
    });
  };

  const handleAddCategory = (cat: string) => {
    const currentCats = systemSettings.menuCategories || CATEGORIES;
    handleUpdateSettings({ ...systemSettings, menuCategories: [...currentCats, cat] });
  };

  const handleRenameCategory = async (oldName: string, newName: string) => {
    const trimmedNew = newName.trim();
    if (!trimmedNew || oldName === trimmedNew) return;

    const currentCats = systemSettings.menuCategories || CATEGORIES;
    const newCats = currentCats.map(c => c === oldName ? trimmedNew : c);
    await handleUpdateSettings({ ...systemSettings, menuCategories: newCats });

    const affectedItems = menu.filter(item => item.category === oldName);
    if (affectedItems.length > 0) {
      setMenu(prev => prev.map(item => item.category === oldName ? { ...item, category: trimmedNew } : item));
      
      const batch = writeBatch(db);
      affectedItems.forEach(item => {
        if (item.id) {
          batch.update(doc(db, 'menu', item.id), { category: trimmedNew });
        }
      });
      await batch.commit();
    }
  };

  const handleDeleteInventoryCategory = (cat: string) => {
    setConfirmDialog({
      message: `Bạn có chắc chắn muốn xóa nhóm kho "${cat}"? Tất cả các mặt hàng trong nhóm này cũng sẽ bị xóa.`,
      onConfirm: async () => {
        const currentCats = systemSettings.inventoryCategories || ['Nguyên liệu', 'Đồ uống', 'Khác'];
        const newCats = currentCats.filter(c => c !== cat);
        await handleUpdateSettings({ ...systemSettings, inventoryCategories: newCats });
        setMenu(prev => prev.filter(item => !(item.category === cat && (item.isInventory || item.type === 'goods'))));

        const itemsToDelete = menu.filter(item => item.category === cat && (item.isInventory || item.type === 'goods'));
        for (const item of itemsToDelete) {
          if (item.id) {
            await deleteDoc(doc(db, 'menu', item.id));
          }
        }
      }
    });
  };

  const handleAddInventoryCategory = (cat: string) => {
    const currentCats = systemSettings.inventoryCategories || ['Nguyên liệu', 'Đồ uống', 'Khác'];
    handleUpdateSettings({ ...systemSettings, inventoryCategories: [...currentCats, cat] });
  };

  const handleRenameInventoryCategory = async (oldName: string, newName: string) => {
    const trimmedNew = newName.trim();
    if (!trimmedNew || oldName === trimmedNew) return;

    const currentCats = systemSettings.inventoryCategories || ['Nguyên liệu', 'Đồ uống', 'Khác'];
    const newCats = currentCats.map(c => c === oldName ? trimmedNew : c);
    await handleUpdateSettings({ ...systemSettings, inventoryCategories: newCats });

    const affectedItems = menu.filter(item => item.category === oldName && (item.isInventory || item.type === 'goods'));
    if (affectedItems.length > 0) {
      setMenu(prev => prev.map(item => (item.category === oldName && (item.isInventory || item.type === 'goods')) ? { ...item, category: trimmedNew } : item));
      
      const batch = writeBatch(db);
      affectedItems.forEach(item => {
        if (item.id) {
          batch.update(doc(db, 'menu', item.id), { category: trimmedNew });
        }
      });
      await batch.commit();
    }
  };

  // Inventory Management
  const handleImportStock = async (itemId: string, quantity: number, unitPrice: number, id = operationId('import')) => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    await importStockAtomic(currentUser, itemId, quantity, unitPrice, activeShift?.id, id);
    // An auxiliary status refresh must never turn a committed import into a failed import.
    await updateOutOfStockStatus([], [itemId]).catch(console.warn);
  };

  const handleAuditInventory = async (audit: InventoryAudit) => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    await auditStockAtomic(currentUser, audit);
    const out = audit.items.filter(i => i.actualStock <= 0).map(i => i.itemId);
    const available = audit.items.filter(i => i.actualStock > 0).map(i => i.itemId);
    await updateOutOfStockStatus(out, available).catch(console.warn);
  };

  const handleUpdateInventoryItem = async (item: MenuItem, expected?: MenuItem) => {
    if(!currentUser)throw new Error('Vui lòng đăng nhập lại.');
    const {stock: ignoredStock,id,...metadata}=item;
    await runTransaction(db,async txn=>{
      const ref=doc(db,'menu',id),snapshot=await txn.get(ref);
      if(!snapshot.exists()||snapshot.data().storeId!==currentUser.storeId)throw new Error('Không tìm thấy mặt hàng của cửa hàng.');
      if(expected && snapshot.data().costPrice!==expected.costPrice)throw new Error('Giá vốn vừa thay đổi do nhập hàng. Vui lòng mở lại mặt hàng trước khi sửa.');
      txn.update(ref,metadata);
    });
    await reconcileOutOfStockStatus(currentUser.storeId,menu,systemSettings.outOfStockAddOnIds||[]).catch(console.warn);
  };

  const handleDeleteInventoryItem = async (id: string) => {
    setMenu(prev => prev.filter(i => i.id !== id));
    await deleteDoc(doc(db, 'menu', id));
    await updateOutOfStockStatus([], [id]);
  };

  const handleUpdateTableOrders = async (tableId: string, updatedOrders: OrderSession[]) => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    const base = tables.find(t => t.id === tableId)?.orders || [];
    await updateOrdersAtomic(currentUser, tableId, base, updatedOrders, true);
  };

  const handleUpdateOrder = async (tableId: string, items: OrderItem[], targetSessionId?: string, id = operationId('order')): Promise<string> => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    return addOrderAtomic(currentUser, tableId, items, targetSessionId, systemSettings.vatPercent || 0, id);
  };

  const handleAddCashTransaction = async (transaction: Omit<CashTransaction, 'id' | 'storeId'>, id = operationId('cash')) => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    await recordCashAtomic(currentUser, transaction, activeShift?.id, id);
  };

  const handleDeleteInvoice = async (invoiceId: string) => {
    if (!currentUser || currentUser.role !== 'admin') throw new Error('Chỉ quản trị viên được hủy hóa đơn.');
    const result = await cancelInvoiceAtomic(currentUser, invoiceId);
    if (result.deleted) {
      setInvoices(previous => previous.filter(i => i.id !== invoiceId));
      setCashTransactions(previous => previous.filter(c => (c as any).invoiceId !== invoiceId));
      const currentCatalog=await fetchStoreRows<MenuItem>('menu',currentUser.storeId).catch(()=>menu);
      await reconcileOutOfStockStatus(currentUser.storeId, currentCatalog, systemSettings.outOfStockAddOnIds || []).catch(console.warn);
      if (result.legacyStockUnknown) alert('Đã hủy hóa đơn. Hóa đơn cũ không có lịch sử xuất kho để hoàn tự động; hãy đối soát tồn kho theo chứng từ thực tế.');
    }
    return result.deleted;
  };

  const handleResetAllTables = async () => {
    setConfirmDialog({
      message: 'Bạn có chắc chắn muốn xóa toàn bộ thông tin bàn và đưa tất cả về trạng thái trống?',
      onConfirm: async () => {
        const batch = tables.map(t => updateDoc(doc(db, 'tables', t.id), {
          status: 'empty',
          orders: [],
          currentOrder: [],
          discount: 0,
          note: deleteField(),
          customerId: deleteField(),
          startTime: deleteField(),
          lastCommittedTotal: deleteField()
        }));
        
        await Promise.all(batch);
        alert('Đã đặt lại toàn bộ bàn thành công.');
      }
    });
  };

  const handleMergeTables = async (targetTableId: string, sourceTableIds: string[], id = operationId('move')) => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    await moveTablesAtomic(currentUser, targetTableId, sourceTableIds, false, id);
  };

  const handleTransferTable = async (sourceTableId: string, targetTableId: string, id = operationId('move')) => {
    if (!currentUser) throw new Error('Vui lòng đăng nhập lại.');
    await moveTablesAtomic(currentUser, targetTableId, [sourceTableId], true, id);
  };

  const handleCheckout = async (tableId: string, ordersToPay: OrderSession[], discount: number, paymentMethod: 'cash' | 'transfer', shouldPrint: boolean = false, customerId?: string): Promise<boolean> => {
    if (!currentUser) return false;

    // 1. Khóa chống thanh toán lặp đa luồng / click đúp liên tục (P0 Idempotency & Replay Protection)
    if (checkoutLockRef.current.has(tableId)) {
      console.warn(`[Anti-Replay P0] Bàn ${tableId} đang được thanh toán trong tiến trình khác. Hủy lệnh trùng.`);
      return false;
    }
    checkoutLockRef.current.add(tableId);

    try {
      // The draft may have just been saved while React still holds an older table.
      const tableDoc=await getDocFromServer(doc(db,'tables',tableId));
      if(!tableDoc.exists())throw new Error('Bàn không còn tồn tại.');
      const table={...tableDoc.data(),id:tableDoc.id} as Table;
      if((table as any).storeId!==currentUser.storeId)throw new Error('Bàn không thuộc cửa hàng.');

      // Kiểm tra đơn hợp lệ cần thanh toán (Chống ghi lặp đơn đã thanh toán)
      if (!ordersToPay || ordersToPay.length === 0) return false;
      if (ordersToPay.some(o => o.id?.startsWith('draft-'))) throw new Error('Vui lòng lưu đơn trước khi thanh toán.');
      const currentOrders = table.orders || [];
      const currentOrderIds = new Set(currentOrders.map(o => o.id));
      const validOrders = ordersToPay.filter(o => currentOrderIds.has(o.id) || o.id?.startsWith('draft-'));
      if (validOrders.length === 0 && currentOrders.length === 0) {
        console.warn(`[Anti-Replay P0] Bàn ${table.name} đã được thanh toán hoặc không còn đơn nào để thanh toán.`);
        return false;
      }

      // Calculate totals for the invoice based on SELECTED orders
      const subtotal = ordersToPay.reduce((sum, o) => sum + itemsSubtotal(o.items), 0);
      const normalizedDiscount = Math.min(100, Math.max(0, Number.isFinite(discount) ? discount : 0));
      const discountAmount = Math.round((subtotal * normalizedDiscount) / 100);
      const vatAmount = Math.round(((subtotal - discountAmount) * (systemSettings.vatPercent || 0)) / 100);
      const total = subtotal - discountAmount + vatAmount;

      // Combine notes from orders being paid and table note (for merged/transferred tables)
      const validNotes = ordersToPay
        .map(o => o.note?.trim())
        .filter((n): n is string => Boolean(n));
      const combinedNotes = validNotes.join('; ');

      const noteParts: string[] = [];
      if (table.note && table.note.trim()) {
        noteParts.push(table.note.trim());
      }
      if (combinedNotes) {
        noteParts.push(combinedNotes);
      }
      const finalInvoiceNote = noteParts.join(' | ');

      // Create Invoice
      const allItems = ordersToPay.reduce((acc, o) => acc.concat(o.items), [] as OrderItem[]);
      
      // Keep recipe versions separate even if the dish ID and sale price match.
      const groupedItems: OrderItem[] = [];
      allItems.forEach(item => {
        const key=itemKey(item);
        const existing=groupedItems.find(i=>itemKey(i)===key);

        if (existing) {
          existing.quantity += item.quantity;
        } else {
          const selectedAddOns = (item.selectedAddOns || []).map(addOn => {
            if (addOn.inventoryItemId) return { ...addOn };
            const candidates = menu.filter(menuItem => (menuItem.isInventory || menuItem.type === 'goods' || menuItem.category === 'Nguyên liệu') && menuItem.name.toLowerCase().trim() === addOn.name.toLowerCase().trim());
            if(candidates.length > 1) throw new Error('Món kèm trùng tên nhiều nguyên liệu; vui lòng liên kết đúng mã kho trước khi thanh toán.');
            const source = candidates[0];
            return source?.id ? { ...addOn, inventoryItemId: source.id } : { ...addOn };
          });
          groupedItems.push({ ...item, selectedAddOns });
        }
      });

      const minStartTime = ordersToPay.reduce((min, o) => {
        if (!min) return o.startTime;
        return new Date(o.startTime) < new Date(min) ? o.startTime : min;
      }, '');

      // Setup Atomic Firestore Transaction với Idempotency Key và Server-Authoritative Stock
      const sortedSessionIds = ordersToPay.map(o => o.id).sort().join('_');
      const idempotencyKey = `${currentUser.storeId}_${tableId}_${sortedSessionIds}`;
      const lockDocRef = doc(db, 'checkout_locks', idempotencyKey);

      const invoiceRef = doc(collection(db, 'invoices'));
      const invoiceId = invoiceRef.id;
      const invoiceNowIso = new Date().toISOString();
      const vnBusinessDate = getVietnamBusinessDate(invoiceNowIso);

      // Tính chính xác giá vốn thực tế (COGS) tại thời điểm bán cho toàn bộ món & topping chốt thành snapshot
      // Chuẩn hóa theo công thức: unitCost × quantityPerServing × soldQuantity
      let invoiceCost = calculateInvoiceCost(groupedItems);
      let invoiceCostIsComplete = false;

      const costSourceIds = new Set<string>();
      groupedItems.forEach(item => {
        if (item.id) costSourceIds.add(item.id);
        (item.recipe || []).forEach(recipe => costSourceIds.add(recipe.ingredientId));
        (item.selectedAddOns || []).forEach(addOn => { if (addOn.inventoryItemId) costSourceIds.add(addOn.inventoryItemId); });
      });

      const cashRef = doc(db, 'cash_transactions', `cash_${invoiceId}`);
      const dailyStatsRef = doc(db, 'daily_stats', `${currentUser.storeId}_${vnBusinessDate}`);
      const tableRef = doc(db, 'tables', tableId);

      const itemsBecomingOut: string[] = [];
      const stockUpdates: Record<string, number> = {};
      let remainingOrdersResult: OrderSession[] = [];
      let newStartTimeResult: string | undefined = undefined;

      // THỰC THI TRANSACTION NGUYÊN TỬ (Chống thanh toán đồng thời & đảm bảo tính đúng đắn đa máy)
      const checkoutCommitted = await runTransaction(db, async (txn) => {
        // --- 1. TOÀN BỘ CÁC BƯỚC ĐỌC (READS TRƯỚC TIÊN) ---
        // 1a. Đọc khóa Idempotency
        const lockSnap = await txn.get(lockDocRef);
        if (lockSnap.exists() && lockSnap.data().status === 'completed') {
          console.warn(`[Idempotency] Yêu cầu thanh toán ${idempotencyKey} đã được hoàn tất trước đó.`);
          return;
        }

        // 1b. Đọc trạng thái bàn thực tế từ server
        const tableSnap = await txn.get(tableRef);
        if (!tableSnap.exists()) {
          throw new Error('Bàn không tồn tại trên hệ thống.');
        }
        const serverTable = tableSnap.data() as Table;
        const serverOrders = serverTable.orders || [];
        const persistedOrdersToPay = ordersToPay.filter(order => !order.id?.startsWith('draft-'));
        const paidIds = new Set(persistedOrdersToPay.map(p => p.id));
        const stillPresent = serverOrders.filter(o => paidIds.has(o.id));
        if (stillPresent.length !== persistedOrdersToPay.length) throw new Error('Đơn hàng đã thay đổi hoặc được thanh toán ở thiết bị khác. Vui lòng mở lại bàn.');
        const serverById = new Map(stillPresent.map(order => [order.id, order]));
        if (persistedOrdersToPay.some(order => orderSignature(order) !== orderSignature(serverById.get(order.id)!))) throw new Error('Nội dung đơn hàng vừa thay đổi ở thiết bị khác. Vui lòng kiểm tra lại.');

        const serverItemSnaps = new Map<string, any>();
        for (const itemId of costSourceIds) {
          const itemSnap = await txn.get(doc(db, 'menu', itemId));
          if(itemSnap.exists()&&itemSnap.data().storeId!==currentUser.storeId)throw new Error('Mặt hàng/nguyên liệu không thuộc cửa hàng.');
          serverItemSnaps.set(itemId, itemSnap);
        }

        // 1d. Đọc thông tin khách hàng nếu có
        let custSnap = null;
        if (customerId) {
          custSnap = await txn.get(doc(db, 'customers', customerId));
        }

        // 1e. Đọc thống kê ngày (daily_stats) để kiểm tra trạng thái trước khi cập nhật
        const dailyStatsSnap = await txn.get(dailyStatsRef);
        if (activeShift) {
          const shiftSnap = await txn.get(doc(db,'shifts',activeShift.id));
          if (!shiftSnap.exists() || shiftSnap.data().storeId !== currentUser.storeId || shiftSnap.data().status !== 'open') throw new Error('Ca đã đóng ở thiết bị khác. Vui lòng mở ca hợp lệ.');
        }
        // Stock decisions use server flags and the exact IDs captured on the order.
        const deltaMap = new Map<string, { item: MenuItem; totalDeduction: number; details: string[] }>();
        const addDelta = (id: string, quantity: number, reason: string) => {
          const source = serverItemSnaps.get(id);
          if (!source?.exists()) throw new Error('Mặt hàng/nguyên liệu không còn tồn tại. Vui lòng kiểm tra lại định lượng.');
          const data = source.data();
          if (data.storeId !== currentUser.storeId) throw new Error('Nguyên liệu không thuộc cửa hàng.');
          if (data.trackStock === false || quantity <= 0) return;
          if(stockQuantity(quantity)<=0)throw new Error('Định lượng nhỏ hơn 0,001 đơn vị kho. Vui lòng kiểm tra lại đơn vị nguyên liệu.');
          const previous = deltaMap.get(id);
          deltaMap.set(id, { item: { ...data, id } as MenuItem, totalDeduction: stockQuantity((previous?.totalDeduction || 0) + quantity), details: [...(previous?.details || []), reason] });
        };
        for (const item of groupedItems) {
          if (item.recipe?.length) for (const recipe of item.recipe) addDelta(recipe.ingredientId, recipe.quantity * item.quantity, item.name);
          else if (item.type === 'goods') addDelta(item.id, item.quantity, item.name);
          for (const addon of item.selectedAddOns || []) if (addon.inventoryItemId) addDelta(addon.inventoryItemId, (addon.quantity ?? 1) * item.quantity, addon.name);
        }
        if(deltaMap.size>200)throw new Error('Hóa đơn có quá nhiều mặt hàng kho. Vui lòng chia thanh toán theo các đơn nhỏ hơn. Chưa có giao dịch nào được ghi.');
        const costSnapshot = calculateInvoiceCostSnapshot(groupedItems, itemId => {
          const sourceSnap = serverItemSnaps.get(itemId);
          return sourceSnap?.exists() ? sourceSnap.data() : undefined;
        });
        invoiceCost = costSnapshot.totalCost;
        invoiceCostIsComplete = costSnapshot.isComplete;

        // --- 2. TOÀN BỘ CÁC BƯỚC GHI (WRITES) ---
        // 2a. Trừ tồn kho từ số liệu đọc trực tiếp trên server
        for (const [itemId, delta] of deltaMap.entries()) {
          const itemSnap = serverItemSnaps.get(itemId);
          const serverStock = (itemSnap && itemSnap.exists() && typeof itemSnap.data().stock === 'number')
            ? itemSnap.data().stock
            : 0;
          const newStock = Number((serverStock - delta.totalDeduction).toFixed(3));
          stockUpdates[itemId] = newStock;

          txn.update(doc(db, 'menu', itemId), { stock: newStock });

          if (delta.item.trackStock !== false && serverStock > 0 && newStock <= 0) {
            itemsBecomingOut.push(itemId);
          }

          // Ghi thẻ kho trong cùng transaction
          const cardRef = doc(collection(db, 'stock_card'));
          const cardEntry: StockCardEntry = {
            itemId: delta.item.id,
            itemName: delta.item.name,
            date: invoiceNowIso,
            type: 'export',
            referenceId: invoiceId,
            change: -delta.totalDeduction,
            remaining: newStock,
            note: `Bán hàng HĐ #${invoiceId.slice(-6).toUpperCase()}: ${delta.details.join('; ')}`
          };
          txn.set(cardRef, { ...cardEntry, storeId: currentUser.storeId });
        }

        // 2b. Cộng điểm tích lũy khách hàng trong transaction
        if (customerId && custSnap && custSnap.exists()) {
          const currentPoints = custSnap.data().points || 0;
          const pointsEarned = Math.floor(total / 100000);
          txn.update(doc(db, 'customers', customerId), {
            points: currentPoints + pointsEarned,
            lastVisit: invoiceNowIso
          });
        }

        // 2c. Ghi Hóa đơn
        const noteParts: string[] = [];
        if (serverTable.note && serverTable.note.trim()) {
          noteParts.push(serverTable.note.trim());
        }
        if (combinedNotes) {
          noteParts.push(combinedNotes);
        }
        const finalInvoiceNote = noteParts.join(' | ');

        const invoiceDocData: Invoice = {
          id: invoiceId,
          date: invoiceNowIso,
          businessDate: vnBusinessDate,
          businessMonth: vnBusinessDate.slice(0, 7),
          businessYear: parseInt(vnBusinessDate.slice(0, 4), 10),
          timeIn: minStartTime || serverTable.startTime || invoiceNowIso,
          items: groupedItems,
          subtotal,
          discount: discountAmount,
          vat: vatAmount,
          total,
          totalCost: invoiceCost,
          costVersion: 3,
          statsApplied: true,
          inventoryMovements: [...deltaMap.entries()].map(([itemId, delta]) => ({ itemId, quantity: delta.totalDeduction })),
          pointsEarned: Math.floor(total / 100000),
          costStatus: invoiceCostIsComplete ? 'complete' : 'estimated',
          paymentMethod,
          tableId,
          shiftId: activeShift?.id,
          tableName: serverTable.name,
          staffId: currentUser.id,
          staffName: currentUser.name,
          storeId: currentUser.storeId,
          customerId,
          note: finalInvoiceNote
        };
        txn.set(invoiceRef, { ...invoiceDocData, storeId: currentUser.storeId, idempotencyKey });

        // 2d. Ghi Phiếu thu liên kết chính xác (Deterministic Doc ID `cash_${invoiceId}`)
        txn.set(cashRef, {
          amount: total,
          type: 'income',
          paymentMethod,
          category: 'Bán hàng',
          note: `Thanh toán bàn ${serverTable.name}`,
          date: invoiceNowIso,
          businessDate: vnBusinessDate,
          businessMonth: vnBusinessDate.slice(0, 7),
          businessYear: parseInt(vnBusinessDate.slice(0, 4), 10),
          staffId: currentUser.id,
          staffName: currentUser.name,
          storeId: currentUser.storeId,
          invoiceId: invoiceId
        });

        // 2e. Cập nhật Thống kê ngày (daily_stats) bằng Atomic Increment
        let targetCostStatus: 'complete' | 'estimated' = invoiceCostIsComplete ? 'complete' : 'estimated';
        if (dailyStatsSnap && dailyStatsSnap.exists()) {
          const prevStats = dailyStatsSnap.data() as any;
          if (prevStats.costStatus === 'estimated' || !invoiceCostIsComplete) {
            targetCostStatus = 'estimated';
          }
        }

        txn.set(dailyStatsRef, {
          storeId: currentUser.storeId,
          date: vnBusinessDate,
          year: parseInt(vnBusinessDate.slice(0, 4), 10),
          month: vnBusinessDate.slice(0, 7),
          totalRevenue: increment(total),
          totalCash: increment(isCashPayment(paymentMethod) ? total : 0),
          totalTransfer: increment(isCashPayment(paymentMethod) ? 0 : total),
          invoiceCount: increment(1),
          totalDiscount: increment(discountAmount || 0),
          totalCost: increment(invoiceCost),
          costStatus: targetCostStatus,
          coverageStatus: 'live_tracking',
          sourceRevision: increment(1),
          hasData: true,
          version: 2,
          updatedAt: invoiceNowIso
        }, { merge: true });

        // 2f. Cập nhật Ca làm việc bằng Atomic Increment
        if (activeShift) {
          const isCash = paymentMethod === 'cash';
          txn.update(doc(db, 'shifts', activeShift.id), { 
            totalRevenue: increment(total),
            totalCash: increment(isCash ? total : 0),
            totalTransfer: increment(!isCash ? total : 0),
            cashIncome: increment(isCash ? total : 0),
            transferIncome: increment(!isCash ? total : 0)
          });
        }

        // 2g. Cập nhật Bàn: Gỡ các order đã thanh toán
        const remainingOrders = serverOrders.filter(o => !paidIds.has(o.id));
        remainingOrdersResult = remainingOrders;

        let calcNewStartTime = serverTable.startTime;
        if (remainingOrders.length > 0 && !calcNewStartTime) {
          calcNewStartTime = remainingOrders.reduce((earliest, o) => {
            if (!o.startTime) return earliest;
            if (!earliest) return o.startTime;
            try {
              return new Date(o.startTime) < new Date(earliest) ? o.startTime : earliest;
            } catch (e) {
              return earliest || o.startTime;
            }
          }, '');
        }
        newStartTimeResult = calcNewStartTime;

        txn.update(tableRef, {
          orders: remainingOrders,
          status: remainingOrders.length === 0 ? 'empty' : 'occupied',
          currentOrder: [],
          discount: 0,
          startTime: remainingOrders.length === 0 ? deleteField() : (calcNewStartTime || invoiceNowIso),
          note: remainingOrders.length === 0 ? deleteField() : (serverTable.note || deleteField())
        });

        // 2h. Đánh dấu hoàn tất Khóa Idempotency
        txn.set(lockDocRef, {
          idempotencyKey,
          storeId: currentUser.storeId,
          tableId,
          invoiceId,
          total,
          completedAt: invoiceNowIso,
          status: 'completed'
        });
        return true;
      });
      if (!checkoutCommitted) {
        alert('Đơn này đã được thanh toán trước đó. Hệ thống sẽ đồng bộ lại trạng thái bàn.');
        return false;
      }

      // Cập nhật trạng thái hết hàng của topping nếu tồn kho chuyển từ > 0 sang <= 0
      if (itemsBecomingOut.length > 0) {
        await updateOutOfStockStatus(itemsBecomingOut, []).catch(error => console.warn('Thanh toán đã thành công; trạng thái hết hàng sẽ đồng bộ lại:', error));
      }

      // Cập nhật local state tức thì mượt mà
      if (Object.keys(stockUpdates).length > 0) {
        setMenu(prev => prev.map(m => stockUpdates[m.id] !== undefined ? { ...m, stock: stockUpdates[m.id] } : m));
      }

      setTables(prev => prev.map(t => t.id === tableId ? {
        ...t,
        orders: remainingOrdersResult,
        status: remainingOrdersResult.length === 0 ? 'empty' : 'occupied',
        currentOrder: [],
        discount: 0,
        startTime: remainingOrdersResult.length === 0 ? undefined : (newStartTimeResult || t.startTime),
        note: remainingOrdersResult.length === 0 ? undefined : t.note
      } : t));

      let customerName = undefined;
      let customerType = undefined;
      if (customerId) {
        const c = customers.find(x => x.id === customerId);
        if (c) {
          customerName = c.name;
          const t = (systemSettings.customerTypes || []).find(x => x.id === c.typeId);
          if (t) {
            customerType = t.name;
          }
        }
      }

      // Print Invoice if requested
      if (shouldPrint) {
        try { triggerPrint({
          type: 'bill',
          tableName: tables.find(t => t.id === tableId)?.name || 'Bàn',
          items: groupedItems,
          subtotal,
          discount: discountAmount,
          vat: vatAmount,
          total,
          staffName: currentUser.name,
          timeIn: minStartTime || invoiceNowIso,
          timeOut: invoiceNowIso,
          note: combinedNotes,
          customerName,
          customerType
        }); } catch (error) { console.warn('Thanh toán đã thành công; vui lòng in lại hóa đơn:', error); }
      }

      // Đóng modal
      setSelectedTable(null);
      return true;
    } catch (err) {
      console.error('Lỗi khi thực hiện thanh toán:', err);
      alert('Có lỗi xảy ra trong quá trình thanh toán. Vui lòng thử lại!');
      return false;
    } finally {
      // Giải phóng khóa bàn
      checkoutLockRef.current.delete(tableId);
    }
  };

  // Shift Management
  const handleOpenShift = async (startCash: number) => {
    if(!currentUser)return;
    if(!Number.isFinite(startCash)||startCash<0){alert('Tiền đầu ca không hợp lệ.');return;}
    try {
      const legacy=(await fetchStoreRows<Shift>('shifts',currentUser.storeId)).find(s=>s.staffId===currentUser.id&&s.status==='open');
      const guardRef=doc(db,'checkout_locks',`shift_open_${currentUser.storeId}_${currentUser.id}`);
      const freshRef=doc(collection(db,'shifts'));
      await runTransaction(db,async txn=>{
        const guard=await txn.get(guardRef);
        const oldId=guard.data()?.shiftId||legacy?.id;
        const old=oldId?await txn.get(doc(db,'shifts',oldId)):undefined;
        if(old?.exists()&&old.data().status==='open'){
          if(old.data().storeId!==currentUser.storeId||old.data().staffId!==currentUser.id)throw new Error('Ca không thuộc nhân viên hiện tại.');
          return;
        }
        const now=new Date().toISOString();
        txn.set(freshRef,{storeId:currentUser.storeId,startTime:now,startCash,totalRevenue:0,totalCash:0,totalTransfer:0,cashIncome:0,cashExpense:0,transferIncome:0,transferExpense:0,staffId:currentUser.id,staffName:currentUser.name,status:'open'});
        txn.set(guardRef,{storeId:currentUser.storeId,staffId:currentUser.id,shiftId:freshRef.id,type:'shift_guard',updatedAt:now});
      });
    }catch(error){alert(error instanceof Error?error.message:'Không thể mở ca.');}
  };

  const handleCloseShift = async (endCash: number): Promise<boolean> => {
    if (!activeShift) return false;
    if(!Number.isFinite(endCash)||endCash<0){alert('Tiền kiểm kê không hợp lệ.');return false;}
    try {
      await runTransaction(db, async txn => {
        const shiftRef = doc(db, 'shifts', activeShift.id);
        const shiftSnap = await txn.get(shiftRef);
        if (!shiftSnap.exists()) throw new Error('Không tìm thấy ca làm việc.');
        const serverShift = shiftSnap.data() as Shift;
        if (serverShift.status !== 'open') throw new Error('Ca làm việc này đã được đóng ở thiết bị khác.');
        const discrepancy = endCash - ((serverShift.startCash || 0) + (serverShift.totalCash || 0));
        txn.update(shiftRef, { endTime: new Date().toISOString(), endCash, discrepancy, discrepancyProcessed: discrepancy === 0, status: 'closed' });
      });
      return true;
    } catch (error) {
      alert(error instanceof Error ? error.message : 'Không thể đóng ca. Vui lòng thử lại.');
      return false;
    }
  };

  // User Management (Bảo mật qua backend API: scrypt hashing, không lưu plaintext password)
  const handleAddUser = async (user: User) => {
    if (!currentUser) return;
    try {
      const resp = await fetch(apiUrl('/api/save-user'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
        },
        body: JSON.stringify({
          user: {
            ...user,
            storeId: currentUser.storeId
          }
        })
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        alert(data.error || 'Có lỗi xảy ra khi tạo tài khoản nhân viên');
      }
    } catch (err: any) {
      console.error('Error adding user:', err);
      alert('Không thể kết nối đến máy chủ bảo mật để tạo người dùng. Vui lòng thử lại.');
    }
  };

  const handleUpdateUser = async (user: User) => {
    if (!currentUser) return;
    try {
      const resp = await fetch(apiUrl('/api/save-user'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
        },
        body: JSON.stringify({
          user: {
            ...user,
            storeId: currentUser.storeId
          }
        })
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        alert(data.error || 'Có lỗi xảy ra khi cập nhật tài khoản');
      }
    } catch (err: any) {
      console.error('Error updating user:', err);
      alert('Không thể kết nối đến máy chủ để cập nhật tài khoản.');
    }
  };

  const handleDeleteUser = async (id: string) => {
    if (!currentUser) return;
    try {
      const resp = await fetch(apiUrl('/api/delete-user'), {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
        },
        body: JSON.stringify({
          userId: id
        })
      });
      if (!resp.ok) {
        const errData = await resp.json().catch(() => ({}));
        alert(errData.error || 'Có lỗi xảy ra khi xóa tài khoản');
      }
    } catch (err) {
      console.error('Error deleting user:', err);
      alert('Không thể kết nối đến máy chủ để xóa tài khoản.');
    }
  };

  const handleFinalizePayroll = async (payroll: PayrollRecord) => {
    if (!currentUser || !payrollSourceReady) throw new Error('Dữ liệu chấm công/lương chưa được server xác nhận đầy đủ.');
    const records = attendanceRecords.filter(r => r.userId === payroll.userId && r.date.slice(0,7) === payroll.month);
    if (attendanceTotals(records).hasOpenSession) throw new Error('Có lượt chấm công chưa kết thúc hoặc giờ không hợp lệ. Vui lòng hoàn tất trước khi chốt lương.');
    const id = `${currentUser.storeId}_${payroll.userId}_${payroll.month}`;
    // Check legacy records before the transaction; the deterministic ID prevents duplicate new finalizations.
    const legacy = payrollRecords.find(p => p.userId === payroll.userId && p.month === payroll.month && p.status === 'finalized');
    if (legacy) throw new Error('Tháng này đã chốt lương. Vui lòng tải lại dữ liệu.');
    await runTransaction(db, async txn => {
      const ref = doc(db,'payroll_records',id), existing = await txn.get(ref);
      if (existing.exists()) throw new Error('Bảng lương đã được chốt ở thiết bị khác.');
      txn.set(ref,{...payroll,id,storeId:currentUser.storeId,finalizedAt:new Date().toISOString()});
    });
  };

  const handleChangePassword = async (newPassword: string) => {
    if (!currentUser) return;
    try {
      const resp = await fetch('/api/change-password', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
        },
        body: JSON.stringify({
          userId: currentUser.id,
          newPassword: newPassword.trim()
        })
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok) {
        alert('Đổi mật khẩu thành công!');
      } else {
        alert(data.error || 'Có lỗi xảy ra khi đổi mật khẩu.');
      }
    } catch (error) {
      console.error('Error changing password:', error);
      alert('Có lỗi xảy ra khi kết nối máy chủ để đổi mật khẩu.');
    }
  };

  const handleUpdateSettings = async (settings: SystemSettings) => {
    setSystemSettings(settings);
    if (!currentUser) return;

    // Update Store Name (admin/manager only)
    if (settings.storeName && (currentUser.role === 'admin' || currentUser.role === 'manager' || currentUser.role === 'superadmin')) {
      try {
        const storeRef = doc(db, 'stores', currentUser.storeId);
        await updateDoc(storeRef, { name: settings.storeName });
      } catch (err) {
        console.error('Error updating store name:', err);
      }
    }

    // Update Admin Account if changed
    if (currentUser.role === 'admin' || currentUser.role === 'superadmin') {
      const updates: any = {};
      if (settings.adminUsername && settings.adminUsername !== currentUser.username) {
        updates.username = settings.adminUsername;
      }
      
      // Nếu có đổi mật khẩu admin trong Cài đặt chung, gọi API đổi mật khẩu an toàn
      if (settings.adminPassword && settings.adminPassword.trim().length > 0) {
        try {
          await fetch(apiUrl('/api/change-password'), {
            method: 'POST',
            headers: { 
              'Content-Type': 'application/json',
              ...(currentUser.token ? { 'Authorization': `Bearer ${currentUser.token}` } : {})
            },
            body: JSON.stringify({
              userId: currentUser.id,
              newPassword: settings.adminPassword.trim()
            })
          });
        } catch (pwErr) {
          console.error("Error updating admin password via API:", pwErr);
        }
      }

      if (Object.keys(updates).length > 0) {
        try {
          await updateDoc(doc(db, 'users', currentUser.id), updates);
          const updatedUser = { ...currentUser, ...updates };
          setCurrentUser(updatedUser);
          safeStorage.setItem('fnb_master_user', JSON.stringify(updatedUser));
        } catch (err) {
          console.error('Error updating user credentials:', err);
        }
      }
    }

    // Update Settings Collection (Strip outOfStockAddOnIds để tránh ghi đè dữ liệu atomic hết hàng của toppings)
    try {
      const { outOfStockAddOnIds: _ignored, ...safeSettings } = settings;
      const sRef = await getSettingsDocRef(currentUser.storeId);
      await setDoc(sRef, { ...safeSettings, storeId: currentUser.storeId }, { merge: true });
    } catch (err) {
      console.error('Error updating settings collection:', err);
    }
  };

  const handleAddCustomer = async (customer: Customer) => {
    if (!currentUser) return;
    try {
      await addDoc(collection(db, 'customers'), { ...customer, storeId: currentUser.storeId });
    } catch (error) {
      console.error('Error adding customer:', error);
      alert('Lỗi khi thêm khách hàng.');
    }
  };

  const handleUpdateCustomerTypes = async (types: CustomerType[]) => {
    if (!currentUser) return;
    const newSettings = { ...systemSettings, customerTypes: types };
    setSystemSettings(newSettings);
    
    try {
      const settingsQuery = query(collection(db, 'settings'), where('storeId', '==', currentUser.storeId));
      const settingsSnap = await getDocs(settingsQuery);
      if (!settingsSnap.empty) {
        await updateDoc(doc(db, 'settings', settingsSnap.docs[0].id), { customerTypes: types });
      } else {
        await addDoc(collection(db, 'settings'), { ...newSettings, storeId: currentUser.storeId });
      }
    } catch (error) {
      console.error('Error updating customer types:', error);
    }
  };

  const handleToggleKitchenEnabled = async (enabled: boolean) => {
    if (!currentUser) return;
    const newSettings = { ...systemSettings, kitchenEnabled: enabled };
    setSystemSettings(newSettings);

    try {
      const settingsQuery = query(collection(db, 'settings'), where('storeId', '==', currentUser.storeId));
      const settingsSnap = await getDocs(settingsQuery);
      if (!settingsSnap.empty) {
        await updateDoc(doc(db, 'settings', settingsSnap.docs[0].id), { kitchenEnabled: enabled });
      } else {
        await addDoc(collection(db, 'settings'), { ...newSettings, storeId: currentUser.storeId });
      }
    } catch (error) {
      console.error('Error updating kitchen enabled setting:', error);
    }
  };

  if (!currentUser) {
    if (isRegistering) {
      return <RegisterStoreView onBack={() => setIsRegistering(false)} onSuccess={() => setIsRegistering(false)} />;
    }
    return <LoginView onLogin={handleLogin} onRegisterClick={() => setIsRegistering(true)} />;
  }

  if (currentUser.role === 'superadmin') {
    return <SuperAdminView onLogout={handleLogout} />;
  }

  const handleCheckIn = async (record: Partial<AttendanceRecord>) => {
    if(!currentUser)throw new Error('Vui lòng đăng nhập lại.');
    return recordAttendanceAtomic(currentUser,record);
  };

  const isCheckinPage = new URLSearchParams(window.location.search).get('checkin') === 'true';

  if (isCheckinPage) {
    return <CheckInView currentUser={currentUser} settings={systemSettings} onCheckIn={handleCheckIn} />;
  }

  const todayStr = currentBusinessDate;
  const todayRecords = currentUser ? (myTodayAttendance.length > 0 ? myTodayAttendance.filter(r=>r.date===todayStr||!r.checkOutTime) : attendanceRecords.filter(r => r.userId === currentUser.id && (r.date === todayStr||!r.checkOutTime))) : [];
  const latestTodayRecord = todayRecords.sort((a, b) => new Date(b.checkInTime || 0).getTime() - new Date(a.checkInTime || 0).getTime())[0];
  const attendanceStatus: 'none' | 'checked_in' | 'checked_out' = !latestTodayRecord 
    ? 'none' 
    : (latestTodayRecord.checkOutTime ? 'checked_out' : 'checked_in');

  const activeOrdersCount = tables.reduce((acc, t) => acc + (t.orders?.filter(o => o.status !== 'paid').length || 0), 0);

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-[#0a0a0a] text-gray-700 dark:text-gray-300 font-sans selection:bg-emerald-500/30">
      <Sidebar activeView={view} setView={handleSetView} onLogout={handleLogout} currentUser={currentUser} unresolvedShiftsCount={currentUser?.role === 'admin' ? shifts.filter(s => s.discrepancy !== undefined && s.discrepancy !== 0 && !s.discrepancyProcessed).length : 0} packages={packages} />
      
      <main className="flex-1 flex flex-col overflow-hidden pb-[calc(4rem+env(safe-area-inset-bottom))] md:pb-0">
        <SubscriptionAlert store={currentUser.store} onLogout={handleLogout} />
        <Header 
          view={view} 
          setView={handleSetView} 
          currentUser={currentUser} 
          packages={packages} 
          onShowUpgrade={() => setShowUpgradeModal(true)} 
          onScanQR={() => setShowScanner(true)}
          menu={menu} 
          shifts={[...allActiveShifts, ...shifts]} 
        />
        
        {/* Content Area */}
        <div className="flex-1 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {view === 'tables' && (
                <div className="flex flex-col h-full">
                  <div className="p-6 border-b border-black/5 dark:border-white/5 flex flex-col gap-4 bg-black/5 dark:bg-white/5">
                    <div className="flex justify-between items-center">
                      <div className="flex gap-4 items-center">
                        <button 
                          onClick={() => setActiveTableGroup('all')}
                          className={cn(
                            "px-4 py-2 rounded-xl text-sm transition-all cursor-pointer",
                            activeTableGroup === 'all' ? "bg-emerald-500 text-white font-bold" : "bg-black/5 dark:bg-white/5 text-gray-600 dark:text-gray-400 hover:bg-black/10 dark:hover:bg-white/10"
                          )}
                        >
                          Tất cả khu vực
                        </button>
                        {tableGroups.map(group => (
                          <div key={group.id} className="relative group/group">
                            <button 
                              onClick={() => setActiveTableGroup(group.id)}
                              className={cn(
                                "px-4 py-2 rounded-xl text-sm transition-all cursor-pointer",
                                activeTableGroup === group.id ? "bg-emerald-500 text-white font-bold" : "bg-black/5 dark:bg-white/5 text-gray-600 dark:text-gray-400 hover:bg-black/10 dark:hover:bg-white/10"
                              )}
                            >
                              {group.name}
                            </button>
                            {currentUser?.role === 'admin' && (
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteTableGroup(group.id);
                                }}
                                className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover/group:opacity-100 transition-opacity cursor-pointer"
                              >
                                <X className="w-2 h-2" />
                              </button>
                            )}
                          </div>
                        ))}
                        {currentUser?.role === 'admin' && (
                          <button 
                            onClick={() => setShowAddGroupModal(true)}
                            className="p-2 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl text-emerald-600 dark:text-emerald-500 hover:bg-black/10 dark:hover:bg-white/10 cursor-pointer"
                            title="Thêm nhóm bàn"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      {currentUser?.role === 'admin' && (
                        <button 
                          onClick={() => {
                            setNewTableName(`Bàn ${tables.length + 1}`);
                            setSelectedGroupId(activeTableGroup !== 'all' ? activeTableGroup : '');
                            setShowAddTableModal(true);
                          }}
                          className="flex items-center gap-2 px-4 py-2 bg-emerald-500 text-white rounded-xl text-sm font-bold hover:bg-emerald-400 transition-all cursor-pointer"
                        >
                          <Plus className="w-4 h-4" /> Thêm bàn
                        </button>
                      )}
                    </div>

                    <div className="flex gap-2 items-center p-1 bg-gray-100 dark:bg-black/20 rounded-2xl w-fit">
                      {[
                        { id: 'all', label: 'Tất cả bàn', count: tables.length },
                        { id: 'empty', label: 'Bàn trống', count: tables.filter(t => t.status === 'empty').length },
                        { id: 'occupied', label: 'Đang dùng', count: tables.filter(t => t.status === 'occupied').length }
                      ].map(status => (
                        <button
                          key={status.id}
                          onClick={() => setActiveTableStatus(status.id as any)}
                          className={cn(
                            "px-6 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2",
                            activeTableStatus === status.id 
                              ? "bg-black/10 dark:bg-white/10 text-gray-900 dark:text-white shadow-lg" 
                              : "text-gray-500 hover:text-gray-300"
                          )}
                        >
                          {status.label}
                          <span className={cn(
                            "px-2 py-0.5 rounded-full text-[10px]",
                            activeTableStatus === status.id ? "bg-emerald-500 text-white" : "bg-black/5 dark:bg-white/5 text-gray-500"
                          )}>
                            {status.count}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                  <TableGrid 
                    tables={tables.filter(t => 
                      (activeTableGroup === 'all' || t.groupId === activeTableGroup) &&
                      (activeTableStatus === 'all' || t.status === activeTableStatus)
                    )} 
                    currentUser={currentUser}
                    onSelectTable={(table) => {
                      if (currentUser?.role === 'cashier' && table.status === 'empty') {
                        alert('Nhân viên thu ngân không có quyền mở bàn trống!');
                        return;
                      }
                      if ((currentUser?.role === 'order' || currentUser?.role === 'order_cashier' || currentUser?.role === 'cashier') && !activeShift) {
                        alert('Vui lòng mở ca làm việc trước khi thực hiện order!');
                        return;
                      }
                      setSelectedTable(table);
                    }}
                    onDeleteTable={handleDeleteTable}
                    onEditTable={setEditingTable}
                    kitchenEnabled={systemSettings.kitchenEnabled !== false}
                  />
                </div>
              )}
              {view === 'reports' && (
                !checkStoreTabPermission('reports', currentUser, packages) ? (
                  <LockedTabView title="Báo cáo doanh thu" onUpgrade={() => setShowUpgradeModal(true)} />
                ) : (
                  <ReportsView isDataReady={invoicesReady} invoices={invoices} activeOrdersCount={activeOrdersCount} businessDate={currentBusinessDate} />
                )
              )}
              {view === 'kitchen' && (
                !checkStoreTabPermission('kitchen', currentUser, packages) ? (
                  <LockedTabView title="Nhà bếp" onUpgrade={() => setShowUpgradeModal(true)} />
                ) : (
                  <KitchenView 
                    tables={tables} 
                    onUpdateTableOrders={handleUpdateTableOrders}
                    onPrint={triggerPrint}
                    currentUser={currentUser}
                    kitchenEnabled={systemSettings.kitchenEnabled !== false}
                    onToggleKitchenEnabled={handleToggleKitchenEnabled}
                  />
                )
              )}
              {view === 'inventory' && (
                !checkStoreTabPermission('inventory', currentUser, packages) ? (
                  <LockedTabView title="Kho hàng" onUpgrade={() => setShowUpgradeModal(true)} />
                ) : (
                  <InventoryView 
                    menu={menu} 
                    onImportStock={handleImportStock}
                    onAddItem={handleAddItem}
                    onUpdateItem={handleUpdateInventoryItem}
                    onDeleteItem={handleDeleteInventoryItem}
                    categories={systemSettings.inventoryCategories}
                    onUpdateCategories={(cats) => setSystemSettings({...systemSettings, inventoryCategories: cats})}
                    audits={inventoryAudits}
                    onAudit={handleAuditInventory}
                    stockCard={stockCardEntries}
                    currentUser={currentUser}
                  />
                )
              )}
              {view === 'tax_report' && (
                !checkStoreTabPermission('tax_report', currentUser, packages) ? (
                  <LockedTabView title="Báo cáo bán hàng" onUpgrade={() => setShowUpgradeModal(true)} />
                ) : (
                  <TaxReportView 
                    invoices={invoices}
                    isInvoicesReady={invoicesReady}
                    currentUser={currentUser}
                    onPrint={triggerPrint}
                  />
                )
              )}
              {view === 'summary' && (
                !checkStoreTabPermission('summary', currentUser, packages) ? (
                  <LockedTabView title="Tổng kết" onUpgrade={() => setShowUpgradeModal(true)} />
                ) : (
                  <SummaryView 
                    invoices={invoices}
                    isInvoicesReady={invoicesReady}
                    inventoryLogs={inventoryLogs}
                    cashTransactions={cashTransactions}
                    payrollRecords={payrollRecords}
                    shifts={shifts}
                    activeShift={activeShift}
                    onAddCashTransaction={handleAddCashTransaction}
                    onDeleteInvoice={handleDeleteInvoice}
                    currentUser={currentUser}
                    settings={systemSettings}
                    onUpdateSettings={handleUpdateSettings}
                    onPrint={triggerPrint}
                    activeOrdersCount={activeOrdersCount}
                    businessDate={currentBusinessDate}
                  />
                )
              )}
              {view === 'settings' && (
                <SettingsView 
                  settings={systemSettings}
                  onUpdateSettings={handleUpdateSettings}
                  currentUser={currentUser}
                  onResetAllTables={handleResetAllTables}
                  onChangePassword={handleChangePassword}
                  localPrinters={localPrinters}
                  onUpdateLocalPrinters={handleUpdateLocalPrinters}
                  onDeleteAccount={handleDeleteAccount}
                  isAttendanceUnlocked={checkStoreTabPermission('attendance', currentUser, packages)}
                  onUpgrade={() => setShowUpgradeModal(true)}
                />
              )}
              {view === 'customers' && (
                !checkStoreTabPermission('customers', currentUser, packages) ? (
                  <LockedTabView title="Khách hàng" onUpgrade={() => setShowUpgradeModal(true)} />
                ) : (
                  <CustomerView 
                    customers={customers} 
                    customerTypes={systemSettings.customerTypes || []}
                    onAddCustomer={handleAddCustomer}
                    onUpdateCustomerTypes={handleUpdateCustomerTypes}
                    currentUser={currentUser}
                  />
                )
              )}
              {view === 'shifts' && (
                <ShiftView 
                  activeShift={activeShift} 
                  allActiveShifts={allActiveShifts.filter(s => users.some(u => u.id === s.staffId))}
                  history={shifts} 
                  onOpenShift={handleOpenShift}
                  onCloseShift={handleCloseShift}
                  onResolveDiscrepancy={async (shiftId) => {
                    setShifts(prev => prev.map(s => s.id === shiftId ? { ...s, discrepancyProcessed: true } : s));
                    await updateDoc(doc(db, 'shifts', shiftId), { discrepancyProcessed: true });
                  }}
                  currentUser={currentUser}
                  tables={tables}
                  attendanceStatus={attendanceStatus}
                  onScanQR={() => setShowScanner(true)}
                  isAttendanceAllowed={checkStoreTabPermission('attendance', currentUser, packages)}
                />
              )}
              {view === 'menu_mgmt' && (
                <MenuMgmtView 
                  menu={menu} 
                  onAddItem={handleAddItem} 
                  onDeleteItem={handleDeleteItem}
                  onUpdateItem={handleUpdateItem}
                  categories={categories}
                  inventoryCategories={systemSettings.inventoryCategories || ['Nguyên liệu', 'Đồ uống', 'Khác']}
                  onAddCategory={handleAddCategory}
                  onDeleteCategory={handleDeleteCategory}
                  onRenameCategory={handleRenameCategory}
                  onUpdateCategories={(cats) => handleUpdateSettings({ ...systemSettings, menuCategories: cats })}
                  onAddInventoryCategory={handleAddInventoryCategory}
                  onDeleteInventoryCategory={handleDeleteInventoryCategory}
                  onRenameInventoryCategory={handleRenameInventoryCategory}
                  onUpdateInventoryCategories={(cats) => handleUpdateSettings({ ...systemSettings, inventoryCategories: cats })}
                />
              )}
              {view === 'user_mgmt' && (
                <UserMgmtView 
                    isDataReady={payrollSourceReady}
                  users={users} 
                  currentUser={currentUser}
                  attendanceRecords={attendanceRecords}
                  payrollRecords={payrollRecords}
                  onAddUser={handleAddUser} 
                  onDeleteUser={handleDeleteUser} 
                  onUpdateUser={handleUpdateUser}
                  onFinalizePayroll={handleFinalizePayroll}
                  checkFeatureLimit={checkFeatureLimit}
                />
              )}
              {view === 'my_payroll' && (
                <MyPayrollView isDataReady={payrollSourceReady} 
                  currentUser={currentUser} 
                  attendanceRecords={attendanceRecords}
                  payrollRecords={payrollRecords}
                  settings={systemSettings}
                  onCheckIn={handleCheckIn}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Modals */}
      {featureLimitMessage && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white dark:bg-[#1a1b1e] rounded-xl p-6 max-w-sm w-full text-center shadow-2xl">
            <h3 className="font-bold text-lg text-gray-900 dark:text-white mb-2">Giới hạn tính năng</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">{featureLimitMessage}</p>
            <div className="flex gap-3 justify-center">
              <button 
                onClick={() => setFeatureLimitMessage(null)}
                className="px-4 py-2 bg-gray-100 dark:bg-white/5 hover:bg-gray-200 dark:hover:bg-white/10 rounded-xl font-bold transition-colors"
              >
                Đóng
              </button>
              <button 
                onClick={() => { setFeatureLimitMessage(null); setShowUpgradeModal(true); }}
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold transition-colors"
              >
                Nâng cấp
              </button>
            </div>
          </div>
        </div>
      )}
      {showUpgradeModal && <SubscriptionModal store={currentUser?.store} onClose={() => setShowUpgradeModal(false)} />}
      {selectedTable && (
        <MenuOrdering 
          selectedTable={selectedTable} 
          tables={tables}
          systemSettings={systemSettings}
          onClose={() => setSelectedTable(null)}
          onUpdateOrder={handleUpdateOrder}
          onCheckout={handleCheckout}
          onMergeTables={handleMergeTables}
          onTransferTable={handleTransferTable}
          menu={menu}
          categories={categories}
          vatPercent={systemSettings.vatPercent}
          onPrint={triggerPrint}
          staffName={currentUser.name}
          currentUser={currentUser}
          onUpdateTable={handleUpdateTable}
          customers={customers}
          customerTypes={systemSettings.customerTypes || []}
          onLogVoid={async (log) => {
            const targetShift = activeShift || allActiveShifts[0];
            if (targetShift) {
              const updatedLogs = [...(targetShift.voidLogs || []), log];
              await updateDoc(doc(db, 'shifts', targetShift.id), {
                voidLogs: updatedLogs
              });
            }
          }}
          activeShift={activeShift}
        />
      )}

      {/* Add Table Modal */}
      {showAddTableModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-3xl p-8 border border-black/10 dark:border-white/10 shadow-2xl space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Thêm bàn mới</h3>
              <button onClick={() => setShowAddTableModal(false)} className="text-gray-500 hover:text-gray-900 dark:hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Tên bàn</label>
                <input 
                  type="text" 
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl py-3 px-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50"
                  value={newTableName}
                  onChange={(e) => setNewTableName(e.target.value)}
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Nhóm bàn</label>
                <select 
                  className="w-full bg-white dark:bg-[#1a1b1e] border border-black/10 dark:border-white/10 rounded-xl py-3 px-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50"
                  value={selectedGroupId}
                  onChange={(e) => setSelectedGroupId(e.target.value)}
                >
                  <option value="">-- Không có nhóm --</option>
                  {tableGroups.map(group => (
                    <option key={group.id} value={group.id}>{group.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex gap-3 pt-4">
              <button 
                onClick={() => setShowAddTableModal(false)}
                className="flex-1 py-3 rounded-xl border border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              >
                Hủy
              </button>
              <button 
                onClick={async () => {
                  const success = await handleAddTable(newTableName, selectedGroupId);
                  if (success) setShowAddTableModal(false);
                }}
                className="flex-1 py-3 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-400 cursor-pointer"
              >
                Xác nhận
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Table Modal */}
      {editingTable && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-3xl p-8 border border-black/10 dark:border-white/10 shadow-2xl space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Chỉnh sửa bàn</h3>
              <button onClick={() => setEditingTable(null)} className="text-gray-500 hover:text-gray-900 dark:hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Tên bàn</label>
                <input 
                  type="text" 
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl py-3 px-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50"
                  value={editingTable.name}
                  onChange={(e) => setEditingTable({...editingTable, name: e.target.value})}
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Nhóm bàn</label>
                <select 
                  className="w-full bg-white dark:bg-[#1a1b1e] border border-black/10 dark:border-white/10 rounded-xl py-3 px-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50"
                  value={editingTable.groupId || ''}
                  onChange={(e) => setEditingTable({...editingTable, groupId: e.target.value || undefined})}
                >
                  <option value="">-- Không có nhóm --</option>
                  {tableGroups.map(group => (
                    <option key={group.id} value={group.id}>{group.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex gap-3 pt-4">
              <button 
                onClick={() => setEditingTable(null)}
                className="flex-1 py-3 rounded-xl border border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              >
                Hủy
              </button>
              <button 
                onClick={async () => {
                  const success = await handleUpdateTable(editingTable.id, { name: editingTable.name, groupId: editingTable.groupId || null });
                  if (success) setEditingTable(null);
                }}
                className="flex-1 py-3 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-400 cursor-pointer"
              >
                Cập nhật
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Group Modal */}
      {showAddGroupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-3xl p-8 border border-black/10 dark:border-white/10 shadow-2xl space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Thêm nhóm bàn mới</h3>
              <button onClick={() => setShowAddGroupModal(false)} className="text-gray-500 hover:text-gray-900 dark:hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-gray-500 uppercase font-bold mb-1 block">Tên nhóm</label>
                <input 
                  type="text" 
                  placeholder="VD: Tầng 1, Tầng 2, Sân vườn..."
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl py-3 px-4 text-gray-900 dark:text-white focus:outline-none focus:border-emerald-500/50"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                />
              </div>
            </div>
            <div className="flex gap-3 pt-4">
              <button 
                onClick={() => setShowAddGroupModal(false)}
                className="flex-1 py-3 rounded-xl border border-black/10 dark:border-white/10 text-gray-600 dark:text-gray-400 font-bold hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer"
              >
                Hủy
              </button>
              <button 
                onClick={() => {
                  if (newGroupName) {
                    handleAddTableGroup(newGroupName);
                    setNewGroupName('');
                    setShowAddGroupModal(false);
                  }
                }}
                className="flex-1 py-3 rounded-xl bg-emerald-500 text-white font-bold hover:bg-emerald-400 cursor-pointer"
              >
                Xác nhận
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Print Area */}
      {printData && (
        <div id="print-area" className="hidden print:block">
          {(() => {
            const template = printData.type === 'bill' ? systemSettings.paymentTemplate : systemSettings.kitchenTemplate;
            return (
              <>
                <div className="text-center border-b border-dashed border-black pb-4 mb-4">
                  {template.showLogo && systemSettings.logo && (
                    <img src={systemSettings.logo} alt="Logo" className="w-16 h-16 mx-auto mb-2 grayscale" />
                  )}
                  <h1 className="text-xl font-bold uppercase">{systemSettings.storeName}</h1>
                  {template.showStoreAddress && <p className="text-xs">{systemSettings.address}</p>}
                  {template.showStorePhone && <p className="text-xs">ĐT: {systemSettings.phone}</p>}
                </div>

                <div className="border-b border-dashed border-black pb-2 mb-2">
                  <div className="flex justify-between text-sm font-bold">
                    <span>{printData.type === 'bill' ? 'HÓA ĐƠN THANH TOÁN' : 'PHIẾU CHẾ BIẾN'}</span>
                    <span>{printData.tableName}</span>
                  </div>
                  {template.showTime && printData.timeIn && (
                    <div className="flex justify-between text-[10px] mt-1">
                      <span>Giờ vào: {format(new Date(printData.timeIn), 'dd/MM/yyyy HH:mm')}</span>
                    </div>
                  )}
                  {template.showTime && printData.timeOut && (
                    <div className="flex justify-between text-[10px] mt-1">
                      <span>Giờ ra: {format(new Date(printData.timeOut), 'dd/MM/yyyy HH:mm')}</span>
                    </div>
                  )}
                  {template.showTime && !printData.timeIn && !printData.timeOut && (
                    <div className="flex justify-between text-[10px] mt-1">
                      <span>Ngày: {format(new Date(), 'dd/MM/yyyy HH:mm')}</span>
                    </div>
                  )}
                  {template.showStaffName && (
                    <div className="flex justify-between text-[10px] mt-1">
                      <span>NV: {printData.staffName}</span>
                    </div>
                  )}
                </div>

                <table className={cn("w-full mb-4", template.fontSize === 'small' ? 'text-[10px]' : template.fontSize === 'large' ? 'text-sm' : 'text-xs')}>
                  <thead>
                    <tr className="border-b border-black">
                      <th className="text-left py-1">Tên món</th>
                      <th className="text-center py-1">SL</th>
                      {printData.type === 'bill' && <th className="text-right py-1">T.Tiền</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {printData.items.map((item, idx) => (
                      <tr key={idx} className="border-b border-gray-100">
                        <td className="py-1">
                          <div className="font-bold">{item.name}</div>
                          {template.showNote && item.note && (
                            <div className="text-[10px] italic">Ghi chú: {item.note}</div>
                          )}
                          {item.selectedAddOns?.map(addon => (
                            <div key={addon.id} className="text-[10px] ml-2">+ {addon.name} {addon.price > 0 ? `(+${addon.price.toLocaleString()}đ)` : ''}</div>
                          ))}
                        </td>
                        <td className="text-center py-1">{item.quantity}</td>
                        {printData.type === 'bill' && (
                          <td className="text-right py-1">
                            {((item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0)) * item.quantity).toLocaleString()}
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>

                {printData.type === 'bill' && (
                  <div className="space-y-1 border-t border-black pt-2">
                    <div className="flex justify-between text-xs">
                      <span>Tạm tính:</span>
                      <span>{(printData.subtotal !== undefined ? printData.subtotal : printData.items.reduce((sum, item) => sum + (item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price, 0) || 0)) * item.quantity, 0)).toLocaleString()}đ</span>
                    </div>
                    {(printData.discount || 0) > 0 && (
                      <div className="flex justify-between text-xs">
                        <span>Giảm giá:</span>
                        <span>-{(printData.discount || 0).toLocaleString()}đ</span>
                      </div>
                    )}
                    {(printData.vat || 0) > 0 && (
                      <div className="flex justify-between text-xs">
                        <span>VAT ({systemSettings.vatPercent}%):</span>
                        <span>{(printData.vat || 0).toLocaleString()}đ</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm font-bold pt-1 border-t border-dashed border-black">
                      <span>TỔNG CỘNG:</span>
                      <span>{printData.total?.toLocaleString()}đ</span>
                    </div>
                  </div>
                )}

                <div className="text-center mt-8 text-[10px] italic">
                  {printData.type === 'bill' ? 'Cảm ơn Quý khách. Hẹn gặp lại!' : 'Vui lòng chế biến món nhanh!'}
                </div>
              </>
            );
          })()}
        </div>
      )}

      {/* Confirm Modal */}
      {confirmDialog && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-[#1a1b1e] w-full max-w-md rounded-3xl p-6 md:p-8 border border-black/10 dark:border-white/10 shadow-2xl">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Xác nhận</h3>
            <p className="text-gray-700 dark:text-gray-300 mb-8">{confirmDialog.message}</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setConfirmDialog(null)}
                className="flex-1 py-3 rounded-xl bg-black/5 dark:bg-white/5 text-gray-900 dark:text-white font-bold hover:bg-black/10 dark:hover:bg-white/10 transition-all cursor-pointer"
              >
                Hủy
              </button>
              <button 
                onClick={async () => {
                  await confirmDialog.onConfirm();
                  setConfirmDialog(null);
                }}
                className="flex-1 py-3 rounded-xl bg-rose-500 text-white font-bold hover:bg-rose-400 transition-all cursor-pointer"
              >
                Đồng ý
              </button>
            </div>
          </div>
        </div>
      )}

      {showScanner && currentUser && (
        <AttendanceScanner 
          currentUser={currentUser} 
          settings={systemSettings} 
          attendanceRecords={attendanceRecords} 
          onCheckIn={handleCheckIn} 
          onClose={() => setShowScanner(false)} 
        />
      )}
    </div>
  );
}


const ThemeToggle = () => {
  const [isDark, setIsDark] = React.useState(true);

  React.useEffect(() => {
    const isDarkMode = document.documentElement.classList.contains('dark');
    setIsDark(isDarkMode);
  }, []);

  const toggleTheme = () => {
    const newDark = !isDark;
    setIsDark(newDark);
    if (newDark) {
      document.documentElement.classList.add('dark');
      safeStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      safeStorage.setItem('theme', 'light');
    }
  };

  return (
    <button 
      onClick={toggleTheme}
      className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer rounded-full bg-black/5 dark:bg-white/5"
      title="Đổi giao diện"
    >
      {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
    </button>
  );
};


const Header = ({ 
  view, 
  setView, 
  currentUser, 
  packages, 
  onShowUpgrade,
  onScanQR,
  menu = [],
  shifts = []
}: { 
  view: ViewType; 
  setView: (view: ViewType) => void;
  currentUser: User | null; 
  packages: any[]; 
  onShowUpgrade: () => void;
  onScanQR?: () => void;
  menu?: MenuItem[];
  shifts?: Shift[];
}) => {
  const [showPackageInfo, setShowPackageInfo] = React.useState(false);
  const [showNotifications, setShowNotifications] = React.useState(false);
  const [dismissedNotifIds, setDismissedNotifIds] = React.useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('fnb_dismissed_notif_ids');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const notifRef = React.useRef<HTMLDivElement>(null);

  const [phoneNotifEnabled, setPhoneNotifEnabled] = React.useState<boolean>(isDeviceNotificationEnabled);
  const [permStatus, setPermStatus] = React.useState<'granted' | 'denied' | 'prompt'>('prompt');
  const isInitialMountRef = React.useRef(true);

  React.useEffect(() => {
    checkNotificationPermission().then(status => setPermStatus(status));
  }, []);

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const allNotifications: { 
    id: string; 
    title: string; 
    description: string; 
    type: 'warning' | 'error' | 'info'; 
    actionText?: string; 
    action?: () => void;
    time?: string;
  }[] = [];
  
  if (currentUser?.role === 'admin' || currentUser?.role === 'manager') {
    // 1. Subscription Expiration
    if (currentUser.store?.subscription?.validUntil) {
      const daysLeft = Math.ceil((new Date(currentUser.store.subscription.validUntil).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
      if (daysLeft >= 0 && daysLeft <= 7) {
        allNotifications.push({
          id: 'sub-expiring',
          title: 'Thời hạn tài khoản',
          description: `Thời hạn của tài khoản sẽ hết ${daysLeft === 0 ? 'hôm nay' : `sau ${daysLeft} ngày`}.`,
          type: 'warning'
        });
      }
    } else if (currentUser.store?.subscription?.status === 'trial' && currentUser.store?.subscription?.trialEndDate) {
      const daysLeft = Math.ceil((new Date(currentUser.store.subscription.trialEndDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
      if (daysLeft >= 0 && daysLeft <= 7) {
        allNotifications.push({
          id: 'trial-expiring',
          title: 'Thời hạn dùng thử',
          description: `Thời hạn dùng thử sẽ kết thúc ${daysLeft === 0 ? 'hôm nay' : `sau ${daysLeft} ngày`}.`,
          type: 'warning'
        });
      }
    }

    // 2. Low Stock Items (báo sắp hết nguyên liệu)
    const lowStockItems = menu.filter(item => {
      if (item.trackStock === false) return false;
      const isInv = item.isInventory || item.type === 'goods';
      if (!isInv) return false;
      const threshold = item.minStock !== undefined && item.minStock !== null ? item.minStock : 5;
      return (item.stock ?? 0) <= threshold;
    });

    lowStockItems.forEach(item => {
      const threshold = item.minStock !== undefined && item.minStock !== null ? item.minStock : 5;
      allNotifications.push({
        id: `low-stock-${item.id}`,
        title: `📦 Sắp hết nguyên liệu: ${item.name}`,
        description: `Mã ${item.code || '---'}: Tồn kho còn ${Number(item.stock ?? 0).toLocaleString('vi-VN', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} ${item.unit || 'đv'} (Định mức: ${threshold}). Cần nhập thêm ngay.`,
        type: 'error',
        actionText: 'Nhập kho',
        action: () => { setShowNotifications(false); setView('inventory'); },
        time: new Date().toISOString()
      });
    });

    // 3. Shift Discrepancies (chênh lệch tiền)
    const discrepancyShifts = shifts.filter(s => s.discrepancy !== undefined && s.discrepancy !== 0 && !s.discrepancyProcessed);
    discrepancyShifts.forEach(s => {
      const disc = s.discrepancy || 0;
      allNotifications.push({
        id: `shift-disc-${s.id}`,
        title: `⚠️ Lệch tiền ca: ${s.staffName || 'Nhân viên'}`,
        description: `Ca làm việc ngày ${s.startTime ? format(new Date(s.startTime), 'dd/MM/yyyy HH:mm') : ''} có chênh lệch tiền mặt ${disc > 0 ? '+' : ''}${disc.toLocaleString('vi-VN')}đ chưa xử lý.`,
        type: 'error',
        actionText: 'Xử lý ca',
        action: () => { setShowNotifications(false); setView('shifts'); },
        time: s.startTime
      });
    });

    // 4. Void / Modified Items by Staff (nhân viên hủy món, sửa món)
    const recentCutoff = Date.now() - 48 * 3600 * 1000;
    shifts.forEach(s => {
      if (!s.voidLogs || !Array.isArray(s.voidLogs) || s.voidLogs.length === 0) return;
      const isShiftRecent = s.status === 'open' || (s.startTime && new Date(s.startTime).getTime() > recentCutoff);
      if (!isShiftRecent) return;

      s.voidLogs.forEach((log, idx) => {
        if (log.time && new Date(log.time).getTime() < recentCutoff) return;

        const isCancel = log.newQuantity === 0;
        const logId = `void-${s.id}-${log.time || idx}-${log.itemName}-${log.oldQuantity}-${log.newQuantity}`;

        let title = '';
        let desc = '';

        if (log.type === 'bill_void') {
          title = `⚠️ Hủy/lệch khi tính tiền: Bàn ${log.tableName || '---'}`;
          const detailsStr = log.details && log.details.length > 0 
            ? log.details.map(d => `${d.itemName} (${d.oldQuantity}→${d.newQuantity})`).join(', ')
            : log.itemName;
          desc = `NV: ${log.staffName || 'Nhân viên'} • ${detailsStr} • Giảm: ${(log.valueDiff || 0).toLocaleString('vi-VN')}đ${log.reason ? `. Lý do: "${log.reason}"` : ''}`;
        } else if (isCancel) {
          title = `🚫 Nhân viên hủy món: ${log.itemName}`;
          desc = `Bàn ${log.tableName || '---'} • NV: ${log.staffName || 'Nhân viên'} hủy ${log.oldQuantity || 1} phần${log.valueDiff ? ` (-${log.valueDiff.toLocaleString('vi-VN')}đ)` : ''}${log.reason ? `. Lý do: "${log.reason}"` : ''}`;
        } else {
          title = `✏️ Nhân viên sửa/giảm món: ${log.itemName}`;
          desc = `Bàn ${log.tableName || '---'} • NV: ${log.staffName || 'Nhân viên'} giảm từ ${log.oldQuantity} xuống ${log.newQuantity} phần${log.valueDiff ? ` (-${log.valueDiff.toLocaleString('vi-VN')}đ)` : ''}${log.reason ? `. Lý do: "${log.reason}"` : ''}`;
        }

        allNotifications.push({
          id: logId,
          title,
          description: desc,
          type: isCancel || log.type === 'bill_void' ? 'error' : 'warning',
          actionText: 'Xem ca làm việc',
          action: () => { setShowNotifications(false); setView('shifts'); },
          time: log.time || s.startTime
        });
      });
    });
  }

  // Sort error notifications first, then newest
  allNotifications.sort((a, b) => {
    if (a.type === 'error' && b.type !== 'error') return -1;
    if (a.type !== 'error' && b.type === 'error') return 1;
    if (a.time && b.time) return b.time.localeCompare(a.time);
    return 0;
  });

  const notifications = allNotifications.filter(n => !dismissedNotifIds.includes(n.id));

  // Push un-sent bell notifications to phone screen
  React.useEffect(() => {
    if (!currentUser || (currentUser.role !== 'admin' && currentUser.role !== 'manager')) {
      return;
    }

    if (isInitialMountRef.current) {
      seedInitialNotificationIds(notifications.map(n => n.id));
      isInitialMountRef.current = false;
      return;
    }

    notifications.forEach(notif => {
      if (!hasNotificationBeenSent(notif.id)) {
        sendDeviceNotification({
          id: notif.id,
          title: notif.title,
          body: notif.description,
          type: notif.type
        });
      }
    });
  }, [notifications, currentUser]);

  const dismissNotification = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setDismissedNotifIds(prev => {
      const updated = [...prev, id];
      try { localStorage.setItem('fnb_dismissed_notif_ids', JSON.stringify(updated.slice(-200))); } catch {}
      return updated;
    });
  };

  const dismissAllNotifications = () => {
    setDismissedNotifIds(prev => {
      const updated = [...prev, ...allNotifications.map(n => n.id)];
      try { localStorage.setItem('fnb_dismissed_notif_ids', JSON.stringify(updated.slice(-200))); } catch {}
      return updated;
    });
  };

  const handleRequestPermission = async () => {
    const granted = await requestNotificationPermission();
    setPermStatus(granted ? 'granted' : 'denied');
    if (granted) {
      setPhoneNotifEnabled(true);
      setDeviceNotificationEnabled(true);
      await sendDeviceNotification({
        id: `welcome-${Date.now()}`,
        title: '🔔 Fnb Master: Đã kích hoạt thông báo',
        body: 'Bạn sẽ nhận thông báo trên màn hình điện thoại khi có hủy món, sửa món, hết nguyên liệu, hoặc lệch tiền.',
        type: 'info'
      });
    }
  };

  const handleTestNotification = async () => {
    await sendDeviceNotification({
      id: `test-notif-${Date.now()}`,
      title: '🔔 Fnb Master: Thông báo điện thoại hoạt động!',
      body: 'Chủ quán nhận biến động ngay: sắp hết nguyên liệu, nhân viên hủy món, sửa món, chênh lệch tiền.',
      type: 'info'
    });
    if (permStatus !== 'granted') {
      const status = await checkNotificationPermission();
      setPermStatus(status);
    }
  };

  const handleTogglePhoneNotif = () => {
    const nextVal = !phoneNotifEnabled;
    setPhoneNotifEnabled(nextVal);
    setDeviceNotificationEnabled(nextVal);
  };

  const titles: Record<ViewType, string> = {
    tables: 'Sơ đồ phòng bàn',
    menu_mgmt: 'Quản lý thực đơn',
    kitchen: 'Điều phối nhà bếp',
    reports: 'Báo cáo doanh thu',
    inventory: 'Quản lý kho hàng',
    customers: 'Khách hàng (CRM)',
    shifts: 'Quản lý ca làm việc',
    user_mgmt: 'Quản lý nhân viên',
    summary: 'Tổng kết & Báo cáo',
    settings: 'Cài đặt hệ thống',
    my_payroll: 'Lương & Chấm công',
    tax_report: 'Báo cáo thuế'
  };

  const store = currentUser?.store;
  const currentPackageId = store?.subscription?.packageId || 'trial';
  const currentPackage = packages.find(p => p.id === currentPackageId) || { name: 'Gói Dùng Thử', features: { maxUsers: 'Không giới hạn' } };

  return (
    <header className="h-[calc(4rem+env(safe-area-inset-top))] md:h-[calc(5rem+env(safe-area-inset-top))] pt-[env(safe-area-inset-top)] border-b border-black/5 dark:border-white/5 flex items-center justify-between px-4 md:px-8 bg-gray-50 dark:bg-[#0a0a0a]/80 backdrop-blur-md z-10 shrink-0">
      <div>
        <h2 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white uppercase tracking-wider truncate max-w-[200px] md:max-w-none">
          {titles[view]}
        </h2>
        <p className="text-[11px] md:text-xs text-gray-500 mt-0.5 truncate block">
          {getVietnamHeaderDateString()} • {currentUser?.name}
        </p>
      </div>
      
      <div className="flex items-center gap-4 md:gap-6">
        {currentUser?.role === 'admin' && (
          <div className="hidden lg:flex items-center gap-3">
            <div className="relative">
              <button 
                onClick={() => setShowPackageInfo(!showPackageInfo)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-50 dark:bg-blue-500/10 text-blue-600 dark:text-blue-500 hover:bg-blue-100 dark:hover:bg-blue-500/20 transition-colors"
              >
                <Package className="w-4 h-4" />
                <span className="text-sm font-bold">{currentPackage.name}</span>
              </button>
              
              {showPackageInfo && (
                <div className="absolute top-full right-0 mt-2 w-72 bg-white dark:bg-[#1a1b1e] border border-black/10 dark:border-white/10 rounded-2xl shadow-xl p-4 z-50">
                  <h4 className="font-bold mb-2">Thông tin gói dịch vụ</h4>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>• Cửa hàng: <span className="font-semibold text-gray-900 dark:text-white">{store?.name || '---'}</span></li>
                    <li>• Gói hiện tại: <span className="font-bold text-emerald-600 dark:text-emerald-400">{currentPackage.name}</span></li>
                    <li>• Tối đa: <span className="font-medium text-gray-900 dark:text-white">{currentPackage.features?.maxUsers || 'Không giới hạn'} nhân viên</span></li>
                    {store?.subscription?.validUntil && (
                      <li>• Hết hạn: <span className="font-medium text-gray-900 dark:text-white">{format(new Date(store.subscription.validUntil), 'dd/MM/yyyy')}</span></li>
                    )}
                  </ul>
                  <div className="mt-3 pt-3 border-t border-black/10 dark:border-white/10">
                    <p className="text-xs font-bold text-gray-900 dark:text-white mb-2">Quyền truy cập các Tab:</p>
                    <div className="grid grid-cols-2 gap-1.5 text-xs">
                      {APP_PACKAGE_TABS.map(tab => {
                        const isAllowed = isTabAllowedInPackage(tab.id, currentPackage);
                        return (
                          <div 
                            key={tab.id}
                            className={cn(
                              "flex items-center gap-1.5 px-2 py-1 rounded-md",
                              isAllowed 
                                ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 font-semibold" 
                                : "bg-black/5 dark:bg-white/5 text-gray-400 line-through opacity-60"
                            )}
                          >
                            <span>{isAllowed ? '✓' : '✕'}</span>
                            <span className="truncate">{tab.label}</span>
                          </div>
                        );
                      })}
                    </div>
                    <div className="mt-3 pt-3 border-t border-black/10 dark:border-white/10 flex flex-col gap-2">
                      <button
                        onClick={() => {
                          setShowPackageInfo(false);
                          onShowUpgrade();
                        }}
                        className="w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Shield className="w-3.5 h-3.5" />
                        <span>Nâng cấp / Gia hạn gói</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        

        {view === 'tables' && (
          <div className="hidden md:flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-black/10 dark:bg-white/10 border border-black/20 dark:border-white/20" />
              <span>Trống</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50" />
              <span>Đang dùng</span>
            </div>
          </div>
        )}
        
        <div className="h-8 w-[1px] bg-black/10 dark:bg-white/10 hidden md:block" />

        <ThemeToggle />
        {(currentUser?.role === 'admin' || currentUser?.role === 'manager') && (
          <div className="relative" ref={notifRef}>
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer rounded-full hover:bg-black/5 dark:hover:bg-white/5"
              title="Thông báo hệ thống"
            >
              <Bell className="w-6 h-6" />
              {notifications.length > 0 && (
                <span className="absolute top-1 right-1 flex min-w-[16px] h-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[9px] font-bold text-white border-2 border-white dark:border-[#0a0a0a]">
                  {notifications.length}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute top-full right-0 mt-2 w-80 md:w-96 bg-white dark:bg-[#1a1b1e] border border-black/10 dark:border-white/10 rounded-2xl shadow-2xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="p-4 border-b border-black/10 dark:border-white/10 bg-gray-50 dark:bg-white/5 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-gray-900 dark:text-white text-sm">Thông báo hệ thống</h4>
                    <span className="text-xs bg-rose-500/10 text-rose-600 dark:text-rose-400 px-2 py-0.5 rounded-full font-bold">
                      {notifications.length}
                    </span>
                  </div>
                  {notifications.length > 0 && (
                    <button
                      onClick={dismissAllNotifications}
                      className="text-xs text-gray-500 hover:text-gray-900 dark:hover:text-white font-medium hover:underline cursor-pointer"
                    >
                      Đã đọc tất cả
                    </button>
                  )}
                </div>

                {/* Phone Notification Status & Action Bar */}
                <div className="px-3.5 py-2.5 bg-blue-50/80 dark:bg-blue-500/10 border-b border-black/5 dark:border-white/5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <Smartphone className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                    <div className="truncate">
                      <span className="font-semibold text-gray-800 dark:text-gray-200">Màn hình điện thoại: </span>
                      {permStatus === 'granted' && phoneNotifEnabled ? (
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">Đang bật</span>
                      ) : !phoneNotifEnabled ? (
                        <span className="text-amber-600 dark:text-amber-400 font-medium">Đang tắt</span>
                      ) : (
                        <span className="text-gray-500 dark:text-gray-400 font-medium">Chưa cấp quyền</span>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1.5 shrink-0">
                    {permStatus !== 'granted' ? (
                      <button
                        onClick={handleRequestPermission}
                        className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-[11px] transition-colors cursor-pointer shadow-sm"
                      >
                        Bật ngay
                      </button>
                    ) : (
                      <>
                        <button
                          onClick={handleTestNotification}
                          className="px-2 py-1 bg-white dark:bg-[#25272c] hover:bg-gray-100 dark:hover:bg-white/10 text-gray-700 dark:text-gray-200 border border-black/10 dark:border-white/10 font-medium rounded-lg text-[10px] transition-colors cursor-pointer flex items-center gap-1"
                          title="Gửi thử một thông báo lên màn hình điện thoại"
                        >
                          <BellRing className="w-3 h-3 text-blue-500" />
                          <span>Thử báo</span>
                        </button>
                        <button
                          onClick={handleTogglePhoneNotif}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-colors cursor-pointer border ${
                            phoneNotifEnabled 
                              ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-500/20 hover:bg-rose-100' 
                              : 'bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/20 hover:bg-emerald-100'
                          }`}
                        >
                          {phoneNotifEnabled ? 'Tắt' : 'Bật'}
                        </button>
                      </>
                    )}
                  </div>
                </div>
                <div className="max-h-[380px] overflow-y-auto custom-scrollbar divide-y divide-black/5 dark:divide-white/5">
                  {notifications.length > 0 ? (
                    notifications.map((notif) => (
                      <div 
                        key={notif.id} 
                        onClick={notif.action} 
                        className="p-3.5 hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer group relative"
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-2.5 h-2.5 mt-1 rounded-full shrink-0 ${notif.type === 'error' ? 'bg-rose-500' : notif.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'}`} />
                          <div className="flex-1 pr-5">
                            <div className="flex items-center justify-between gap-2">
                              <h5 className={`text-xs font-bold leading-tight ${notif.type === 'error' ? 'text-rose-600 dark:text-rose-400' : notif.type === 'warning' ? 'text-amber-600 dark:text-amber-500' : 'text-blue-600 dark:text-blue-400'}`}>
                                {notif.title}
                              </h5>
                              {notif.time && (
                                <span className="text-[10px] text-gray-400 font-normal shrink-0">
                                  {format(new Date(notif.time), 'HH:mm')}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-gray-600 dark:text-gray-300 mt-1 leading-relaxed">
                              {notif.description}
                            </p>
                            {notif.actionText && (
                              <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 group-hover:underline">
                                <span>{notif.actionText}</span>
                                <span>→</span>
                              </div>
                            )}
                          </div>
                          <button
                            onClick={(e) => dismissNotification(notif.id, e)}
                            className="absolute top-3 right-3 p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-md hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
                            title="Ẩn thông báo này"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-8 text-center text-gray-500 text-sm">
                      <Bell className="w-8 h-8 mx-auto mb-3 opacity-20" />
                      Không có thông báo mới nào
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
};
